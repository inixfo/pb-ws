from django.apps import AppConfig


class EmiConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'emi'
