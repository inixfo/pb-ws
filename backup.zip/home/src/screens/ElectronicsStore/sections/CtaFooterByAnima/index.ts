export { CtaFooterByAnima } from "./CtaFooterByAnima";
