import { ArrowRightIcon, ShoppingCartIcon } from "lucide-react";
import React from "react";
import { Badge } from "../../../../components/ui/badge";
import { Button } from "../../../../components/ui/button";
import { Card, CardContent } from "../../../../components/ui/card";
import { Separator } from "../../../../components/ui/separator";

export const ThankYouContent = (): JSX.Element => {
  // Order details data
  const orderDetails = {
    orderNumber: "234000",
    deliveryAddress: "567 Cherry Souse Lane Sacramento, 95829",
    deliveryTime: "Sunday, May 9, 12:00 - 14:00",
    paymentMethod: "Cash on delivery",
  };

  // Product data for recommended items
  const recommendedProducts = [
    {
      id: 1,
      name: "VRB01 Virtual Reality Glasses",
      price: "$340.99",
      originalPrice: "$430.00",
      discount: "-21%",
      rating: 4,
      reviews: 123,
      image: "/image.png",
      hasDiscount: true,
    },
    {
      id: 2,
      name: "Apple iPhone 14 128GB Blue",
      price: "$899.00",
      rating: 4.5,
      reviews: 142,
      image: "/image-1.png",
      hasDiscount: false,
    },
  ];

  // Render star ratings
  const renderStars = (rating: number) => {
    const stars = [];
    for (let i = 1; i <= 5; i++) {
      if (i <= rating) {
        stars.push(
          <img
            key={i}
            className="w-3 h-3"
            alt="Star fill"
            src="/star-fill.svg"
          />,
        );
      } else if (i - 0.5 === rating) {
        stars.push(
          <img
            key={i}
            className="w-3 h-3"
            alt="Star half"
            src="/star-half.svg"
          />,
        );
      } else {
        stars.push(
          <img key={i} className="w-3 h-3" alt="Star" src="/star.svg" />,
        );
      }
    }
    return stars;
  };

  return (
    <div className="flex flex-col md:flex-row w-full items-start gap-8 py-8 px-4">
      {/* Left section - Order details */}
      <div className="flex flex-col items-start w-full md:w-1/2 max-w-[600px]">
        {/* Order confirmation header */}
        <header className="flex items-center justify-between relative w-full mb-8">
          <div className="flex items-center gap-4">
            <img className="w-12 h-12" alt="Check" src="/check.svg" />
            <div className="flex flex-col w-full items-start gap-1.5">
              <p className="w-full text-gray-600 text-sm leading-[22px] font-normal">
                Order #{orderDetails.orderNumber}
              </p>
              <h4 className="w-full font-semibold text-gray-900 text-2xl leading-8">
                Thank you for your order!
              </h4>
            </div>
          </div>
          <Button
            variant="link"
            className="text-gray-700 text-sm font-medium underline"
          >
            Track order
          </Button>
        </header>

        {/* Order details section */}
        <div className="flex flex-col w-full items-start gap-8 mb-8">
          <Separator className="w-full" />
          <div className="flex flex-col items-start gap-6 w-full">
            {/* Delivery address */}
            <div className="flex flex-col items-start gap-2 w-full">
              <h6 className="w-full font-semibold text-gray-900 text-base leading-6">
                Delivery
              </h6>
              <p className="w-full text-gray-600 text-sm leading-[22px] font-normal">
                {orderDetails.deliveryAddress}
              </p>
            </div>

            {/* Delivery time */}
            <div className="flex flex-col items-start gap-2 w-full">
              <h6 className="w-full font-semibold text-gray-900 text-base leading-6">
                Time
              </h6>
              <p className="w-full text-gray-600 text-sm leading-[22px] font-normal">
                {orderDetails.deliveryTime}
              </p>
            </div>

            {/* Payment method */}
            <div className="flex flex-col items-start gap-2 w-full">
              <h6 className="w-full font-semibold text-gray-900 text-base leading-6">
                Payment
              </h6>
              <p className="w-full text-gray-600 text-sm leading-[22px] font-normal">
                {orderDetails.paymentMethod}
              </p>
            </div>
          </div>
        </div>

        {/* Coupon section */}
        <Card className="w-full bg-green-50 rounded-lg border border-green-100 mb-8">
          <CardContent className="flex flex-col items-center justify-center gap-6 px-8 py-10">
            <div className="flex flex-col items-center gap-3 w-full">
              <h4 className="w-full text-center font-semibold text-gray-900 text-2xl leading-8">
                🎉 Congratulations! 30% off your next purchase!
              </h4>
              <p className="w-full text-center text-gray-600 text-sm leading-[22px] font-normal">
                Use the coupon now or look for it in your personal account.
              </p>
            </div>
            <div className="flex w-full max-w-[500px] gap-2">
              <div className="flex-1 px-4 py-[9px] bg-white rounded-lg border border-gray-200">
                <p className="text-gray-600 text-sm leading-[22px] font-normal">
                  30%SALEOFF
                </p>
              </div>
              <Button className="bg-primarymain text-white rounded-lg hover:bg-primarymain/90">
                Copy coupon
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Footer */}
        <footer className="flex items-center gap-3">
          <p className="text-gray-600 text-sm leading-[22px] font-normal">
            Need help?
          </p>
          <Button
            variant="link"
            className="text-primarymain text-sm font-medium underline p-0 h-auto"
          >
            Contact us
          </Button>
        </footer>
      </div>

      {/* Right section - Recommended products */}
      <div className="flex flex-col w-full md:w-1/2 bg-gray-50 rounded-2xl p-8">
        <div className="w-full">
          <h4 className="text-center mb-8 font-semibold text-gray-900 text-2xl leading-8">
            You may also like
          </h4>

          {/* Product cards */}
          <div className="flex flex-col md:flex-row items-center gap-6 mb-8">
            {recommendedProducts.map((product) => (
              <Card
                key={product.id}
                className="w-full md:w-[306px] bg-white rounded-lg overflow-hidden border-0 shadow-sm"
              >
                <div className="relative flex flex-col items-center justify-center p-6">
                  {product.hasDiscount && (
                    <Badge className="absolute top-4 left-4 bg-dangermain text-white">
                      {product.discount}
                    </Badge>
                  )}
                  <img
                    className="w-full max-w-[258px] h-48 object-contain"
                    alt={product.name}
                    src={product.image}
                  />
                </div>
                <CardContent className="flex flex-col items-start gap-3 pt-0 pb-4 px-4">
                  <div className="flex flex-col items-start gap-2 w-full">
                    <div className="flex items-center gap-2 w-full">
                      <div className="flex items-start gap-1">
                        {renderStars(product.rating)}
                      </div>
                      <p className="flex-1 text-gray-400 text-xs leading-[18px]">
                        ({product.reviews})
                      </p>
                    </div>
                    <p className="font-medium text-gray-900 text-sm leading-5">
                      {product.name}
                    </p>
                  </div>
                  <div className="flex items-center justify-between w-full">
                    <div className="flex items-center gap-2 h-10">
                      <p className="font-semibold text-gray-900 text-xl leading-7">
                        {product.price}
                      </p>
                      {product.originalPrice && (
                        <p className="text-gray-400 text-sm leading-[21px] line-through">
                          {product.originalPrice}
                        </p>
                      )}
                    </div>
                    <Button
                      variant="secondary"
                      size="icon"
                      className="w-10 h-10 p-3 bg-gray-100 rounded-lg"
                    >
                      <ShoppingCartIcon className="w-4 h-4" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Continue shopping button */}
          <Button className="flex w-full items-center justify-center gap-2 px-6 py-3 bg-primarymain text-white rounded-lg hover:bg-primarymain/90">
            Continue shopping
            <ArrowRightIcon className="w-[18px] h-[18px]" />
          </Button>
        </div>
      </div>
    </div>
  );
}; 