import React, { useRef, useEffect } from "react";
import { HeaderByAnima } from "../ElectronicsStore/sections/HeaderByAnima/HeaderByAnima";
import { CtaFooterByAnima } from "../ElectronicsStore/sections/CtaFooterByAnima/CtaFooterByAnima";
import { Badge } from "../../components/ui/badge";
import { Button } from "../../components/ui/button";
import { Card, CardContent } from "../../components/ui/card";
import { Checkbox } from "../../components/ui/Checkbox";
import { Input } from "../../components/ui/input";
import { ChevronRightIcon, ChevronDownIcon, ChevronLeftIcon, ChevronUpIcon, DollarSignIcon, XIcon, FilterIcon } from "lucide-react";
import PaginationComponent from "../../components/ui/pagination";
import { Select } from "../../components/ui/Select";
import { Separator } from "../../components/ui/separator";

// Rename the imported component to maintain compatibility with existing code
const Pagination = PaginationComponent;

export const ShopCatalog = (): JSX.Element => {
  // Pagination and sort
  const [currentPage, setCurrentPage] = React.useState(1);
  const totalPages = 5;
  const sortOptions = [
    { value: "popular", label: "Most popular" },
    { value: "new", label: "Newest" },
    { value: "price_low", label: "Price: Low to High" },
    { value: "price_high", label: "Price: High to Low" },
  ];
  const [sort, setSort] = React.useState(sortOptions[0].value);

  // Mobile responsiveness
  const [mobileFiltersVisible, setMobileFiltersVisible] = React.useState(false);
  const filterButtonRef = useRef<HTMLButtonElement>(null);
  const filtersRef = useRef<HTMLDivElement>(null);

  // Filters state
  const [selectedBrands, setSelectedBrands] = React.useState<string[]>(["Apple"]);
  const [selectedSSD, setSelectedSSD] = React.useState<string[]>(["1 TB"]);
  const [selectedCategories, setSelectedCategories] = React.useState<string[]>([]);
  const [selectedColors, setSelectedColors] = React.useState<string[]>([]);
  const [showAllBrands, setShowAllBrands] = React.useState(false);
  const [minPrice, setMinPrice] = React.useState("340");
  const [maxPrice, setMaxPrice] = React.useState("1250");
  const [filterTags, setFilterTags] = React.useState<string[]>(["Sale", "Asus", "1 TB", "$340 - $1,250"]);
  const [cart, setCart] = React.useState<number[]>([]);

  // Categories data with counts
  const categories = [
    { name: "Smartphones", count: 218 },
    { name: "Accessories", count: 372 },
    { name: "Tablets", count: 110 },
    { name: "Wearable Electronics", count: 142 },
    { name: "Computers & Laptops", count: 205 },
    { name: "Cameras, Photo & Video", count: 78 },
    { name: "Headphones", count: 121 },
    { name: "Video Games", count: 89 },
  ];

  // Brand data with counts
  const brands = [
    { name: "Apple", count: 12 },
    { name: "Asus", count: 47 },
    { name: "Cobra", count: 52 },
    { name: "Dell", count: 48 },
    { name: "Lenovo", count: 112 },
    { name: "2E Gambing", count: 13 },
    { name: "AsRock", count: 35 },
  ];

  // SSD sizes data with counts
  const ssdSizes = [
    { name: "2 TB", count: 13 },
    { name: "1 TB", count: 28 },
    { name: "512 GB", count: 47 },
    { name: "256 GB", count: 56 },
    { name: "128 GB", count: 69 },
    { name: "64 GB or less", count: 141 },
  ];

  // Color options
  const colors = [
    { name: "Green", color: "#8bc4ab" },
    { name: "Coral red", color: "#ee7976" },
    { name: "Light pink", color: "#df8fbf" },
    { name: "Sky blue", color: "#9acbf1" },
    { name: "Black", color: "#364254" },
    { name: "White", color: "transparent" },
  ];

  // Product data
  const products = [
    { id: 1, name: "VRB01 Virtual Reality Glasses", price: "$340.99", oldPrice: "$430.00", rating: 5, reviews: 14, image: "/image-2.png", discount: "-21%" },
    { id: 2, name: "Apple iPhone 14 128GB White", price: "$899.00", rating: 4, reviews: 142, image: "/image-3.png" },
    { id: 3, name: "Smart Watch Series 7, White", price: "$429.00", rating: 5, reviews: 64, image: "/image-17.png" },
    { id: 4, name: "Tablet Apple iPad Air M1", price: "$540.00", rating: 5, reviews: 12, image: "/image-5.png" },
    { id: 5, name: "Headphones Apple AirPods 2 Pro", price: "$224.00", rating: 4, reviews: 78, image: "/image-6.png" },
    { id: 6, name: "Laptop Apple MacBook Pro 13 M2", price: "$1,200.00", rating: 3, reviews: 51, image: "/image-7.png", isNew: true },
    { id: 7, name: "Sony Dualsense Edge Controller", price: "$200.00", rating: 5, reviews: 187, image: "/image-9.png" },
    { id: 8, name: "Tablet Apple iPad Pro M1", price: "$640.00", rating: 4.5, reviews: 49, image: "/image-10.png" },
    { id: 9, name: "Xiaomi Wireless Buds Pro", price: "$156.00", rating: 5, reviews: 142, image: "/image-11.png" },
    { id: 10, name: "Apple iPhone 14 128GB Blue", price: "$899.00", rating: 4.5, reviews: 335, image: "/image-12.png" },
    { id: 11, name: "Wireless Bluetooth Headphones Sony", price: "$299.00", rating: 4, reviews: 136, image: "/image-13.png" },
    { id: 12, name: "VRB01 Camera Nikon Max", price: "$652.00", oldPrice: "$785.00", rating: 5, reviews: 14, image: "/image-15.png", discount: "-17%" },
    { id: 13, name: "Power Bank PBS 10000 mAh Black", price: "$45.00", rating: 4, reviews: 125, image: "/image-16.png" },
    { id: 14, name: "Smart Watch Series 7, White", price: "$429.00", rating: 5, reviews: 64, image: "/image-17.png" },
  ];

  // Handlers
  const handleBrandToggle = (brand: string) => {
    setSelectedBrands((prev) =>
      prev.includes(brand) ? prev.filter((b) => b !== brand) : [...prev, brand]
    );
  };
  const handleSSDToggle = (size: string) => {
    setSelectedSSD((prev) =>
      prev.includes(size) ? prev.filter((s) => s !== size) : [...prev, size]
    );
  };
  const handleCategoryClick = (cat: string) => {
    setSelectedCategories((prev) =>
      prev.includes(cat) ? prev.filter((c) => c !== cat) : [...prev, cat]
    );
  };
  const handleColorClick = (color: string) => {
    setSelectedColors((prev) =>
      prev.includes(color) ? prev.filter((c) => c !== color) : [...prev, color]
    );
  };
  const handlePriceChange = (type: "min" | "max", value: string) => {
    if (type === "min") setMinPrice(value);
    else setMaxPrice(value);
  };
  const handleClearAll = () => {
    setSelectedBrands([]);
    setSelectedSSD([]);
    setSelectedCategories([]);
    setSelectedColors([]);
    setMinPrice("340");
    setMaxPrice("1250");
    setFilterTags([]);
  };
  const handleRemoveTag = (tag: string) => {
    setFilterTags((prev) => prev.filter((t) => t !== tag));
  };
  const handleAddToCart = (id: number) => {
    setCart((prev) => [...prev, id]);
    alert("Added to cart!");
  };

  // Toggle mobile filters
  const toggleMobileFilters = () => {
    setMobileFiltersVisible(prev => !prev);
  };

  // Close filters on outside click
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (
        filtersRef.current &&
        !filtersRef.current.contains(event.target as Node) &&
        filterButtonRef.current &&
        !filterButtonRef.current.contains(event.target as Node)
      ) {
        setMobileFiltersVisible(false);
      }
    }
    if (mobileFiltersVisible) {
      document.addEventListener("mousedown", handleClickOutside);
    } else {
      document.removeEventListener("mousedown", handleClickOutside);
    }
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, [mobileFiltersVisible]);

  // Render star ratings
  const renderStars = (rating: number) => {
    const stars = [];
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 !== 0;
    for (let i = 0; i < fullStars; i++) {
      stars.push(<img key={`full-${i}`} className="w-3 h-3" alt="Star fill" src="/star-fill.svg" />);
    }
    if (hasHalfStar) {
      stars.push(<img key="half" className="w-3 h-3" alt="Star half" src="/star-half.svg" />);
    }
    const emptyStars = 5 - fullStars - (hasHalfStar ? 1 : 0);
    for (let i = 0; i < emptyStars; i++) {
      stars.push(<img key={`empty-${i}`} className="w-3 h-3" alt="Star" src="/star.svg" />);
    }
    return stars;
  };

  return (
    <div className="flex flex-col w-full bg-white-100 min-h-screen">
      <HeaderByAnima showHeroSection={false} />
      <main className="w-full max-w-[1296px] mx-auto px-4 sm:px-6 lg:px-8 mt-6 sm:mt-8 md:mt-10 mb-10 sm:mb-16 md:mb-20">
        {/* Breadcrumb and Title */}
        <div className="pt-4 sm:pt-6 md:pt-8 pb-2 px-0">
          <div className="flex items-center gap-2 text-xs text-gray-500 mb-2">
            <span className="text-gray-700">Home</span>
            <ChevronRightIcon className="w-3.5 h-3.5 text-gray-400" />
            <span className="text-gray-400">Catalog with sidebar filters</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold text-gray-900 leading-9">Shop catalog</h1>
        </div>
        {/* Banners */}
        <div className="flex flex-col md:flex-row gap-4 md:gap-6 mb-6 md:mb-8">
          <div className="relative flex-1 min-w-0 h-48 sm:h-56 rounded-2xl overflow-hidden bg-gradient-to-r from-[#ACCBEE] to-[#E7F0FD] flex items-center">
            <img src="/image.png" alt="iPhone" className="absolute left-0 top-0 h-full w-[55%] object-cover" />
            <div className="absolute left-[56%] top-1/2 -translate-y-1/2 flex flex-col gap-2">
              <h2 className="text-xl sm:text-2xl font-bold text-gray-900">iPhone 14</h2>
              <p className="text-xs sm:text-sm text-gray-700">Apple iPhone 14 128GB Blue</p>
              <Button className="mt-2 bg-primarymain text-white-100 w-fit px-4 sm:px-6 py-2 rounded-lg flex items-center gap-1 text-sm">
                From $899 <ChevronRightIcon className="w-3 h-3 sm:w-4 sm:h-4" />
              </Button>
            </div>
          </div>
          <div className="relative flex-1 min-w-0 h-48 sm:h-56 rounded-2xl overflow-hidden bg-gradient-to-r from-[#FDCBF1] to-[#FFECFA] flex items-center">
            <img src="/image-1.png" alt="iPad" className="absolute left-0 bottom-0 w-full h-[60%] object-contain" />
            <div className="absolute left-1/2 top-8 -translate-x-1/2 flex flex-col items-center w-[70%]">
              <img src="/apple.svg" alt="Apple" className="w-6 h-6 sm:w-8 sm:h-8 mb-1" />
              <p className="text-xs sm:text-sm text-gray-700 mb-1">Deal of the week</p>
              <h2 className="text-xl sm:text-2xl font-bold text-gray-900">iPad Pro M1</h2>
            </div>
          </div>
        </div>
        {/* Filter bar */}
        <div className="flex flex-wrap items-center justify-between mb-4 sm:mb-6 px-0">
          <div className="flex flex-wrap items-center gap-2 md:gap-4 w-full sm:w-auto mb-3 sm:mb-0">
            <span className="text-sm text-gray-900">Found <span className="font-semibold">732</span> items</span>
            <div className="hidden sm:flex flex-wrap items-center gap-2">
              {filterTags.map((tag, index) => (
                <Badge key={index} variant="outline" className="px-3 py-1 bg-gray-100 text-gray-700 rounded-md flex items-center text-xs">
                  <button onClick={() => handleRemoveTag(tag)} className="mr-1"><XIcon className="w-3 h-3" /></button>
                  {tag}
                </Badge>
              ))}
            </div>
            {filterTags.length > 0 && (
              <button className="hidden sm:block text-xs text-gray-700 underline ml-2" onClick={handleClearAll}>Clear all</button>
            )}
            
            {/* Mobile filter button */}
            <Button 
              ref={filterButtonRef}
              variant="outline" 
              size="sm" 
              className="ml-auto sm:hidden flex items-center gap-1"
              onClick={toggleMobileFilters}
            >
              <FilterIcon className="w-4 h-4" />
              <span>Filters</span>
            </Button>
          </div>
          
          <div className="flex items-center gap-2 w-full sm:w-auto justify-between sm:justify-end">
            <span className="text-sm text-gray-900">Sort by:</span>
            <Select
              options={sortOptions}
              value={sort}
              onChange={e => setSort(e.target.value)}
              className="w-[140px] border-none shadow-none text-sm"
            />
          </div>
        </div>
        
        {/* Mobile filter tags row */}
        <div className="flex sm:hidden flex-wrap items-center gap-2 mb-4">
          {filterTags.map((tag, index) => (
            <Badge key={index} variant="outline" className="px-3 py-1 bg-gray-100 text-gray-700 rounded-md flex items-center text-xs">
              <button onClick={() => handleRemoveTag(tag)} className="mr-1"><XIcon className="w-3 h-3" /></button>
              {tag}
            </Badge>
          ))}
          {filterTags.length > 0 && (
            <button className="text-xs text-gray-700 underline" onClick={handleClearAll}>Clear all</button>
          )}
        </div>
        
        {/* Main grid */}
        <div className="flex flex-col lg:flex-row gap-6 lg:gap-8">
          {/* Sidebar for desktop */}
          <aside className="hidden lg:block w-[280px] flex-shrink-0 flex flex-col gap-6">
            {/* Status */}
            <div className="bg-white rounded-xl border border-gray-200 p-5 flex flex-col gap-3">
              <h3 className="text-base font-semibold text-gray-900 mb-2">Status</h3>
              <div className="flex flex-wrap gap-2">
                <Badge variant="outline" className="px-3 py-1 border-[#181d25] text-gray-900 rounded-md flex items-center text-xs"><img className="w-3 h-3 mr-1" alt="Icon" src="/icon-10.svg" />Sale</Badge>
                <Badge variant="outline" className="px-3 py-1 border-gray-200 text-gray-700 rounded-md flex items-center text-xs">Same Day Delivery</Badge>
                <Badge variant="outline" className="px-3 py-1 border-gray-200 text-gray-700 rounded-md flex items-center text-xs">Available to Order</Badge>
              </div>
            </div>
            {/* Categories */}
            <div className="bg-white rounded-xl border border-gray-200 p-5">
              <h3 className="text-base font-semibold text-gray-900 mb-2">Categories</h3>
              <div className="flex flex-col gap-2">
                {categories.map((category, index) => (
                  <button
                    key={index}
                    className={`flex items-center justify-between w-full px-2 py-1 rounded transition text-sm ${selectedCategories.includes(category.name) ? "bg-primary text-white" : "hover:bg-gray-100 text-gray-700"}`}
                    onClick={() => handleCategoryClick(category.name)}
                    type="button"
                  >
                    <span>{category.name}</span>
                    <span className="text-xs text-gray-400">{category.count}</span>
                  </button>
                ))}
              </div>
            </div>
            {/* Price */}
            <div className="bg-white rounded-xl border border-gray-200 p-5">
              <h3 className="text-base font-semibold text-gray-900 mb-2">Price</h3>
              <div className="flex flex-col gap-4">
                <div className="flex items-center gap-2">
                  <span className="text-xs text-gray-500">$</span>
                  <Input value={minPrice} onChange={e => handlePriceChange("min", e.target.value)} className="w-16 h-8 text-xs border-gray-200 rounded" />
                  <span className="text-xs text-gray-500">-</span>
                  <Input value={maxPrice} onChange={e => handlePriceChange("max", e.target.value)} className="w-16 h-8 text-xs border-gray-200 rounded" />
                </div>
                <div className="h-2 w-full bg-gray-200 rounded-full relative mt-2 mb-1">
                  <div className="absolute left-[20%] right-[20%] h-2 bg-primarymain rounded-full" />
                </div>
              </div>
            </div>
            {/* Brand */}
            <div className="bg-white rounded-xl border border-gray-200 p-5">
              <h3 className="text-base font-semibold text-gray-900 mb-2">Brand</h3>
              <div className="flex flex-col gap-2">
                {(showAllBrands ? brands : brands.slice(0, 5)).map((brand, index) => (
                  <label key={index} className="flex items-center gap-2 cursor-pointer text-sm">
                    <Checkbox checked={selectedBrands.includes(brand.name)} onChange={() => handleBrandToggle(brand.name)} />
                    <span>{brand.name}</span>
                    <span className="ml-auto text-xs text-gray-400">{brand.count}</span>
                  </label>
                ))}
                <button className="text-xs text-primary font-medium mt-1" onClick={() => setShowAllBrands(v => !v)}>{showAllBrands ? "Show less" : "Show all"}</button>
              </div>
            </div>
            {/* SSD Size */}
            <div className="bg-white rounded-xl border border-gray-200 p-5">
              <h3 className="text-base font-semibold text-gray-900 mb-2">SSD Size</h3>
              <div className="flex flex-col gap-2">
                {ssdSizes.map((size, index) => (
                  <label key={index} className="flex items-center gap-2 cursor-pointer text-sm">
                    <Checkbox checked={selectedSSD.includes(size.name)} onChange={() => handleSSDToggle(size.name)} />
                    <span>{size.name}</span>
                    <span className="ml-auto text-xs text-gray-400">{size.count}</span>
                  </label>
                ))}
              </div>
            </div>
            {/* Color */}
            <div className="bg-white rounded-xl border border-gray-200 p-5">
              <h3 className="text-base font-semibold text-gray-900 mb-2">Color</h3>
              <div className="flex flex-wrap gap-2">
                {colors.map((color, index) => (
                  <button
                    key={index}
                    className={`flex items-center gap-1 px-2 py-1 rounded-full border ${selectedColors.includes(color.name) ? "border-primary ring-2 ring-primary" : "border-gray-200"}`}
                    onClick={() => handleColorClick(color.name)}
                    type="button"
                  >
                    <span className="w-4 h-4 rounded-full block" style={{ backgroundColor: color.color, border: color.name === "White" ? "1px solid #e0e5eb" : "none" }} />
                    <span className="text-xs text-gray-700">{color.name}</span>
                  </button>
                ))}
              </div>
            </div>
          </aside>
          
          {/* Mobile filters modal */}
          {mobileFiltersVisible && (
            <div className="fixed inset-0 z-50 bg-black/50 lg:hidden">
              <div 
                ref={filtersRef}
                className="absolute top-0 left-0 w-[85%] max-w-sm h-full bg-white overflow-y-auto pb-6"
              >
                <div className="sticky top-0 bg-white p-4 flex items-center justify-between border-b border-gray-200 z-10">
                  <h3 className="text-lg font-semibold">Filters</h3>
                  <Button variant="ghost" size="sm" onClick={toggleMobileFilters}>
                    <XIcon className="w-5 h-5" />
                  </Button>
                </div>
                <div className="p-4 flex flex-col gap-6">
                  {/* Status */}
                  <div className="flex flex-col gap-3">
                    <h3 className="text-base font-semibold text-gray-900">Status</h3>
                    <div className="flex flex-wrap gap-2">
                      <Badge variant="outline" className="px-3 py-1 border-[#181d25] text-gray-900 rounded-md flex items-center text-xs"><img className="w-3 h-3 mr-1" alt="Icon" src="/icon-10.svg" />Sale</Badge>
                      <Badge variant="outline" className="px-3 py-1 border-gray-200 text-gray-700 rounded-md flex items-center text-xs">Same Day Delivery</Badge>
                      <Badge variant="outline" className="px-3 py-1 border-gray-200 text-gray-700 rounded-md flex items-center text-xs">Available to Order</Badge>
                    </div>
                  </div>
                  
                  <Separator />
                  
                  {/* Categories */}
                  <div className="flex flex-col gap-3">
                    <h3 className="text-base font-semibold text-gray-900">Categories</h3>
                    <div className="flex flex-col gap-2">
                      {categories.map((category, index) => (
                        <button
                          key={index}
                          className={`flex items-center justify-between w-full px-2 py-1 rounded transition text-sm ${selectedCategories.includes(category.name) ? "bg-primary text-white" : "hover:bg-gray-100 text-gray-700"}`}
                          onClick={() => handleCategoryClick(category.name)}
                          type="button"
                        >
                          <span>{category.name}</span>
                          <span className="text-xs text-gray-400">{category.count}</span>
                        </button>
                      ))}
                    </div>
                  </div>
                  
                  <Separator />
                  
                  {/* Price */}
                  <div className="flex flex-col gap-3">
                    <h3 className="text-base font-semibold text-gray-900">Price</h3>
                    <div className="flex flex-col gap-4">
                      <div className="flex items-center gap-2">
                        <span className="text-xs text-gray-500">$</span>
                        <Input value={minPrice} onChange={e => handlePriceChange("min", e.target.value)} className="w-16 h-8 text-xs border-gray-200 rounded" />
                        <span className="text-xs text-gray-500">-</span>
                        <Input value={maxPrice} onChange={e => handlePriceChange("max", e.target.value)} className="w-16 h-8 text-xs border-gray-200 rounded" />
                      </div>
                      <div className="h-2 w-full bg-gray-200 rounded-full relative mt-2 mb-1">
                        <div className="absolute left-[20%] right-[20%] h-2 bg-primarymain rounded-full" />
                      </div>
                    </div>
                  </div>
                  
                  <Separator />
                  
                  {/* Brand */}
                  <div className="flex flex-col gap-3">
                    <h3 className="text-base font-semibold text-gray-900">Brand</h3>
                    <div className="flex flex-col gap-2">
                      {(showAllBrands ? brands : brands.slice(0, 5)).map((brand, index) => (
                        <label key={index} className="flex items-center gap-2 cursor-pointer text-sm">
                          <Checkbox checked={selectedBrands.includes(brand.name)} onChange={() => handleBrandToggle(brand.name)} />
                          <span>{brand.name}</span>
                          <span className="ml-auto text-xs text-gray-400">{brand.count}</span>
                        </label>
                      ))}
                      <button className="text-xs text-primary font-medium mt-1" onClick={() => setShowAllBrands(v => !v)}>{showAllBrands ? "Show less" : "Show all"}</button>
                    </div>
                  </div>
                  
                  <Separator />
                  
                  {/* SSD Size */}
                  <div className="flex flex-col gap-3">
                    <h3 className="text-base font-semibold text-gray-900">SSD Size</h3>
                    <div className="flex flex-col gap-2">
                      {ssdSizes.map((size, index) => (
                        <label key={index} className="flex items-center gap-2 cursor-pointer text-sm">
                          <Checkbox checked={selectedSSD.includes(size.name)} onChange={() => handleSSDToggle(size.name)} />
                          <span>{size.name}</span>
                          <span className="ml-auto text-xs text-gray-400">{size.count}</span>
                        </label>
                      ))}
                    </div>
                  </div>
                  
                  <Separator />
                  
                  {/* Color */}
                  <div className="flex flex-col gap-3">
                    <h3 className="text-base font-semibold text-gray-900">Color</h3>
                    <div className="flex flex-wrap gap-2">
                      {colors.map((color, index) => (
                        <button
                          key={index}
                          className={`flex items-center gap-1 px-2 py-1 rounded-full border ${selectedColors.includes(color.name) ? "border-primary ring-2 ring-primary" : "border-gray-200"}`}
                          onClick={() => handleColorClick(color.name)}
                          type="button"
                        >
                          <span className="w-4 h-4 rounded-full block" style={{ backgroundColor: color.color, border: color.name === "White" ? "1px solid #e0e5eb" : "none" }} />
                          <span className="text-xs text-gray-700">{color.name}</span>
                        </button>
                      ))}
                    </div>
                  </div>
                  
                  <div className="flex gap-3 mt-2">
                    <Button className="flex-1 bg-primarymain text-white" onClick={toggleMobileFilters}>
                      Apply filters
                    </Button>
                    <Button variant="outline" className="flex-1" onClick={handleClearAll}>
                      Clear all
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          )}
          
          {/* Product grid and banners */}
          <section className="flex-1 min-w-0">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6 mb-6 sm:mb-8">
              {products.slice(0, 6).map((product, idx) => (
                <Card key={product.id} className="rounded-xl border border-gray-200 bg-white overflow-hidden flex flex-col">
                  <div className="relative flex items-center justify-center h-40 sm:h-48 bg-gray-50">
                    {product.discount && (<Badge className="absolute top-3 left-3 bg-dangermain text-white-100 text-xs px-2 py-1">{product.discount}</Badge>)}
                    {product.isNew && (<Badge className="absolute top-3 left-3 bg-infomain text-white-100 text-xs px-2 py-1">New</Badge>)}
                    <img className="h-28 sm:h-32 object-contain" alt={product.name} src={product.image} />
                  </div>
                  <CardContent className="flex-1 flex flex-col justify-between p-3 sm:p-4">
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <div className="flex items-start gap-1">{renderStars(product.rating)}</div>
                        <span className="text-gray-400 text-xs">({product.reviews})</span>
                      </div>
                      <h3 className="text-gray-900 text-sm font-semibold mb-1 min-h-[38px] line-clamp-2">{product.name}</h3>
                    </div>
                    <div className="flex items-center justify-between mt-2">
                      <div className="flex items-center gap-2">
                        <span className="text-gray-900 text-base sm:text-lg font-bold">{product.price}</span>
                        {product.oldPrice && (<span className="text-gray-400 text-xs line-through">{product.oldPrice}</span>)}
                      </div>
                      <Button variant="ghost" size="icon" className="w-8 h-8 sm:w-9 sm:h-9 p-2 bg-gray-100 rounded-lg" onClick={() => handleAddToCart(product.id)}>
                        <img className="w-4 h-4" alt="Icon" src="/icon-11.svg" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
            
            {/* Sale Banner */}
            <div className="w-full h-auto sm:h-[120px] md:h-[140px] rounded-2xl bg-gradient-to-r from-[#E7F0FD] to-[#ACCBEE] flex flex-col sm:flex-row items-center p-4 sm:px-8 md:px-12 mb-6 sm:mb-8 relative overflow-hidden">
              <div className="flex-1 text-center sm:text-left mb-4 sm:mb-0">
                <h2 className="text-xl sm:text-2xl font-bold text-gray-900 mb-1 sm:mb-2">SEASONAL WEEKLY SALE 2024</h2>
                <p className="text-base sm:text-lg text-gray-800">Use code <span className="bg-white px-2 py-1 rounded-full font-semibold">Sale 2024</span> to get best offer</p>
              </div>
              <img src="/image-8.png" alt="Banner" className="h-[80px] sm:h-[100px] md:h-[120px] w-auto sm:absolute sm:right-8 md:right-12 sm:bottom-0 object-contain" />
            </div>
            
            {/* More products */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6 mb-6 sm:mb-8">
              {products.slice(6).map((product, idx) => (
                <Card key={product.id} className="rounded-xl border border-gray-200 bg-white overflow-hidden flex flex-col">
                  <div className="relative flex items-center justify-center h-40 sm:h-48 bg-gray-50">
                    {product.discount && (<Badge className="absolute top-3 left-3 bg-dangermain text-white-100 text-xs px-2 py-1">{product.discount}</Badge>)}
                    {product.isNew && (<Badge className="absolute top-3 left-3 bg-infomain text-white-100 text-xs px-2 py-1">New</Badge>)}
                    <img className="h-28 sm:h-32 object-contain" alt={product.name} src={product.image} />
                  </div>
                  <CardContent className="flex-1 flex flex-col justify-between p-3 sm:p-4">
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <div className="flex items-start gap-1">{renderStars(product.rating)}</div>
                        <span className="text-gray-400 text-xs">({product.reviews})</span>
                      </div>
                      <h3 className="text-gray-900 text-sm font-semibold mb-1 min-h-[38px] line-clamp-2">{product.name}</h3>
                    </div>
                    <div className="flex items-center justify-between mt-2">
                      <div className="flex items-center gap-2">
                        <span className="text-gray-900 text-base sm:text-lg font-bold">{product.price}</span>
                        {product.oldPrice && (<span className="text-gray-400 text-xs line-through">{product.oldPrice}</span>)}
                      </div>
                      <Button variant="ghost" size="icon" className="w-8 h-8 sm:w-9 sm:h-9 p-2 bg-gray-100 rounded-lg" onClick={() => handleAddToCart(product.id)}>
                        <img className="w-4 h-4" alt="Icon" src="/icon-11.svg" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
            
            {/* Pagination */}
            <div className="flex justify-center mt-6 sm:mt-8">
              <Pagination currentPage={currentPage} totalPages={16} onPageChange={setCurrentPage} />
            </div>
          </section>
        </div>
      </main>
      <CtaFooterByAnima />
    </div>
  );
}; 