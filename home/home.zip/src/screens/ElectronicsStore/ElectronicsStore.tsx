import { ChevronRightIcon } from "lucide-react";
import React from "react";
import { Button } from "../../components/ui/button";
import { Card, CardContent } from "../../components/ui/card";
import { BenefitsByAnima } from "./sections/BenefitsByAnima";
import { CtaFooterByAnima } from "./sections/CtaFooterByAnima";
import { HeaderByAnima } from "./sections/HeaderByAnima/HeaderByAnima";
import { NewArrivalsByAnima } from "./sections/NewArrivalsByAnima/NewArrivalsByAnima";
import { SpecialOffersByAnima } from "./sections/SpecialOffersByAnima/SpecialOffersByAnima";
import { TrendingProductsByAnima } from "./sections/TrendingProductsByAnima/TrendingProductsByAnima";

export const ElectronicsStore = (): JSX.Element => {
  // Brand logos data for mapping
  const brands = [
    { name: "Vector", src: "/vector.svg", hasImage: true },
    { name: "Motorola", src: "/motorola.svg", hasImage: true },
    { name: "Canon", src: "/canon.svg", hasImage: true },
    { name: "Samsung", src: "/samsung.svg", hasImage: true },
    { name: "Sony", src: "/sony.svg", hasImage: true },
    { name: "All brands", src: "/icon-18.svg", hasImage: false },
  ];

  return (
    <div className="flex flex-col w-full bg-white-100">
      <HeaderByAnima />
      <div className="w-full max-w-[1296px] mx-auto px-4 sm:px-6 flex flex-col gap-8 sm:gap-12">
        <div className="mt-4 sm:mt-8">
          <BenefitsByAnima />
        </div>
        <div className="mt-8 sm:mt-12">
          <NewArrivalsByAnima />
        </div>
        <div className="mt-8 sm:mt-12">
          <TrendingProductsByAnima />
        </div>
        <div className="mt-8 sm:mt-12">
          <section className="pt-3 mt-2 md:mt-3 lg:mt-4 w-full">
            <div className="flex flex-col md:flex-row w-full">
              <div className="mb-3 md:mb-0 md:w-1/4">
                <div className="relative flex flex-col items-center justify-center h-full py-3">
                  <div className="absolute top-0 start-0 w-full h-full hidden md:block">
                    <span className="absolute top-0 start-0 w-full h-full rounded-2xl dark:hidden" style={{backgroundColor: "rgb(172, 203, 238)"}}></span>
                    <span className="absolute top-0 start-0 w-full h-full rounded-2xl hidden dark:block" style={{backgroundColor: "rgb(27, 39, 58)"}}></span>
                  </div>
                  <div className="absolute top-0 start-0 w-full h-full md:hidden">
                    <span className="absolute top-0 start-0 w-full h-full rounded-t-2xl dark:hidden" style={{background: "linear-gradient(90deg, rgb(172, 203, 238) 0%, rgb(231, 240, 253) 100%)"}}></span>
                    <span className="absolute top-0 start-0 w-full h-full rounded-t-2xl hidden dark:block" style={{background: "linear-gradient(90deg, rgb(27, 39, 58) 0%, rgb(31, 38, 50) 100%)"}}></span>
                  </div>
                  <div className="relative z-10 text-5xl font-bold text-gray-900 dark:text-gray-100 text-nowrap mb-0">20
                    <span className="inline-block ml-1">
                      <span className="block text-2xl">%</span>
                      <span className="block text-base">OFF</span>
                    </span>
                  </div>
                </div>
              </div>
              <div className="relative md:w-3/4">
                <div className="absolute top-0 start-0 h-full overflow-hidden rounded-full z-10 hidden md:block" style={{color: "var(--cz-body-bg)", marginLeft: "-2px"}}>
                  <svg width="4" height="180" viewBox="0 0 4 180" xmlns="http://www.w3.org/2000/svg">
                    <path d="M2 0L1.99998 180" stroke="currentColor" strokeWidth="3" strokeDasharray="8 12" strokeLinecap="round"></path>
                  </svg>
                </div>
                <div className="relative">
                  <span className="absolute top-0 start-0 w-full h-full rounded-2xl dark:hidden" style={{background: "linear-gradient(90deg, rgb(172, 203, 238) 0%, rgb(231, 240, 253) 100%)"}}></span>
                  <span className="absolute top-0 start-0 w-full h-full rounded-2xl hidden dark:block" style={{background: "linear-gradient(90deg, rgb(27, 39, 58) 0%, rgb(31, 38, 50) 100%)"}}></span>
                  <div className="flex flex-col md:flex-row items-center relative z-10">
                    <div className="mb-2 md:mb-0 md:w-1/2">
                      <div className="text-center md:text-start py-3 px-4 md:ps-5 md:pe-0 md:me-[-20px]">
                        <h3 className="uppercase font-bold md:ps-3 pb-1 mb-1 text-gray-900 dark:text-gray-100 text-lg md:text-xl">Seasonal weekly sale 2024</h3>
                        <p className="text-gray-700 dark:text-gray-300 md:ps-3 mb-0 text-sm md:text-base">Use code <span className="inline-block font-semibold bg-white text-gray-900 rounded-full py-0.5 px-2">Sale 2024</span> to get best offer</p>
                      </div>
                    </div>
                    <div className="flex justify-center md:justify-end pb-3 md:pb-0 md:w-1/2">
                      <div className="md:me-4">
                        <div className="w-full" style={{maxWidth: "320px"}}>
                          <img alt="Camera" loading="lazy" width="640" height="384" className="block h-auto max-h-[140px] md:max-h-[160px] object-contain" src="/image-1.png" />
                        </div>
                        <div className="hidden lg:block" style={{marginBottom: "-5%"}}></div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="hidden lg:block" style={{paddingBottom: "1%"}}></div>
          </section>
        </div>
        <div className="mt-8 sm:mt-12">
          <SpecialOffersByAnima />
        </div>
        {/* Brands section */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3 sm:gap-6 pb-8 sm:pb-12 mt-8 sm:mt-12">
          {brands.map((brand, index) => (
            <Card
              key={index}
              className="h-24 sm:h-28 rounded-xl overflow-hidden border border-solid border-[#e0e5eb]"
            >
              <CardContent className="p-0 h-full flex items-center justify-center">
                {brand.hasImage ? (
                  <img
                    className="w-[120px] sm:w-[164px] h-16 sm:h-20 object-contain"
                    alt={brand.name}
                    src={brand.src}
                  />
                ) : (
                  <Button variant="ghost" className="flex items-center gap-1.5">
                    <span className="font-navigation-nav-link-small font-[number:var(--navigation-nav-link-small-font-weight)] text-gray-700 text-[length:var(--navigation-nav-link-small-font-size)] tracking-[var(--navigation-nav-link-small-letter-spacing)] leading-[var(--navigation-nav-link-small-line-height)]">
                      All brands
                    </span>
                    <ChevronRightIcon className="w-4 h-4" />
                  </Button>
                )}
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
      <CtaFooterByAnima />
    </div>
  );
};
