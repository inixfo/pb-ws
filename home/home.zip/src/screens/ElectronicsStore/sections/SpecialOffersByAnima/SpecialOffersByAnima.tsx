import { ChevronLeftIcon, ChevronRightIcon, ShoppingCartIcon, StarIcon } from "lucide-react";
import React, { useRef } from "react";
import { Badge } from "../../../../components/ui/badge";
import { Button } from "../../../../components/ui/button";
import { Card, CardContent } from "../../../../components/ui/card";
import { Separator } from "../../../../components/ui/separator";
// Import Swiper React components
import { Swiper, SwiperSlide } from 'swiper/react';
// Import Swiper styles
import 'swiper/css';
import 'swiper/css/navigation';
// Import required modules
import { Navigation } from 'swiper/modules';
import type { SwiperRef } from 'swiper/react';

// Product data for mapping
const products = [
  {
    id: 1,
    name: "Xiaomi Wireless Buds Pro",
    image: "/image-19.png",
    currentPrice: "$129.99",
    originalPrice: "$156.00",
    rating: 5,
    reviews: 14,
    available: 112,
    progress: 25, // percentage of progress bar filled
  },
  {
    id: 2,
    name: "Smart Watch Series 7, White",
    image: "/image-20.png",
    currentPrice: "$429.00",
    originalPrice: "$486.00",
    rating: 5,
    reviews: 142,
    available: 45,
    progress: 50,
  },
  {
    id: 3,
    name: "VRB01 Camera Nikon Max",
    image: "/image-21.png",
    currentPrice: "$652.00",
    originalPrice: "$785.00",
    rating: 4,
    reviews: 64,
    available: 13,
    progress: 25,
  },
  {
    id: 4,
    name: "Apple iPhone 14 128GB Blue",
    image: "/image-22.png",
    currentPrice: "$899.00",
    originalPrice: "$967.00",
    rating: 3,
    reviews: 51,
    available: 7,
    progress: 25,
  },
];

export const SpecialOffersByAnima = (): JSX.Element => {
  // Reference to Swiper instance
  const swiperRef = useRef<SwiperRef>(null);

  // Render star ratings based on the rating value
  const renderStars = (rating: number) => {
    return Array(5)
      .fill(0)
      .map((_, index) => (
        <StarIcon
          key={index}
          className={`w-3 h-3 ${
            index < rating
              ? "fill-primarymain text-primarymain"
              : "text-gray-200"
          }`}
        />
      ));
  };

  return (
    <section className="flex flex-col items-start gap-6 w-full">
      <div className="flex flex-col w-full items-start gap-6">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between w-full gap-4 sm:gap-0">
          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4 sm:gap-8">
            <h3 className="font-heading-desktop-h3 text-gray-900 text-xl sm:text-[28px] leading-[36px] font-semibold">
              Special offers for you
            </h3>

            <div className="flex items-center gap-2">
              <Badge className="bg-primarymain rounded-md px-0.5 py-2">
                <span className="w-7 sm:w-9 text-white-100 text-center text-sm sm:text-base font-navigation-nav-link-small">
                  12d
                </span>
              </Badge>

              <span className="font-navigation-nav-link-regular text-gray-400 text-center">
                :
              </span>

              <Badge className="bg-primarymain rounded-md px-0.5 py-2">
                <span className="w-7 sm:w-9 text-white-100 text-center text-sm sm:text-base font-navigation-nav-link-small">
                  10h
                </span>
              </Badge>

              <span className="font-navigation-nav-link-regular text-gray-400 text-center">
                :
              </span>

              <Badge className="bg-primarymain rounded-md px-0.5 py-2">
                <span className="w-7 sm:w-9 text-white-100 text-center text-sm sm:text-base font-navigation-nav-link-small">
                  12m
                </span>
              </Badge>
            </div>
          </div>

          <Button variant="ghost" className="flex items-center gap-1.5 py-2.5">
            <span className="font-navigation-nav-link-small text-gray-800">
              View all
            </span>
            <ChevronRightIcon className="w-4 h-4" />
          </Button>
        </div>

        <Separator className="w-full" />
      </div>

      <div className="w-full relative">
        <Swiper
          ref={swiperRef}
          slidesPerView={2}
          spaceBetween={12}
          modules={[Navigation]}
          breakpoints={{
            640: {
              slidesPerView: 2,
              spaceBetween: 20,
            },
            768: {
              slidesPerView: 3,
              spaceBetween: 24,
            },
            1024: {
              slidesPerView: 4,
              spaceBetween: 24,
            },
          }}
          className="special-offers-swiper"
        >
          {products.map((product) => (
            <SwiperSlide key={product.id}>
              <Card
                className="flex flex-col items-start bg-white-100 rounded-lg overflow-hidden h-full"
              >
                <div className="flex items-center justify-center p-3 sm:p-6 w-full">
                  <img
                    className="w-full sm:w-[258px] h-32 sm:h-60 object-contain"
                    alt={product.name}
                    src={product.image}
                  />
                </div>

                <CardContent className="flex flex-col items-start gap-2 sm:gap-3 pt-0 pb-3 sm:pb-4 px-2 sm:px-4 w-full">
                  <div className="flex flex-col items-start gap-1 sm:gap-2 w-full">
                    <div className="flex items-center gap-1 sm:gap-2 w-full">
                      <div className="flex gap-0.5 sm:gap-1">
                        {renderStars(product.rating)}
                      </div>
                      <span className="flex-1 font-body-extra-small text-gray-400 text-[10px] sm:text-[12px] leading-[18px]">
                        ({product.reviews})
                      </span>
                    </div>

                    <h4 className="font-navigation-nav-link-small text-gray-900 text-xs sm:text-[14px] leading-tight sm:leading-[20px] line-clamp-2">
                      {product.name}
                    </h4>
                  </div>

                  <div className="flex items-center justify-between w-full">
                    <div className="flex items-center gap-1 sm:gap-2">
                      <span className="font-heading-desktop-h5 text-gray-900 text-sm sm:text-[20px] leading-[28px] font-semibold">
                        {product.currentPrice}
                      </span>
                      <span className="font-normal text-gray-400 text-xs sm:text-sm line-through">
                        {product.originalPrice}
                      </span>
                    </div>

                    <Button
                      variant="secondary"
                      size="icon"
                      className="w-7 h-7 sm:w-10 sm:h-10 p-1.5 sm:p-3 bg-gray-100 rounded-lg"
                    >
                      <ShoppingCartIcon className="w-3 h-3 sm:w-4 sm:h-4" />
                    </Button>
                  </div>

                  <div className="flex flex-col h-[30px] sm:h-[34px] gap-1 sm:gap-2 w-full">
                    <div className="w-full bg-gray-100 h-1 rounded-[100px] relative">
                      <div
                        className="h-1 bg-primarymain rounded-[100px]"
                        style={{ width: `${product.progress}%` }}
                      />
                    </div>

                    <div className="flex items-center gap-1 w-full">
                      <span className="font-normal text-gray-500 text-xs sm:text-sm">
                        Available:
                      </span>
                      <span className="font-navigation-nav-link-small text-gray-900 text-xs sm:text-[14px] leading-[20px]">
                        {product.available}
                      </span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </SwiperSlide>
          ))}
        </Swiper>
        
        {/* Navigation arrows matching the Hero section style - visible on all screen sizes */}
        <button 
          className="absolute left-1 sm:left-4 top-[30%] sm:top-1/2 -translate-y-1/2 bg-white/80 hover:bg-white rounded-full p-1.5 sm:p-2 shadow-md z-20"
          onClick={() => swiperRef.current?.swiper.slidePrev()}
        >
          <ChevronLeftIcon className="w-4 sm:w-5 h-4 sm:h-5" />
        </button>
        <button 
          className="absolute right-1 sm:right-4 top-[30%] sm:top-1/2 -translate-y-1/2 bg-white/80 hover:bg-white rounded-full p-1.5 sm:p-2 shadow-md z-20"
          onClick={() => swiperRef.current?.swiper.slideNext()}
        >
          <ChevronRightIcon className="w-4 sm:w-5 h-4 sm:h-5" />
        </button>
      </div>
    </section>
  );
};
