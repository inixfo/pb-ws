import { ChevronRightIcon, ShoppingCartIcon, StarIcon } from "lucide-react";
import React from "react";
import { Badge } from "../../../../components/ui/badge";
import { Button } from "../../../../components/ui/button";
import { Card, CardContent } from "../../../../components/ui/card";
import { Separator } from "../../../../components/ui/separator";

// Product data for mapping
const products = [
  {
    id: 1,
    name: "VRB01 Virtual Reality Glasses",
    price: "$340.99",
    originalPrice: "$430.00",
    rating: 5,
    reviews: 14,
    image: "/image-10.png",
    badge: { text: "-21%", type: "danger" },
  },
  {
    id: 2,
    name: "Apple iPhone 14 128GB White",
    price: "$899.00",
    rating: 4,
    reviews: 142,
    image: "/image-11.png",
  },
  {
    id: 3,
    name: "Smart Watch Series 7, White",
    price: "$429.00",
    rating: 5,
    reviews: 64,
    image: "/image-20.png",
  },
  {
    id: 4,
    name: "Laptop Apple MacBook Pro 13 M2",
    price: "$1,200.00",
    rating: 3,
    reviews: 51,
    image: "/image-13.png",
    badge: { text: "New", type: "info" },
  },
  {
    id: 5,
    name: "Tablet Apple iPad Air M1",
    price: "$540.00",
    rating: 5,
    reviews: 12,
    image: "/image-14.png",
  },
  {
    id: 6,
    name: "Headphones Apple AirPods 2 Pro",
    price: "$224.00",
    rating: 4,
    reviews: 78,
    image: "/image-15.png",
  },
  {
    id: 7,
    name: "Tablet Apple iPad Pro M1",
    price: "$640.00",
    rating: 5,
    reviews: 48,
    image: "/image-16.png",
  },
  {
    id: 8,
    name: "Wireless Bluetooth Headphones Sony",
    price: "$299.00",
    rating: 4,
    reviews: 136,
    image: "/image-17.png",
  },
];

export const TrendingProductsByAnima = (): JSX.Element => {
  // Function to render star ratings
  const renderStars = (rating: number) => {
    return Array(5)
      .fill(0)
      .map((_, index) => (
        <StarIcon
          key={index}
          className={`w-3 h-3 ${
            index < rating ? "fill-current text-yellow-500" : "text-gray-300"
          }`}
        />
      ));
  };

  return (
    <section className="flex flex-col gap-6 w-full">
      <header className="w-full">
        <div className="flex items-center justify-between mb-6">
          <h2 className="font-heading-desktop-h3 text-gray-900 text-[length:var(--heading-desktop-h3-font-size)] leading-[var(--heading-desktop-h3-line-height)] tracking-[var(--heading-desktop-h3-letter-spacing)]">
            Trending products
          </h2>

          <Button
            variant="ghost"
            className="flex items-center gap-1.5 py-2.5 px-0"
          >
            <span className="font-navigation-nav-link-small text-gray-800 text-[length:var(--navigation-nav-link-small-font-size)] tracking-[var(--navigation-nav-link-small-letter-spacing)] leading-[var(--navigation-nav-link-small-line-height)]">
              View all
            </span>
            <ChevronRightIcon className="w-4 h-4" />
          </Button>
        </div>
        <Separator className="w-full" />
      </header>

      <div className="grid grid-cols-2 md:grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-6">
        {products.map((product) => (
          <Card key={product.id} className="rounded-lg overflow-hidden">
            <div className="relative flex items-center justify-center p-3 sm:p-6 bg-white-100">
              {product.badge && (
                <Badge
                  className={`absolute top-2 sm:top-4 left-2 sm:left-4 ${
                    product.badge.type === "danger"
                      ? "bg-dangermain"
                      : "bg-infomain"
                  } text-white-100 text-xs sm:text-sm`}
                >
                  {product.badge.text}
                </Badge>
              )}
              <img
                src={product.image}
                alt={product.name}
                className="w-full h-[100px] sm:w-[258px] sm:h-60 object-contain"
              />
            </div>
            <CardContent className="flex flex-col gap-2 sm:gap-3 p-2 sm:p-4 bg-white-100">
              <div className="flex flex-col gap-1 sm:gap-2">
                <div className="flex items-center gap-1 sm:gap-2">
                  <div className="flex gap-0.5 sm:gap-1">
                    {renderStars(product.rating)}
                  </div>
                  <span className="text-gray-400 text-[10px] sm:text-xs font-body-extra-small sm:text-[length:var(--body-extra-small-font-size)] tracking-[var(--body-extra-small-letter-spacing)] leading-[var(--body-extra-small-line-height)]">
                    ({product.reviews})
                  </span>
                </div>
                <h3 className="font-navigation-nav-link-small text-gray-900 text-xs sm:text-[length:var(--navigation-nav-link-small-font-size)] leading-tight sm:leading-[var(--navigation-nav-link-small-line-height)] tracking-[var(--navigation-nav-link-small-letter-spacing)] line-clamp-2">
                  {product.name}
                </h3>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-1 sm:gap-2">
                  <span className="font-heading-desktop-h5 text-gray-900 text-sm sm:text-[length:var(--heading-desktop-h5-font-size)] tracking-[var(--heading-desktop-h5-letter-spacing)] leading-[var(--heading-desktop-h5-line-height)]">
                    {product.price}
                  </span>
                  {product.originalPrice && (
                    <span className="font-normal text-gray-400 text-xs sm:text-sm line-through">
                      {product.originalPrice}
                    </span>
                  )}
                </div>
                <Button
                  size="icon"
                  variant="ghost"
                  className="w-8 h-8 sm:w-10 sm:h-10 p-2 sm:p-3 bg-gray-100 rounded-lg"
                >
                  <ShoppingCartIcon className="w-3 h-3 sm:w-4 sm:h-4" />
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </section>
  );
};
