import { ArrowRightIcon, StarIcon } from "lucide-react";
import React from "react";
import { Button } from "../../../../components/ui/button";
import { Card, CardContent } from "../../../../components/ui/card";

// Product data for the middle column
const middleColumnProducts = [
  {
    id: 1,
    name: "Smart Watch Series 7, White",
    price: "$449.00",
    rating: 5,
    reviews: 45,
    image: "/image-2.png",
  },
  {
    id: 2,
    name: "VRB01 Virtual Reality Glasses",
    price: "$340.99",
    rating: 4,
    reviews: 123,
    image: "/image-3.png",
  },
  {
    id: 3,
    name: "Wireless Bluetooth Headphones Sony",
    price: "$357.00",
    rating: 4,
    reviews: 34,
    image: "/image-4.png",
  },
  {
    id: 4,
    name: "Laptop Apple MacBook Pro 13 M2",
    price: "$1,200.00",
    rating: 5,
    reviews: 8,
    image: "/image-5.png",
  },
];

// Product data for the right column
const rightColumnProducts = [
  {
    id: 1,
    name: "Tablet Apple iPad Air M1",
    price: "$540.00",
    rating: 3,
    reviews: 126,
    image: "/image-6.png",
  },
  {
    id: 2,
    name: "Headphones Apple AirPods 2 Pro",
    price: "$209.99",
    originalPrice: "$356.00",
    rating: 5,
    reviews: 340,
    image: "/image-7.png",
  },
  {
    id: 3,
    name: "Power Bank PBS 10000 mAh Black",
    price: "$49.99",
    rating: 4,
    reviews: 29,
    image: "/image-8.png",
  },
  {
    id: 4,
    name: "Apple iPhone 14 128GB White",
    price: "$899.00",
    originalPrice: "$956.00",
    rating: 5,
    reviews: 12,
    image: "/image-9.png",
  },
];

export const NewArrivalsByAnima = (): JSX.Element => {
  // Function to render star ratings
  const renderStars = (rating: number) => {
    return Array(5)
      .fill(0)
      .map((_, index) => (
        <StarIcon
          key={index}
          className={`w-3 h-3 ${index < rating ? "fill-current text-primarymain" : "text-gray-300"}`}
        />
      ));
  };

  // Function to render product cards
  const renderProductCard = (product: any) => (
    <Card className="flex items-center gap-4 w-full bg-white-100 rounded-lg border-0 shadow-none">
      <CardContent className="p-0">
        <div className="flex items-center gap-4 w-full">
          <div
            className="w-[80px] h-[80px] sm:w-[110px] sm:h-[110px] rounded"
            style={{
              backgroundImage: `url(${product.image})`,
              backgroundSize: "cover",
              backgroundPosition: "center",
            }}
          />
          <div className="flex flex-col items-start gap-1 sm:gap-2 flex-1">
            <div className="flex items-center gap-2 w-full">
              <div className="flex items-start gap-1">
                {renderStars(product.rating)}
              </div>
              <div className="flex-1 mt-[-1px] font-body-extra-small text-gray-400 text-[10px] sm:text-[12px] leading-[16px] sm:leading-[18px]">
                {product.reviews}
              </div>
            </div>
            <div className="w-full font-medium text-xs sm:text-sm text-gray-900 line-clamp-2">
              {product.name}
            </div>
            <div className="flex h-5 sm:h-7 items-center gap-2 w-full">
              <div className="font-semibold text-base sm:text-lg text-gray-900 whitespace-nowrap">
                {product.price}
              </div>
              {product.originalPrice && (
                <div className="flex-1 font-normal text-xs sm:text-sm text-gray-400 line-through">
                  {product.originalPrice}
                </div>
              )}
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );

  return (
    <section className="flex flex-col w-full items-start gap-6 sm:gap-8">
      <h2 className="w-full font-semibold text-xl sm:text-2xl md:text-[28px] text-gray-900 leading-tight sm:leading-[36px]">
        New arrivals
      </h2>

      <div className="flex flex-col lg:flex-row items-start gap-6 w-full">
        {/* Featured MacBook Card */}
        <Card className="w-full lg:w-[380px] h-[300px] sm:h-[400px] md:h-[480px] bg-[#243042] rounded-2xl overflow-hidden border-0">
          <CardContent className="p-0 h-full">
            <div className="relative h-full flex flex-col items-center justify-center bg-[url(/background.png)] bg-cover">
              <div className="absolute w-[220px] sm:w-[280px] md:w-[320px] h-[230px] sm:h-[280px] md:h-[320px] top-[20px] sm:top-[30px] md:top-[30px] left-1/2 transform -translate-x-1/2">
                <div className="absolute top-[180px] sm:top-[220px] md:top-[240px] left-1/2 transform -translate-x-1/2 font-bold text-4xl sm:text-5xl md:text-6xl text-white-100 leading-tight sm:leading-tight md:leading-tight whitespace-nowrap text-center">
                  MacBook
                </div>
                <img
                  className="absolute w-[200px] sm:w-[240px] md:w-[280px] h-[210px] sm:h-[240px] md:h-[280px] top-0 left-1/2 transform -translate-x-1/2 object-contain"
                  alt="MacBook"
                  src="/image-1.png"
                />
              </div>
              <div className="absolute top-[240px] sm:top-[320px] md:top-[360px] left-1/2 transform -translate-x-1/2 font-medium text-sm sm:text-base text-gray-300 whitespace-nowrap text-center">
                Be Pro Anywhere
              </div>
              <Button className="absolute top-[270px] sm:top-[360px] md:top-[400px] left-1/2 transform -translate-x-1/2 bg-primarymain hover:bg-primarymain/90 text-white-100 rounded-md text-xs sm:text-sm">
                <span>
                  From $1,199
                </span>
                <ArrowRightIcon className="ml-1.5 w-3 h-3 sm:w-3.5 sm:h-3.5" />
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Product Columns - Stack on mobile, side by side on larger screens */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-6 w-full">
        {/* Middle Column Products */}
          <div className="flex flex-col items-start gap-4">
          {middleColumnProducts.map((product) => (
            <div key={product.id} className="w-full">
              {renderProductCard(product)}
            </div>
          ))}
        </div>

        {/* Right Column Products */}
          <div className="flex flex-col items-start gap-4">
          {rightColumnProducts.map((product) => (
            <div key={product.id} className="w-full">
              {renderProductCard(product)}
            </div>
          ))}
          </div>
        </div>
      </div>
    </section>
  );
};
