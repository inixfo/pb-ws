import React from "react";
import { Button } from "../../../../components/ui/button";
import { Card, CardContent } from "../../../../components/ui/card";
import { Input } from "../../../../components/ui/input";
import { Separator } from "../../../../components/ui/separator";

// Card logo components to prevent duplicate rendering
const VisaLogo = () => (
  <svg xmlns="http://www.w3.org/2000/svg" width="46" height="20" viewBox="0 0 70 32" fill="none">
    <path d="M26.513 21.5823H20.9834L24.2603 7.1377H29.7899L26.513 21.5823Z" fill="#00579F"/>
    <path d="M47.8039 7.3677C46.7679 6.9777 45.0159 6.5477 42.8899 6.5477C37.4999 6.5477 33.7839 9.2977 33.7639 13.1477C33.7239 16.0177 36.3839 17.6277 38.3659 18.6277C40.3879 19.6477 41.0099 20.3077 41.0099 21.1977C40.9899 22.5777 39.2579 23.2177 37.6459 23.2177C35.4199 23.2177 34.2239 22.9077 32.4129 22.1577L31.6969 21.8577L30.9299 26.4577C32.1659 26.9877 34.5139 27.4577 36.9799 27.4777C42.7299 27.4777 46.3859 24.7677 46.4259 20.6377C46.4459 18.3177 45.0159 16.5277 42.0139 15.0477C40.1829 14.0877 39.0179 13.4277 39.0179 12.4877C39.0379 11.6377 40.0079 10.7677 42.0939 10.7677C43.7869 10.7277 45.0559 11.1177 46.0719 11.5077L46.5719 11.7177L47.3079 7.4277L47.8039 7.3677Z" fill="#00579F"/>
    <path d="M55.2598 17.3177C55.7598 16.1577 57.6098 11.4477 57.6098 11.4477C57.5898 11.4877 58.0898 10.1277 58.3898 9.2777L58.8098 11.2577C58.8098 11.2577 59.9258 16.3477 60.1658 17.3177C59.4458 17.3177 56.2798 17.3177 55.2598 17.3177ZM63.0158 7.1377H59.0298C57.7738 7.1377 56.8338 7.5077 56.2798 8.8477L48.1299 27.1377H53.9798C53.9798 27.1377 54.9798 24.5277 55.1998 23.9277C55.7798 23.9277 61.3358 23.9277 62.0758 23.9277C62.2358 24.6677 62.7558 27.1377 62.7558 27.1377H67.9858L63.0158 7.1377Z" fill="#00579F"/>
    <path d="M18.8499 7.1377L13.4199 21.3577L12.8999 18.8577C11.9999 15.9677 9.07993 12.8577 5.87993 11.1577L10.8799 27.1177H16.7699L24.9199 7.1377H18.8499Z" fill="#00579F"/>
    <path d="M8.62987 7.1377H0.129866L0.00986633 7.5477C6.95987 9.3377 11.6799 13.7777 13.6399 18.8577L11.6999 8.8677C11.3399 7.5277 10.0899 7.1577 8.62987 7.1377Z" fill="#FAA61A"/>
  </svg>
);

export const CtaFooterByAnima = (): JSX.Element => {
  // Video content data
  const videoItems = [
    {
      image: "/image-23.png",
      duration: "6:16",
      title: "5 New Cool Gadgets You Must See on Cartzilla - Cheap Budget",
    },
    {
      image: "/image-24.png",
      duration: "10:20",
      title: "5 Super Useful Gadgets on Cartzilla You Must Have in 2023",
    },
    {
      image: "/image-25.png",
      duration: "8:40",
      title: "Top 5 New Amazing Gadgets on Cartzilla You Must See",
    },
  ];

  // Social media icons
  const socialIcons = [
    { src: "/icon-19.svg", alt: "Icon" },
    { src: "/icon-17.svg", alt: "Icon" },
    { src: "/icon-20.svg", alt: "Icon" },
    { src: "/icon-21.svg", alt: "Icon" },
  ];

  // Footer links data
  const footerLinks = {
    company: ["About company", "Our team", "Careers", "Contact us", "News"],
    account: [
      "Your account",
      "Shipping rates & policies",
      "Refunds & replacements",
      "Delivery info",
      "Order tracking",
      "Taxes & fees",
    ],
    customerService: [
      "Payment methods",
      "Money back guarantee",
      "Product returns",
      "Support center",
      "Shipping",
      "Term and conditions",
    ],
  };

  // Product categories
  const productCategories = [
    [
      "Computers",
      "Smartphones",
      "TV, Video",
      "Speakers",
      "Cameras",
      "Printers",
      "Video Games",
      "Headphones",
      "Wearable",
      "HDD/SSD",
      "Smart Home",
      "Apple Devices",
      "Tablets",
    ],
    [
      "Monitors",
      "Scanners",
      "Servers",
      "Heating and Cooling",
      "E-readers",
      "Data Storage",
      "Networking",
      "Power Strips",
      "Plugs and Outlets",
      "Detectors and Sensors",
      "Accessories",
    ],
  ];

  return (
    <footer className="flex flex-col w-full">
      {/* Newsletter Section */}
      <section className="w-full py-12 md:py-16 lg:py-24 px-4 md:px-8 lg:px-16 bg-gray-50">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row gap-8 md:gap-16 lg:gap-24">
          {/* Newsletter Subscription */}
          <div className="flex flex-col gap-8 md:gap-12 flex-1">
            <div className="flex flex-col gap-6 md:gap-8 max-w-xl">
              <div className="flex flex-col gap-2">
                <h4 className="font-semibold text-xl md:text-2xl text-gray-900">
                  Sign up to our newsletter
                </h4>
                <p className="text-sm md:text-base text-gray-600">
                  Receive our latest updates about our products &amp; promotions
                </p>
              </div>

              <div className="flex flex-col sm:flex-row gap-2 w-full">
                <Input
                  className="flex-1 px-4 py-3 bg-white border-gray-300 rounded-lg text-gray-600"
                  placeholder="Your email"
                />
                <Button className="px-6 py-3 bg-primarymain text-white rounded-lg font-medium">
                  Subscribe
                </Button>
              </div>
            </div>

            <div className="flex items-center gap-4">
              {socialIcons.map((icon, index) => (
                <Button
                  key={index}
                  variant="outline"
                  size="icon"
                  className="p-3 bg-gray-100 rounded-[20px] border-none"
                >
                  <img className="w-4 h-4" alt={icon.alt} src={icon.src} />
                </Button>
              ))}
            </div>
          </div>

          {/* Video Content */}
          <div className="flex flex-col gap-4 flex-1">
            {videoItems.map((item, index) => (
              <Card
                key={index}
                className="border-none shadow-none bg-transparent"
              >
                <CardContent className="p-0 flex gap-4">
                  <img
                    className="w-[100px] sm:w-[140px] h-[60px] sm:h-[86px] object-cover rounded-md"
                    alt="Video thumbnail"
                    src={item.image}
                  />
                  <div className="flex flex-col justify-center gap-1 sm:gap-2 flex-1">
                    <span className="text-xs text-gray-500">
                      {item.duration}
                    </span>
                    <h6 className="text-sm font-medium text-gray-700">
                      {item.title}
                    </h6>
                  </div>
                </CardContent>
              </Card>
            ))}

            <Button
              variant="ghost"
              className="flex items-center gap-1.5 py-2.5 px-0 text-gray-700 justify-start w-fit"
            >
              <span className="text-sm font-medium">
                View all
              </span>
              <img className="w-4 h-4" alt="Icon" src="/icon-1.svg" />
            </Button>
          </div>
        </div>
      </section>

      {/* Main Footer */}
      <section className="w-full pt-12 md:pt-16 lg:pt-[72px] pb-6 px-4 md:px-8 lg:px-16 bg-gray-800 text-white">
        <div className="max-w-7xl mx-auto flex flex-col gap-12 md:gap-16 lg:gap-[72px]">
          {/* Footer Links */}
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-8 md:gap-12 lg:gap-[134px]">
            {/* Company Info */}
            <div className="flex flex-col gap-6">
              <img className="w-24 h-10" alt="Logo" src="/logo.svg" />
              <div className="flex flex-col gap-4">
                <p className="text-sm text-gray-300">
                  Got question? Contact us 24/7
                </p>
                <Button
                  variant="outline"
                  className="flex justify-between px-5 py-2.5 bg-gray-700 text-gray-200 rounded-lg border-none"
                >
                  <span className="text-sm">
                    Help and consultation
                  </span>
                  <img className="w-4 h-4" alt="Icon" src="/icon-22.svg" />
                </Button>
              </div>
            </div>

            {/* Company Links */}
            <div className="flex flex-col gap-4">
              <h6 className="font-semibold text-base text-white">
                Company
              </h6>
              <div className="flex flex-col gap-2">
                {footerLinks.company.map((link, index) => (
                  <a
                    key={index}
                    href="#"
                    className="font-normal text-gray-200 text-sm leading-[22px]"
                  >
                    {link}
                  </a>
                ))}
              </div>
            </div>

            {/* Account Links */}
            <div className="flex flex-col gap-4">
              <h6 className="font-semibold text-base text-white">
                Account
              </h6>
              <div className="flex flex-col gap-2">
                {footerLinks.account.map((link, index) => (
                  <a
                    key={index}
                    href="#"
                    className="font-normal text-gray-200 text-sm leading-[22px]"
                  >
                    {link}
                  </a>
                ))}
              </div>
            </div>

            {/* Customer Service Links */}
            <div className="flex flex-col gap-4">
              <h6 className="font-semibold text-base text-white">
                Customer service
              </h6>
              <div className="flex flex-col gap-2">
                {footerLinks.customerService.map((link, index) => (
                  <a
                    key={index}
                    href="#"
                    className="font-normal text-gray-200 text-sm leading-[22px]"
                  >
                    {link}
                  </a>
                ))}
              </div>
            </div>
          </div>

          {/* Product Categories */}
          <div className="flex flex-col gap-6 w-full">
            {productCategories.map((categoryRow, rowIndex) => (
              <div key={rowIndex} className="flex flex-wrap items-center gap-3">
                {categoryRow.map((category, index) => (
                  <Button
                    key={index}
                    variant="outline"
                    className="px-4 py-2.5 bg-gray-700 text-gray-200 rounded-lg border-none"
                  >
                    <span className="font-normal text-sm">
                      {category}
                    </span>
                  </Button>
                ))}
              </div>
            ))}
          </div>

          {/* Divider */}
          <Separator className="bg-gray-700" />

          {/* Payment Methods and Copyright */}
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <img className="w-10 h-10" alt="Icon" src="/icon-23.svg" />
              <div className="h-5">
                <VisaLogo />
              </div>
              <img
                className="w-[49px] h-5"
                alt="Apple Pay"
                src="/applepay.svg"
              />
              <img
                className="w-8 h-8"
                alt="Payment Method"
                src="/payment-method.svg"
              />
            </div>
            <p className="text-sm text-gray-400 text-center sm:text-right">
              © 2023 All Rights Reserved. Made with love by <span className="underline">Anima</span>
            </p>
          </div>
        </div>
      </section>
    </footer>
  );
};
