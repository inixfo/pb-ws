import React from "react";
import { Badge } from "../../../../components/ui/badge";
import { Button } from "../../../../components/ui/button";
import {
  Card,
  CardContent,
  CardFooter,
  CardHeader,
} from "../../../../components/ui/card";
import { Input } from "../../../../components/ui/input";
import { Progress } from "../../../../components/ui/progress";
import { Separator } from "../../../../components/ui/separator";
import { 
  ArrowLeftIcon, 
  ChevronRightIcon, 
  MinusIcon, 
  PlusIcon, 
  XIcon, 
  PercentIcon, 
  MoveRightIcon, 
  StarIcon
} from "lucide-react";

// Define cart items data
const cartItems = [
  {
    id: 1,
    name: "Apple iPhone 14 128GB",
    color: "White",
    model: "128 GB",
    price: "$899.00",
    quantity: 1,
    total: "$899.00",
    image: "/image.png",
    discount: false,
    discountPrice: null,
  },
  {
    id: 2,
    name: "Tablet Apple iPad Pro M2",
    color: "Black",
    model: "256 GB",
    price: "$989.00",
    quantity: 1,
    total: "$989.00",
    image: "/image-1.png",
    discount: true,
    discountPrice: "$1,099.00",
    discountPercentage: "10%",
  },
  {
    id: 3,
    name: "Smart Watch Series 7",
    color: "White",
    model: "44 mm",
    price: "$429.00",
    quantity: 2,
    total: "$429.00",
    image: "/image-2.png",
    discount: false,
    discountPrice: null,
  },
];

// Define order summary data
const orderSummary = {
  subtotal: "$2,427.00",
  saving: "-$110.00",
  tax: "$73.40",
  shipping: "Calculated at checkout",
  total: "$2,390.40",
  bonuses: "239 bonuses",
};

export const ShoppingCartContent = (): JSX.Element => {
  return (
    <div className="flex flex-col w-full max-w-[1296px] items-start gap-6">
      {/* Breadcrumb and Title */}
      <div className="flex flex-col items-start gap-6 w-full">
        <div className="flex items-center gap-2">
          <Button
            variant="link"
            className="p-0 h-auto font-navigation-nav-link-small text-gray-700"
            onClick={() => window.location.href = '/'}
          >
            Home
          </Button>
          <ChevronRightIcon className="w-3.5 h-3.5 text-gray-400" />
          <Button
            variant="link"
            className="p-0 h-auto font-navigation-nav-link-small text-gray-700"
          >
            Shop
          </Button>
          <ChevronRightIcon className="w-3.5 h-3.5 text-gray-400" />
          <span className="font-navigation-nav-link-small text-gray-400">
            Cart
          </span>
        </div>

        <h1 className="text-gray-900 font-heading-desktop-h3">
          Shopping cart
        </h1>
      </div>

      {/* Cart Content */}
      <div className="flex flex-col md:flex-row items-start gap-8 md:gap-14 w-full">
        {/* Left Column - Cart Items */}
        <div className="flex flex-col gap-8 w-full md:w-auto">
          {/* Free Shipping Progress */}
          <div className="w-full md:w-[824px]">
            <div className="flex flex-col w-full items-start gap-[3px]">
              <div className="w-full text-sm">
                <span className="text-[#4e5562] leading-[22px]">Buy </span>
                <span className="font-semibold text-[#181d25] leading-[22px]">
                  $183
                </span>
                <span className="text-[#4e5562] leading-[22px]">
                  {" "}
                  more to get{" "}
                </span>
                <span className="font-semibold text-[#181d25] leading-[22px]">
                  Free Shipping
                </span>
              </div>

              <div className="relative w-full h-6">
                <Progress
                  value={75}
                  className="h-1 mt-2.5 bg-gray-100 rounded-full"
                />
                <div className="absolute w-6 h-6 top-0 right-[220px] bg-white-100 rounded-xl border border-solid border-[#fc9231] flex items-center justify-center">
                  <StarIcon className="w-3 h-3 fill-current text-[#fc9231]" />
                </div>
              </div>
            </div>
          </div>

          {/* Cart Items Table */}
          <div className="flex flex-col w-full md:w-[824px] gap-6">
            {/* Table Header */}
            <div className="flex flex-col items-start gap-4 w-full">
              <div className="w-full h-[21px] flex">
                <div className="w-[306px] font-body-small text-gray-600">
                  Product
                </div>
                <div className="hidden md:block w-[140px] font-body-small text-gray-600">
                  Price
                </div>
                <div className="hidden md:block w-[158px] font-body-small text-gray-600">
                  Quantity
                </div>
                <div className="hidden md:block w-[90px] font-body-small text-gray-600">
                  Total
                </div>
                <Button
                  variant="link"
                  className="ml-auto p-0 font-normal text-sm text-gray-600 underline"
                >
                  Clear cart
                </Button>
              </div>
              <Separator className="w-full" />
            </div>

            {/* Cart Items */}
            {cartItems.map((item, index) => (
              <div
                key={index}
                className="flex flex-col items-start gap-6 w-full"
              >
                <div className="flex flex-col md:flex-row items-start md:items-center gap-4 w-full">
                  {/* Product */}
                  <div className="flex w-full md:w-[340px] items-center gap-4 pl-0 pr-4">
                    <div
                      className="relative w-[110px] h-[110px] rounded-lg bg-cover bg-center"
                      style={{
                        backgroundImage: `url(${item.image})`,
                      }}
                    >
                      {item.discount && (
                        <Badge className="absolute top-2 left-2 bg-dangermain px-2 py-0.5 rounded">
                          <span className="text-white-100 font-navigation-nav-link-extra-small">
                            -{item.discountPercentage}
                          </span>
                        </Badge>
                      )}
                    </div>
                    <div className="flex flex-col items-start gap-2 flex-1">
                      <div className="w-full font-navigation-nav-link-small text-gray-900">
                        {item.name}
                      </div>
                      <div className="flex flex-col items-start gap-1 w-full">
                        <div className="flex items-center gap-1 w-full">
                          <div className="font-body-extra-small text-gray-500">
                            Color:
                          </div>
                          <div className="flex-1 font-medium text-gray-900 text-xs">
                            {item.color}
                          </div>
                        </div>
                        <div className="flex items-center gap-1 w-full">
                          <div className="font-body-extra-small text-gray-500">
                            Model:
                          </div>
                          <div className="flex-1 font-medium text-gray-900 text-xs">
                            {item.model}
                          </div>
                        </div>
                      </div>
                      
                      {/* Mobile Price, Quantity and Total */}
                      <div className="flex md:hidden flex-col gap-2 w-full mt-2">
                        <div className="flex justify-between items-center">
                          <span className="text-sm text-gray-600">Price:</span>
                          <div className="flex items-center gap-2">
                            <div className="font-heading-desktop-h6 text-gray-900">
                              {item.price}
                            </div>
                            {item.discount && (
                              <div className="text-xs text-gray-400 line-through">
                                {item.discountPrice}
                              </div>
                            )}
                          </div>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-sm text-gray-600">Quantity:</span>
                          <div className="w-[140px] h-10">
                            <div className="flex items-center rounded-lg border border-solid border-[#cad0d9]">
                              <Button
                                variant="ghost"
                                size="icon"
                                className="p-3 h-auto"
                              >
                                <MinusIcon className="w-4 h-4 text-gray-600" />
                              </Button>
                              <div className="flex w-10 items-center justify-center px-5 py-2.5">
                                <span className="font-navigation-nav-link-small text-gray-700">
                                  {item.quantity}
                                </span>
                              </div>
                              <Button
                                variant="ghost"
                                size="icon"
                                className="p-3 h-auto"
                              >
                                <PlusIcon className="w-4 h-4 text-gray-600" />
                              </Button>
                            </div>
                          </div>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-sm text-gray-600">Total:</span>
                          <div className="font-heading-desktop-h6 text-gray-900">
                            {item.total}
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Desktop Price */}
                  <div className="hidden md:flex w-[140px] items-center gap-2">
                    <div className="font-heading-desktop-h6 text-gray-900">
                      {item.price}
                    </div>
                    {item.discount && (
                      <div className="text-xs text-gray-400 line-through">
                        {item.discountPrice}
                      </div>
                    )}
                  </div>

                  {/* Desktop Quantity */}
                  <div className="hidden md:block w-[158px] h-10">
                    <div className="flex items-center rounded-lg border border-solid border-[#cad0d9]">
                      <Button
                        variant="ghost"
                        size="icon"
                        className="p-3 h-auto"
                      >
                        <MinusIcon className="w-4 h-4 text-gray-600" />
                      </Button>
                      <div className="flex w-10 items-center justify-center px-5 py-2.5">
                        <span className="font-navigation-nav-link-small text-gray-700">
                          {item.quantity}
                        </span>
                      </div>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="p-3 h-auto"
                      >
                        <PlusIcon className="w-4 h-4 text-gray-600" />
                      </Button>
                    </div>
                  </div>

                  {/* Desktop Total */}
                  <div className="hidden md:block flex-1 font-heading-desktop-h6 text-gray-900">
                    {item.total}
                  </div>

                  {/* Remove */}
                  <Button variant="ghost" size="icon" className="p-0 h-auto ml-auto md:ml-0">
                    <XIcon className="w-4 h-4 text-gray-500" />
                  </Button>
                </div>
                <Separator className="w-full" />
              </div>
            ))}

            {/* Continue Shopping */}
            <Button
              variant="ghost"
              className="flex items-center gap-1.5 px-0 py-2.5 w-fit"
              onClick={() => window.location.href = '/'}
            >
              <ArrowLeftIcon className="w-4 h-4 text-gray-800" />
              <span className="font-navigation-nav-link-small text-gray-800">
                Continue shopping
              </span>
            </Button>
          </div>
        </div>

        {/* Right Column - Order Summary */}
        <div className="flex flex-col gap-4 w-full md:w-auto">
          {/* Order Summary Card */}
          <Card className="w-full md:w-[416px] bg-gray-50 rounded-2xl">
            <CardHeader className="px-8 pt-8 pb-0">
              <h2 className="font-heading-desktop-h5 text-gray-900">
                Order summary
              </h2>
            </CardHeader>
            <Separator className="mx-8 my-6" />
            <CardContent className="px-8 pb-0">
              <div className="flex flex-col gap-4">
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-600">
                    Subtotal (3 items):
                  </span>
                  <span className="font-navigation-nav-link-small text-gray-900 text-right">
                    {orderSummary.subtotal}
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-600">Saving:</span>
                  <span className="font-navigation-nav-link-small text-dangermain text-right">
                    {orderSummary.saving}
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-600">
                    Tax collected:
                  </span>
                  <span className="font-navigation-nav-link-small text-gray-900 text-right">
                    {orderSummary.tax}
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-600">Shipping:</span>
                  <span className="font-navigation-nav-link-small text-gray-900 text-right">
                    {orderSummary.shipping}
                  </span>
                </div>
              </div>
            </CardContent>
            <Separator className="mx-8 my-6" />
            <CardFooter className="px-8 pb-8 flex flex-col gap-4">
              <div className="flex justify-between items-center w-full">
                <span className="text-sm text-gray-600">
                  Estimated total:
                </span>
                <span className="font-heading-desktop-h5 text-gray-900 text-right w-[156px]">
                  {orderSummary.total}
                </span>
              </div>
              <Button className="w-full bg-primarymain hover:bg-primarymain/90 text-white-100 rounded-lg py-3 font-navigation-nav-link-regular"
                onClick={() => window.location.href = '/checkout'}
              >
                Proceed to checkout
                <MoveRightIcon className="w-[18px] h-[18px] ml-2" />
              </Button>
              <div className="text-sm text-center text-gray-900">
                <span className="text-[#4e5562] underline">
                  Create an account
                </span>
                <span className="text-[#4e5562]"> and get</span>
                <span className="text-[#181d25]">&nbsp;</span>
                <span className="font-navigation-nav-link-small text-[#181d25]">
                  {orderSummary.bonuses}{" "}
                </span>
              </div>
            </CardFooter>
          </Card>

          {/* Promo Code Card */}
          <Card className="w-full md:w-[416px] bg-gray-50 rounded-2xl px-8 py-1">
            <CardContent className="p-0">
              <div className="flex items-center justify-between py-5 w-full">
                <div className="flex items-center gap-3 flex-1">
                  <PercentIcon className="w-5 h-5 text-gray-700" />
                  <span className="flex-1 font-heading-desktop-h6 text-gray-900">
                    Apply promo code
                  </span>
                </div>
                <Button variant="ghost" size="icon" className="p-0 h-auto">
                  <PlusIcon className="w-4 h-4 text-gray-700" />
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}; 