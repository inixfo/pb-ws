import {
  BellIcon,
  CreditCardIcon,
  FileTextIcon,
  HeartIcon,
  HelpCircleIcon,
  LogOutIcon,
  MapPinIcon,
  StarIcon,
  UserIcon,
  ChevronRightIcon,
  XIcon,
  CalendarIcon,
  DollarSignIcon,
  MenuIcon
} from "lucide-react";
import React, { useState } from "react";
import { Link } from "react-router-dom";
import { Avatar, AvatarFallback } from "../../components/ui/avatar/Avatar";
import { Badge } from "../../components/ui/badge";
import { Button } from "../../components/ui/button";
import { Card, CardContent } from "../../components/ui/card";
import { Separator } from "../../components/ui/separator";
import { Select } from "../../components/ui/Select";
import PaginationComponent, { PaginationItem, PaginationLink } from "../../components/ui/pagination";
import { HeaderByAnima } from "../ElectronicsStore/sections/HeaderByAnima/HeaderByAnima";
import { CtaFooterByAnima } from "../ElectronicsStore/sections/CtaFooterByAnima/CtaFooterByAnima";

// Rename the imported component to maintain compatibility with existing code
const Pagination = PaginationComponent;

// Sidebar menu items
interface AccountMenuItem {
  icon: React.ReactElement;
  label: string;
  href: string;
  active?: boolean;
  badge?: string;
}

const accountMenuItems: AccountMenuItem[] = [
  {
    icon: <UserIcon size={16} />,
    label: "Orders",
    href: "/account",
    active: false,
  },
  { 
    icon: <HeartIcon size={16} />, 
    label: "Wishlist", 
    href: "/wishlist", 
    active: false,
  },
  { 
    icon: <CreditCardIcon size={16} />, 
    label: "Payment methods", 
    href: "/payment-methods",
    active: false
  },
  { 
    icon: <CreditCardIcon size={16} />, 
    label: "My EMI", 
    href: "/my-emi",
    active: true
  },
  { 
    icon: <StarIcon size={16} />, 
    label: "My reviews", 
    href: "/my-reviews",
    active: false 
  },
];

const manageAccountItems = [
  { icon: <UserIcon size={16} />, label: "Personal info", href: "/personal-info", active: false },
  { icon: <MapPinIcon size={16} />, label: "Addresses", href: "/addresses", active: false },
  { icon: <BellIcon size={16} />, label: "Notifications", href: "/notifications", active: false },
];

const customerServiceItems = [
  { icon: <HelpCircleIcon size={16} />, label: "Help center", href: "#" },
  {
    icon: <FileTextIcon size={16} />,
    label: "Terms and conditions",
    href: "#",
  },
];

// EMI data
interface EMIProduct {
  id: string;
  name: string;
  purchaseDate: string;
  totalAmount: number;
  image: string;
  emiDetails: {
    totalInstallments: number;
    paidInstallments: number;
    installmentAmount: number;
    nextInstallmentDate: string;
    bank: string;
    interestRate: number;
    processingFee: number;
  };
}

const emiProducts: EMIProduct[] = [
  {
    id: "EMI87654321",
    name: "Apple iPhone 14 128GB White",
    purchaseDate: "Feb 6, 2026",
    totalAmount: 899.00,
    image: "/image-1.png",
    emiDetails: {
      totalInstallments: 12,
      paidInstallments: 3,
      installmentAmount: 78.95,
      nextInstallmentDate: "May 6, 2026",
      bank: "Chase Bank",
      interestRate: 7.5,
      processingFee: 25.00
    }
  },
  {
    id: "EMI76543210",
    name: "MacBook Pro M2 13-inch",
    purchaseDate: "Jan 15, 2026",
    totalAmount: 1299.00,
    image: "/image-2.png",
    emiDetails: {
      totalInstallments: 18,
      paidInstallments: 4,
      installmentAmount: 76.40,
      nextInstallmentDate: "May 15, 2026",
      bank: "Bank of America",
      interestRate: 8.0,
      processingFee: 30.00
    }
  },
  {
    id: "EMI65432109",
    name: "Samsung Galaxy Watch 5",
    purchaseDate: "Dec 20, 2025",
    totalAmount: 349.00,
    image: "/image.png",
    emiDetails: {
      totalInstallments: 6,
      paidInstallments: 2,
      installmentAmount: 60.50,
      nextInstallmentDate: "Apr 20, 2026",
      bank: "Citibank",
      interestRate: 6.5,
      processingFee: 15.00
    }
  },
  {
    id: "EMI54321098",
    name: "iPad Pro 12.9 inch",
    purchaseDate: "Nov 05, 2025",
    totalAmount: 1099.00,
    image: "/image-3.png",
    emiDetails: {
      totalInstallments: 12,
      paidInstallments: 5,
      installmentAmount: 96.80,
      nextInstallmentDate: "Apr 05, 2026",
      bank: "Wells Fargo",
      interestRate: 7.0,
      processingFee: 28.00
    }
  }
];

export const MyEMI = (): JSX.Element => {
  const [selectedEMI, setSelectedEMI] = useState<EMIProduct | null>(null);
  const [drawerOpen, setDrawerOpen] = useState<boolean>(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState<boolean>(false);

  const openDrawer = (emi: EMIProduct) => {
    setSelectedEMI(emi);
    setDrawerOpen(true);
  };

  const closeDrawer = () => {
    setDrawerOpen(false);
  };

  const toggleMobileMenu = () => {
    setMobileMenuOpen(!mobileMenuOpen);
  };

  // Function to calculate remaining amount
  const calculateRemainingAmount = (emi: EMIProduct) => {
    const { totalInstallments, paidInstallments, installmentAmount } = emi.emiDetails;
    return ((totalInstallments - paidInstallments) * installmentAmount).toFixed(2);
  };

  // Function to calculate paid amount
  const calculatePaidAmount = (emi: EMIProduct) => {
    const { paidInstallments, installmentAmount } = emi.emiDetails;
    return (paidInstallments * installmentAmount).toFixed(2);
  };

  // Function to calculate progress percentage
  const calculateProgressPercentage = (emi: EMIProduct) => {
    const { totalInstallments, paidInstallments } = emi.emiDetails;
    return Math.round((paidInstallments / totalInstallments) * 100);
  };

  return (
    <div className="flex flex-col w-full bg-white min-h-screen">
      <HeaderByAnima showHeroSection={false} />
      
      {/* Main Content */}
      <main className="container mx-auto flex flex-col lg:flex-row gap-6 lg:gap-12 px-4 py-8 md:py-16">
        {/* Mobile User Profile with Hamburger */}
        <div className="flex items-center justify-between lg:hidden w-full mb-4">
          <div className="flex items-center gap-4">
            <Avatar className="w-12 h-12 bg-blue-100 rounded-3xl">
              <AvatarFallback className="text-blue-500 font-semibold">
                S
              </AvatarFallback>
            </Avatar>
            <div className="flex flex-col gap-1">
              <h6 className="font-semibold text-gray-900">
                Susan Gardner
              </h6>
              <div className="flex items-center gap-2">
                <img
                  className="w-3.5 h-3.5"
                  alt="Bonus icon"
                  src="/group.png"
                />
                <span className="text-sm text-gray-800">
                  100 bonuses available
                </span>
              </div>
            </div>
          </div>
          <Button 
            variant="ghost" 
            size="icon"
            className="h-10 w-10 rounded-full hover:bg-gray-100"
            onClick={toggleMobileMenu}
          >
            <MenuIcon className="h-6 w-6" />
          </Button>
        </div>

        {/* Mobile Menu Overlay */}
        {mobileMenuOpen && (
          <div className="fixed inset-0 z-40 lg:hidden" onClick={toggleMobileMenu}>
            <div className="absolute inset-0 bg-black/40"></div>
            <div 
              className="absolute right-0 top-0 h-full w-4/5 max-w-sm bg-white shadow-xl p-6 overflow-y-auto"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="flex justify-end mb-6">
                <Button 
                  variant="ghost" 
                  size="icon"
                  className="h-8 w-8"
                  onClick={toggleMobileMenu}
                >
                  <XIcon className="h-5 w-5" />
                </Button>
              </div>
              
              {/* Mobile Nav Items */}
              <div className="space-y-6">
                {/* User Profile (Mobile) */}
                <div className="flex items-center gap-4 mb-4">
                  <Avatar className="w-12 h-12 bg-blue-100 rounded-3xl">
                    <AvatarFallback className="text-blue-500 font-semibold">
                      S
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex flex-col gap-1">
                    <h6 className="font-semibold text-gray-900">
                      Susan Gardner
                    </h6>
                    <div className="flex items-center gap-2">
                      <img
                        className="w-3.5 h-3.5"
                        alt="Bonus icon"
                        src="/group.png"
                      />
                      <span className="text-sm text-gray-800">
                        100 bonuses available
                      </span>
                    </div>
                  </div>
                </div>
                
                <Separator />
                
                {/* Account Navigation (Mobile) */}
                <div>
                  <h6 className="font-semibold text-gray-900 mb-2">Account</h6>
                  <nav className="flex flex-col gap-1">
                    {accountMenuItems.map((item, index) => (
                      <Button
                        key={index}
                        variant={item.active ? "secondary" : "ghost"}
                        className={`justify-start gap-2 px-3 py-2.5 h-auto rounded-lg transition-colors ${
                          item.active 
                            ? "bg-gray-100" 
                            : "hover:bg-gray-50"
                        }`}
                        asChild
                        onClick={toggleMobileMenu}
                      >
                        <Link to={item.href}>
                          {React.cloneElement(item.icon, { className: "text-gray-700" })}
                          <span
                            className={`flex-1 text-left text-sm ${item.active ? "text-gray-900" : "text-gray-700"}`}
                          >
                            {item.label}
                          </span>
                          {item.badge && (
                            <Badge className="bg-primarymain text-white-100 rounded-full px-2 py-0.5 text-xs">
                              {item.badge}
                            </Badge>
                          )}
                        </Link>
                      </Button>
                    ))}
                  </nav>
                </div>
                
                {/* Manage Account Section (Mobile) */}
                <div>
                  <h6 className="font-semibold text-gray-900 mb-2">
                    Manage account
                  </h6>
                  <div className="flex flex-col gap-1">
                    {manageAccountItems.map((item, index) => (
                      <Button
                        key={index}
                        variant={item.active ? "secondary" : "ghost"}
                        className={`justify-start gap-2 px-3 py-2.5 h-auto rounded-lg transition-colors ${
                          item.active 
                            ? "bg-gray-100" 
                            : "hover:bg-gray-50"
                        }`}
                        asChild
                        onClick={toggleMobileMenu}
                      >
                        <Link to={item.href}>
                          {React.cloneElement(item.icon, {
                            className: "text-gray-700",
                          })}
                          <span className={`flex-1 text-left text-sm ${item.active ? "text-gray-900" : "text-gray-700"}`}>
                            {item.label}
                          </span>
                        </Link>
                      </Button>
                    ))}
                  </div>
                </div>
                
                {/* Customer Service Section (Mobile) */}
                <div>
                  <h6 className="font-semibold text-gray-900 mb-2">
                    Customer service
                  </h6>
                  <div className="flex flex-col gap-1">
                    {customerServiceItems.map((item, index) => (
                      <Button
                        key={index}
                        variant="ghost"
                        className="justify-start gap-2 px-3 py-2.5 h-auto rounded-lg hover:bg-gray-50 transition-colors"
                        asChild
                        onClick={toggleMobileMenu}
                      >
                        <Link to={item.href}>
                          {React.cloneElement(item.icon, {
                            className: "text-gray-700",
                          })}
                          <span className="flex-1 text-left text-sm text-gray-700">
                            {item.label}
                          </span>
                        </Link>
                      </Button>
                    ))}
                  </div>
                </div>
                
                {/* Log Out Button (Mobile) */}
                <Button
                  variant="ghost"
                  className="justify-start gap-2 px-3 py-2.5 h-auto rounded-lg w-full hover:bg-gray-50 transition-colors"
                  asChild
                  onClick={toggleMobileMenu}
                >
                  <Link to="/">
                    <LogOutIcon size={16} className="text-gray-700" />
                    <span className="flex-1 text-left text-sm text-gray-700">
                      Log out
                    </span>
                  </Link>
                </Button>
              </div>
            </div>
          </div>
        )}

        {/* Sidebar - Hide on mobile */}
        <aside className="hidden lg:flex lg:w-[282px] flex-col gap-6">
          {/* User Profile */}
          <div className="flex items-center gap-4">
            <Avatar className="w-12 h-12 bg-blue-100 rounded-3xl">
              <AvatarFallback className="text-blue-500 font-semibold">
                S
              </AvatarFallback>
            </Avatar>
            <div className="flex flex-col gap-1 flex-1">
              <h6 className="font-semibold text-gray-900">
                Susan Gardner
              </h6>
              <div className="flex items-center gap-2">
                <img
                  className="w-3.5 h-3.5"
                  alt="Bonus icon"
                  src="/group.png"
                />
                <span className="text-sm text-gray-800">
                  <span className="text-[#4e5562]">
                    100 bonuses
                  </span>
                  <span className="font-semibold">&nbsp;</span>
                  <span>available</span>
                </span>
              </div>
            </div>
          </div>

          {/* Account Navigation */}
          <nav className="flex flex-col gap-0.5">
            {accountMenuItems.map((item, index) => (
              <Button
                key={index}
                variant={item.active ? "secondary" : "ghost"}
                className={`justify-start gap-2 px-3 py-2.5 h-auto rounded-lg ${item.active ? "bg-gray-100" : ""}`}
                asChild
              >
                <Link to={item.href}>
                  {React.cloneElement(item.icon, { className: "text-gray-700" })}
                  <span
                    className={`flex-1 text-left text-sm ${item.active ? "text-gray-900" : "text-gray-700"}`}
                  >
                    {item.label}
                  </span>
                  {item.badge && (
                    <Badge className="bg-primarymain text-white-100 rounded-full px-2 py-0.5 text-xs">
                      {item.badge}
                    </Badge>
                  )}
                </Link>
              </Button>
            ))}
          </nav>

          {/* Manage Account Section */}
          <div className="flex flex-col gap-2">
            <h6 className="px-4 font-semibold text-gray-900">
              Manage account
            </h6>
            <div className="flex flex-col gap-0.5">
              {manageAccountItems.map((item, index) => (
                <Button
                  key={index}
                  variant={item.active ? "secondary" : "ghost"}
                  className={`justify-start gap-2 px-3 py-2.5 h-auto rounded-lg ${item.active ? "bg-gray-100" : ""}`}
                  asChild
                >
                  <Link to={item.href}>
                    {React.cloneElement(item.icon, {
                      className: "text-gray-700",
                    })}
                    <span className={`flex-1 text-left text-sm ${item.active ? "text-gray-900" : "text-gray-700"}`}>
                      {item.label}
                    </span>
                  </Link>
                </Button>
              ))}
            </div>
          </div>

          {/* Customer Service Section */}
          <div className="flex flex-col gap-2">
            <h6 className="px-4 font-semibold text-gray-900">
              Customer service
            </h6>
            <div className="flex flex-col gap-0.5">
              {customerServiceItems.map((item, index) => (
                <Button
                  key={index}
                  variant="ghost"
                  className="justify-start gap-2 px-3 py-2.5 h-auto rounded-lg"
                  asChild
                >
                  <Link to={item.href}>
                    {React.cloneElement(item.icon, {
                      className: "text-gray-700",
                    })}
                    <span className="flex-1 text-left text-sm text-gray-700">
                      {item.label}
                    </span>
                  </Link>
                </Button>
              ))}
            </div>
          </div>

          {/* Log Out Button */}
          <Button
            variant="ghost"
            className="justify-start gap-2 px-3 py-2.5 h-auto rounded-lg"
            asChild
          >
            <Link to="/">
              <LogOutIcon size={16} className="text-gray-700" />
              <span className="flex-1 text-left text-sm text-gray-700">
                Log out
              </span>
            </Link>
          </Button>
        </aside>

        {/* Main Content Area */}
        <div className="flex-1 max-w-[966px] flex flex-col gap-10">
          {/* Header with Filters */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 sm:gap-0">
            <h2 className="text-2xl md:text-3xl font-bold text-gray-900">My EMI</h2>
            <div className="flex flex-col sm:flex-row gap-3 sm:gap-6">
              <Select
                options={[
                  { value: "all", label: "All Products" },
                  { value: "current", label: "Current EMI" },
                  { value: "completed", label: "Completed EMI" }
                ]}
                value="all"
                className="w-full sm:w-[196px]"
              />
            </div>
          </div>

          {/* EMI Products Table */}
          <Card className="border-0 shadow-none">
            <CardContent className="p-0 space-y-8">
              {/* Table Header - Hidden on Mobile */}
              <div className="hidden md:block space-y-5">
                <div className="flex gap-4">
                  <div className="w-[147px] text-sm text-gray-600">EMI ID</div>
                  <div className="w-[147px] text-sm text-gray-600">
                    Purchase Date
                  </div>
                  <div className="w-[147px] text-sm text-gray-600">Status</div>
                  <div className="w-[147px] text-sm text-gray-600">Total</div>
                </div>
                <Separator />
              </div>

              {/* EMI Product Rows */}
              <div className="space-y-5">
                {emiProducts.map((emi, index) => {
                  const progressPercentage = calculateProgressPercentage(emi);
                  return (
                    <div key={index} className="space-y-5">
                      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 md:gap-0 md:h-16">
                        <div className="flex flex-col md:flex-row gap-2 md:gap-4">
                          <div className="w-full md:w-[147px] text-sm md:text-base font-medium text-gray-900">
                            <span className="md:hidden font-normal text-gray-600 mr-2">EMI ID:</span>
                            {emi.id}
                          </div>
                          <div className="w-full md:w-[147px] text-sm md:text-base font-medium text-gray-900">
                            <span className="md:hidden font-normal text-gray-600 mr-2">Date:</span>
                            {emi.purchaseDate}
                          </div>
                          <div className="w-full md:w-[147px]">
                            <div className="flex items-center gap-2">
                              <div className="w-full bg-gray-200 rounded-full h-2.5">
                                <div 
                                  className="bg-blue-500 h-2.5 rounded-full" 
                                  style={{ width: `${progressPercentage}%` }}
                                />
                              </div>
                              <span className="text-xs font-medium text-gray-700">{progressPercentage}%</span>
                            </div>
                            <div className="text-xs text-gray-600 mt-1">
                              {emi.emiDetails.paidInstallments} of {emi.emiDetails.totalInstallments} installments
                            </div>
                          </div>
                          <div className="w-full md:w-[147px] text-sm md:text-base font-medium text-gray-900">
                            <span className="md:hidden font-normal text-gray-600 mr-2">Total:</span>
                            ${emi.totalAmount.toFixed(2)}
                          </div>
                        </div>

                        <div className="flex items-center gap-3 mt-2 md:mt-0">
                          <div className="flex items-center gap-2 justify-end">
                            <img
                              className="w-16 h-16 object-cover rounded-md"
                              alt={emi.name}
                              src={emi.image}
                            />
                          </div>
                          <Button 
                            variant="ghost" 
                            size="sm" 
                            className="p-0 h-8 w-8"
                            onClick={() => openDrawer(emi)}
                          >
                            <ChevronRightIcon className="w-4 h-4 text-gray-600 flex-shrink-0" />
                          </Button>
                        </div>
                      </div>
                      <Separator />
                    </div>
                  );
                })}
              </div>

              {/* Pagination */}
              <Pagination className="flex items-start gap-1">
                <PaginationItem>
                  <PaginationLink
                    className="p-1.5 bg-gray-100 rounded-md"
                    isActive
                  >
                    1
                  </PaginationLink>
                </PaginationItem>
                <PaginationItem>
                  <PaginationLink className="p-1.5 bg-gray-50 rounded-md">
                    2
                  </PaginationLink>
                </PaginationItem>
              </Pagination>
            </CardContent>
          </Card>
        </div>
      </main>
      
      {/* EMI Details Drawer */}
      {drawerOpen && selectedEMI && (
        <div className="fixed inset-0 z-50 flex">
          {/* Backdrop */}
          <div 
            className="fixed inset-0 bg-black/40" 
            onClick={closeDrawer}
          />
          
          {/* Drawer */}
          <div className="fixed top-0 right-0 h-full w-full md:w-[450px] bg-white shadow-xl transition-transform">
            <div className="flex flex-col h-full">
              {/* Header */}
              <div className="flex items-center justify-between p-6 border-b">
                <h2 className="text-xl font-semibold">
                  EMI Details - {selectedEMI.id}
                </h2>
                <Button
                  variant="ghost"
                  size="sm"
                  className="p-1 h-8 w-8"
                  onClick={closeDrawer}
                >
                  <XIcon className="w-5 h-5" />
                </Button>
              </div>
              
              {/* Content */}
              <div className="flex-1 overflow-y-auto p-6">
                {/* Product Info */}
                <div className="flex gap-4 mb-6">
                  <img 
                    src={selectedEMI.image} 
                    alt={selectedEMI.name} 
                    className="w-24 h-24 object-cover rounded-md"
                  />
                  <div>
                    <h3 className="text-lg font-medium text-gray-900">{selectedEMI.name}</h3>
                    <p className="text-gray-600">Purchased on {selectedEMI.purchaseDate}</p>
                    <p className="text-gray-900 font-semibold mt-2">${selectedEMI.totalAmount.toFixed(2)}</p>
                  </div>
                </div>
                
                <Separator className="my-6" />
                
                {/* EMI Progress */}
                <div className="mb-6">
                  <h4 className="text-sm font-medium text-gray-700 mb-2">EMI Progress</h4>
                  <div className="flex items-center gap-2 mb-2">
                    <div className="w-full bg-gray-200 rounded-full h-2.5">
                      <div 
                        className="bg-blue-500 h-2.5 rounded-full" 
                        style={{ width: `${calculateProgressPercentage(selectedEMI)}%` }}
                      />
                    </div>
                    <span className="text-xs font-medium text-gray-700">{calculateProgressPercentage(selectedEMI)}%</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600">Paid: ${calculatePaidAmount(selectedEMI)}</span>
                    <span className="text-gray-600">Remaining: ${calculateRemainingAmount(selectedEMI)}</span>
                  </div>
                </div>
                
                {/* Installment Details */}
                <div className="bg-gray-50 rounded-lg p-4 mb-6">
                  <h4 className="text-sm font-medium text-gray-700 mb-4">Installment Details</h4>
                  
                  <div className="space-y-3">
                    <div className="flex justify-between">
                      <span className="text-gray-600">Total Installments</span>
                      <span className="font-medium">{selectedEMI.emiDetails.totalInstallments}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Paid Installments</span>
                      <span className="font-medium">{selectedEMI.emiDetails.paidInstallments}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Remaining Installments</span>
                      <span className="font-medium">{selectedEMI.emiDetails.totalInstallments - selectedEMI.emiDetails.paidInstallments}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Installment Amount</span>
                      <span className="font-medium">${selectedEMI.emiDetails.installmentAmount.toFixed(2)}/mo</span>
                    </div>
                  </div>
                </div>
                
                {/* Next Payment */}
                <div className="bg-blue-50 border border-blue-100 rounded-lg p-4 mb-6">
                  <div className="flex items-center gap-2 mb-2">
                    <CalendarIcon className="w-4 h-4 text-blue-500" />
                    <h4 className="text-sm font-medium text-gray-700">Next Payment</h4>
                  </div>
                  <div className="flex justify-between mb-1">
                    <span className="text-gray-600">Due Date</span>
                    <span className="font-medium">{selectedEMI.emiDetails.nextInstallmentDate}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Amount</span>
                    <span className="font-medium">${selectedEMI.emiDetails.installmentAmount.toFixed(2)}</span>
                  </div>
                </div>
                
                {/* Loan Details */}
                <div className="mb-6">
                  <h4 className="text-sm font-medium text-gray-700 mb-4">Loan Details</h4>
                  
                  <div className="space-y-3">
                    <div className="flex justify-between">
                      <span className="text-gray-600">Bank</span>
                      <span className="font-medium">{selectedEMI.emiDetails.bank}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Interest Rate</span>
                      <span className="font-medium">{selectedEMI.emiDetails.interestRate}%</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Processing Fee</span>
                      <span className="font-medium">${selectedEMI.emiDetails.processingFee.toFixed(2)}</span>
                    </div>
                  </div>
                </div>
              </div>
              
              {/* Actions */}
              <div className="p-6 border-t">
                <Button className="w-full" variant="default">
                  <DollarSignIcon className="w-4 h-4 mr-2" />
                  Pay Current Installment
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}
      
      <CtaFooterByAnima />
    </div>
  );
}; 