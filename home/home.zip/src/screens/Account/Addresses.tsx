import {
  BellIcon,
  ChevronRightIcon,
  CreditCardIcon,
  FileTextIcon,
  HeartIcon,
  HelpCircleIcon,
  LogOutIcon,
  MapPinIcon,
  PlusIcon,
  StarIcon,
  UserIcon,
  MenuIcon,
  XIcon
} from "lucide-react";
import React, { useState } from "react";
import { Link } from "react-router-dom";
import { Avatar, AvatarFallback } from "../../components/ui/avatar/Avatar";
import { Badge } from "../../components/ui/badge";
import { Button } from "../../components/ui/button";
import { Input } from "../../components/ui/input";
import { Label } from "../../components/ui/label";
import { Separator } from "../../components/ui/separator";
import { HeaderByAnima } from "../ElectronicsStore/sections/HeaderByAnima/HeaderByAnima";
import { CtaFooterByAnima } from "../ElectronicsStore/sections/CtaFooterByAnima/CtaFooterByAnima";

// Sidebar menu items
interface AccountMenuItem {
  icon: React.ReactElement;
  label: string;
  href: string;
  active?: boolean;
  badge?: string;
}

const accountMenuItems: AccountMenuItem[] = [
  {
    icon: <UserIcon size={16} />,
    label: "Orders",
    href: "/account",
    active: false,
  },
  { 
    icon: <HeartIcon size={16} />, 
    label: "Wishlist", 
    href: "/wishlist", 
    active: false,
  },
  { 
    icon: <CreditCardIcon size={16} />, 
    label: "Payment methods", 
    href: "/payment-methods",
    active: false
  },
  { 
    icon: <CreditCardIcon size={16} />, 
    label: "My EMI", 
    href: "/my-emi",
    active: false
  },
  { 
    icon: <StarIcon size={16} />, 
    label: "My reviews", 
    href: "/my-reviews",
    active: false 
  },
];

const manageAccountItems = [
  { icon: <UserIcon size={16} />, label: "Personal info", href: "/personal-info", active: false },
  { icon: <MapPinIcon size={16} />, label: "Addresses", href: "/addresses", active: true },
  { icon: <BellIcon size={16} />, label: "Notifications", href: "/notifications", active: false },
];

const customerServiceItems = [
  { icon: <HelpCircleIcon size={16} />, label: "Help center", href: "/help-center" },
  {
    icon: <FileTextIcon size={16} />,
    label: "Terms and conditions",
    href: "/terms",
  },
];

// Address type
interface Address {
  id: string;
  primary: boolean;
  street: string;
  city: string;
  state: string;
  zip: string;
  country: string;
}

// Initial address data
const initialAddresses: Address[] = [
  {
    id: "1",
    primary: true,
    street: "396 Lillian Bolavandy",
    city: "Holbrook",
    state: "New York",
    zip: "11741",
    country: "United States"
  },
  {
    id: "2",
    primary: false,
    street: "514 S. Magnolia St.",
    city: "Orlando",
    state: "Florida",
    zip: "32806",
    country: "United States"
  }
];

// Edit types
type EditingAddress = {
  isEditing: boolean;
  addressId: string | null;
  isNew: boolean;
};

export const Addresses = (): JSX.Element => {
  const [addresses, setAddresses] = useState<Address[]>(initialAddresses);
  const [editing, setEditing] = useState<EditingAddress>({
    isEditing: false,
    addressId: null,
    isNew: false
  });
  const [formData, setFormData] = useState<Address | null>(null);
  const [mobileMenuOpen, setMobileMenuOpen] = useState<boolean>(false);

  const handleEditAddress = (addressId: string) => {
    const addressToEdit = addresses.find(addr => addr.id === addressId);
    if (addressToEdit) {
      setFormData(addressToEdit);
      setEditing({
        isEditing: true,
        addressId,
        isNew: false
      });
    }
  };

  const handleAddAddress = () => {
    const newAddress: Address = {
      id: `new-${Date.now()}`,
      primary: false,
      street: "",
      city: "",
      state: "",
      zip: "",
      country: "United States"
    };
    setFormData(newAddress);
    setEditing({
      isEditing: true,
      addressId: newAddress.id,
      isNew: true
    });
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    if (formData) {
      setFormData({
        ...formData,
        [name]: value
      });
    }
  };

  const handleCancel = () => {
    setEditing({
      isEditing: false,
      addressId: null,
      isNew: false
    });
    setFormData(null);
  };

  const handleSave = () => {
    if (formData) {
      if (editing.isNew) {
        setAddresses([...addresses, formData]);
      } else {
        setAddresses(
          addresses.map(addr => 
            addr.id === formData.id ? formData : addr
          )
        );
      }
      setEditing({
        isEditing: false,
        addressId: null,
        isNew: false
      });
      setFormData(null);
    }
  };

  const formatAddress = (address: Address) => {
    return (
      <>
        <p className="text-gray-900">{address.city} {address.zip}, {address.country}</p>
        <p className="text-gray-900">{address.street}</p>
      </>
    );
  };

  const toggleMobileMenu = () => {
    setMobileMenuOpen(!mobileMenuOpen);
  };

  return (
    <div className="flex flex-col w-full bg-white min-h-screen">
      <HeaderByAnima showHeroSection={false} />
      
      {/* Main Content */}
      <main className="container mx-auto flex flex-col lg:flex-row gap-6 lg:gap-12 px-4 py-8 md:py-16">
        {/* Mobile User Profile with Hamburger */}
        <div className="flex items-center justify-between lg:hidden w-full mb-4">
          <div className="flex items-center gap-4">
            <Avatar className="w-12 h-12 bg-blue-100 rounded-3xl">
              <AvatarFallback className="text-blue-500 font-semibold">
                S
              </AvatarFallback>
            </Avatar>
            <div className="flex flex-col gap-1">
              <h6 className="font-semibold text-gray-900">
                Susan Gardner
              </h6>
              <div className="flex items-center gap-2">
                <img
                  className="w-3.5 h-3.5"
                  alt="Bonus icon"
                  src="/group.png"
                />
                <span className="text-sm text-gray-800">
                  100 bonuses available
                </span>
              </div>
            </div>
          </div>
          <Button 
            variant="ghost" 
            size="icon"
            className="h-10 w-10 rounded-full hover:bg-gray-100"
            onClick={toggleMobileMenu}
          >
            <MenuIcon className="h-6 w-6" />
          </Button>
        </div>

        {/* Mobile Menu Overlay */}
        {mobileMenuOpen && (
          <div className="fixed inset-0 z-40 lg:hidden" onClick={toggleMobileMenu}>
            <div className="absolute inset-0 bg-black/40"></div>
            <div 
              className="absolute right-0 top-0 h-full w-4/5 max-w-sm bg-white shadow-xl p-6 overflow-y-auto"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="flex justify-end mb-6">
                <Button 
                  variant="ghost" 
                  size="icon"
                  className="h-8 w-8"
                  onClick={toggleMobileMenu}
                >
                  <XIcon className="h-5 w-5" />
                </Button>
              </div>
              
              {/* Mobile Nav Items */}
              <div className="space-y-6">
                {/* User Profile (Mobile) */}
                <div className="flex items-center gap-4 mb-4">
                  <Avatar className="w-12 h-12 bg-blue-100 rounded-3xl">
                    <AvatarFallback className="text-blue-500 font-semibold">
                      S
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex flex-col gap-1">
                    <h6 className="font-semibold text-gray-900">
                      Susan Gardner
                    </h6>
                    <div className="flex items-center gap-2">
                      <img
                        className="w-3.5 h-3.5"
                        alt="Bonus icon"
                        src="/group.png"
                      />
                      <span className="text-sm text-gray-800">
                        100 bonuses available
                      </span>
                    </div>
                  </div>
                </div>
                
                <Separator />
                
                {/* Account Navigation (Mobile) */}
                <div>
                  <h6 className="font-semibold text-gray-900 mb-2">Account</h6>
                  <nav className="flex flex-col gap-1">
                    {accountMenuItems.map((item, index) => (
                      <Button
                        key={index}
                        variant={item.active ? "secondary" : "ghost"}
                        className={`justify-start gap-2 px-3 py-2.5 h-auto rounded-lg transition-colors ${
                          item.active 
                            ? "bg-gray-100" 
                            : "hover:bg-gray-50"
                        }`}
                        asChild
                        onClick={toggleMobileMenu}
                      >
                        <Link to={item.href}>
                          {React.cloneElement(item.icon, { className: "text-gray-700" })}
                          <span
                            className={`flex-1 text-left text-sm ${item.active ? "text-gray-900" : "text-gray-700"}`}
                          >
                            {item.label}
                          </span>
                          {item.badge && (
                            <Badge className="bg-primarymain text-white-100 rounded-full px-2 py-0.5 text-xs">
                              {item.badge}
                            </Badge>
                          )}
                        </Link>
                      </Button>
                    ))}
                  </nav>
                </div>
                
                {/* Manage Account Section (Mobile) */}
                <div>
                  <h6 className="font-semibold text-gray-900 mb-2">
                    Manage account
                  </h6>
                  <div className="flex flex-col gap-1">
                    {manageAccountItems.map((item, index) => (
                      <Button
                        key={index}
                        variant={item.active ? "secondary" : "ghost"}
                        className={`justify-start gap-2 px-3 py-2.5 h-auto rounded-lg transition-colors ${
                          item.active 
                            ? "bg-gray-100" 
                            : "hover:bg-gray-50"
                        }`}
                        asChild
                        onClick={toggleMobileMenu}
                      >
                        <Link to={item.href}>
                          {React.cloneElement(item.icon, {
                            className: "text-gray-700",
                          })}
                          <span className={`flex-1 text-left text-sm ${item.active ? "text-gray-900" : "text-gray-700"}`}>
                            {item.label}
                          </span>
                        </Link>
                      </Button>
                    ))}
                  </div>
                </div>
                
                {/* Customer Service Section (Mobile) */}
                <div>
                  <h6 className="font-semibold text-gray-900 mb-2">
                    Customer service
                  </h6>
                  <div className="flex flex-col gap-1">
                    {customerServiceItems.map((item, index) => (
                      <Button
                        key={index}
                        variant="ghost"
                        className="justify-start gap-2 px-3 py-2.5 h-auto rounded-lg hover:bg-gray-50 transition-colors"
                        asChild
                        onClick={toggleMobileMenu}
                      >
                        <Link to={item.href}>
                          {React.cloneElement(item.icon, {
                            className: "text-gray-700",
                          })}
                          <span className="flex-1 text-left text-sm text-gray-700">
                            {item.label}
                          </span>
                        </Link>
                      </Button>
                    ))}
                  </div>
                </div>
                
                {/* Log Out Button (Mobile) */}
                <Button
                  variant="ghost"
                  className="justify-start gap-2 px-3 py-2.5 h-auto rounded-lg w-full hover:bg-gray-50 transition-colors"
                  asChild
                  onClick={toggleMobileMenu}
                >
                  <Link to="/">
                    <LogOutIcon size={16} className="text-gray-700" />
                    <span className="flex-1 text-left text-sm text-gray-700">
                      Log out
                    </span>
                  </Link>
                </Button>
              </div>
            </div>
          </div>
        )}

        {/* Sidebar - Hide on mobile */}
        <aside className="hidden lg:flex lg:w-[282px] flex-col gap-6">
          {/* User Profile */}
          <div className="flex items-center gap-4">
            <Avatar className="w-12 h-12 bg-blue-100 rounded-3xl">
              <AvatarFallback className="text-blue-500 font-semibold">
                S
              </AvatarFallback>
            </Avatar>
            <div className="flex flex-col gap-1 flex-1">
              <h6 className="font-semibold text-gray-900">
                Susan Gardner
              </h6>
              <div className="flex items-center gap-2">
                <img
                  className="w-3.5 h-3.5"
                  alt="Bonus icon"
                  src="/group.png"
                />
                <span className="text-sm text-gray-800">
                  <span className="text-[#4e5562]">
                    100 bonuses
                  </span>
                  <span className="font-semibold">&nbsp;</span>
                  <span>available</span>
                </span>
              </div>
            </div>
          </div>

          {/* Account Navigation */}
          <nav className="flex flex-col gap-0.5">
            {accountMenuItems.map((item, index) => (
              <Button
                key={index}
                variant={item.active ? "secondary" : "ghost"}
                className={`justify-start gap-2 px-3 py-2.5 h-auto rounded-lg ${item.active ? "bg-gray-100" : ""}`}
                asChild
              >
                <Link to={item.href}>
                  {React.cloneElement(item.icon, { className: "text-gray-700" })}
                  <span
                    className={`flex-1 text-left text-sm ${item.active ? "text-gray-900" : "text-gray-700"}`}
                  >
                    {item.label}
                  </span>
                  {item.badge && (
                    <Badge className="bg-primarymain text-white-100 rounded-full px-2 py-0.5 text-xs">
                      {item.badge}
                    </Badge>
                  )}
                </Link>
              </Button>
            ))}
          </nav>

          {/* Manage Account Section */}
          <div className="flex flex-col gap-2">
            <h6 className="px-4 font-semibold text-gray-900">
              Manage account
            </h6>
            <div className="flex flex-col gap-0.5">
              {manageAccountItems.map((item, index) => (
                <Button
                  key={index}
                  variant={item.active ? "secondary" : "ghost"}
                  className={`justify-start gap-2 px-3 py-2.5 h-auto rounded-lg ${item.active ? "bg-gray-100" : ""}`}
                  asChild
                >
                  <Link to={item.href}>
                    {React.cloneElement(item.icon, {
                      className: "text-gray-700",
                    })}
                    <span className={`flex-1 text-left text-sm ${item.active ? "text-gray-900" : "text-gray-700"}`}>
                      {item.label}
                    </span>
                  </Link>
                </Button>
              ))}
            </div>
          </div>

          {/* Customer Service Section */}
          <div className="flex flex-col gap-2">
            <h6 className="px-4 font-semibold text-gray-900">
              Customer service
            </h6>
            <div className="flex flex-col gap-0.5">
              {customerServiceItems.map((item, index) => (
                <Button
                  key={index}
                  variant="ghost"
                  className="justify-start gap-2 px-3 py-2.5 h-auto rounded-lg"
                  asChild
                >
                  <Link to={item.href}>
                    {React.cloneElement(item.icon, {
                      className: "text-gray-700",
                    })}
                    <span className="flex-1 text-left text-sm text-gray-700">
                      {item.label}
                    </span>
                  </Link>
                </Button>
              ))}
            </div>
          </div>

          {/* Log Out Button */}
          <Button
            variant="ghost"
            className="justify-start gap-2 px-3 py-2.5 h-auto rounded-lg"
            asChild
          >
            <Link to="/">
              <LogOutIcon size={16} className="text-gray-700" />
              <span className="flex-1 text-left text-sm text-gray-700">
                Log out
              </span>
            </Link>
          </Button>
        </aside>

        {/* Main Content Area */}
        <div className="flex-1 max-w-[966px] flex flex-col">
          <h2 className="text-3xl font-bold text-gray-900 mb-8">Addresses</h2>

          {editing.isEditing && formData ? (
            <div className="mb-8 p-6 border border-gray-200 rounded-lg">
              <h3 className="text-xl font-semibold text-gray-900 mb-6">
                {editing.isNew ? "Add new address" : "Edit address"}
              </h3>
              <div className="space-y-6">
                <div>
                  <Label htmlFor="street">Street address</Label>
                  <Input 
                    id="street"
                    name="street"
                    value={formData.street}
                    onChange={handleInputChange}
                    className="mt-2"
                  />
                </div>
                
                <div className="grid grid-cols-2 gap-6">
                  <div>
                    <Label htmlFor="city">City</Label>
                    <Input 
                      id="city"
                      name="city"
                      value={formData.city}
                      onChange={handleInputChange}
                      className="mt-2"
                    />
                  </div>
                  <div>
                    <Label htmlFor="state">State</Label>
                    <Input 
                      id="state"
                      name="state"
                      value={formData.state}
                      onChange={handleInputChange}
                      className="mt-2"
                    />
                  </div>
                </div>
                
                <div className="grid grid-cols-2 gap-6">
                  <div>
                    <Label htmlFor="zip">ZIP / Postal code</Label>
                    <Input 
                      id="zip"
                      name="zip"
                      value={formData.zip}
                      onChange={handleInputChange}
                      className="mt-2"
                    />
                  </div>
                  <div>
                    <Label htmlFor="country">Country</Label>
                    <Input 
                      id="country"
                      name="country"
                      value={formData.country}
                      onChange={handleInputChange}
                      className="mt-2"
                    />
                  </div>
                </div>
                
                {!formData.primary && (
                  <div className="flex items-center gap-2">
                    <input 
                      type="checkbox" 
                      id="primary"
                      checked={formData.primary}
                      onChange={(e) => {
                        setFormData({
                          ...formData,
                          primary: e.target.checked
                        });
                      }}
                      className="h-4 w-4"
                    />
                    <Label htmlFor="primary" className="text-sm">Set as primary address</Label>
                  </div>
                )}

                <div className="flex justify-end gap-3 mt-6">
                  <Button
                    variant="outline"
                    className="border-gray-200"
                    onClick={handleCancel}
                  >
                    Cancel
                  </Button>
                  <Button onClick={handleSave}>
                    Save
                  </Button>
                </div>
              </div>
            </div>
          ) : (
            <>
              {/* Shipping Address */}
              {addresses.map(address => (
                <div key={address.id} className="mb-8">
                  <div className="flex justify-between items-center mb-4">
                    <div className="flex items-center gap-2">
                      <h3 className="text-xl font-semibold text-gray-900">
                        {address.primary ? "Shipping address" : "Alternative shipping address"}
                      </h3>
                      {address.primary && (
                        <Badge className="bg-blue-100 text-blue-700 px-2 py-0.5">Primary</Badge>
                      )}
                    </div>
                    <Button 
                      variant="link"
                      className="text-gray-700 font-medium p-0 h-auto"
                      onClick={() => handleEditAddress(address.id)}
                    >
                      Edit
                    </Button>
                  </div>
                  
                  <div className="space-y-1 mb-8">
                    {formatAddress(address)}
                  </div>
                  
                  <Separator />
                </div>
              ))}

              {/* Add Address Button */}
              <Button 
                variant="ghost" 
                className="text-gray-700 flex items-center gap-2 w-fit mt-2"
                onClick={handleAddAddress}
              >
                <PlusIcon size={16} />
                <span>Add address</span>
              </Button>
            </>
          )}
        </div>
      </main>
      
      <CtaFooterByAnima />
    </div>
  );
}; 