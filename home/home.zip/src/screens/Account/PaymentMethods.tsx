import {
  BellIcon,
  ChevronRightIcon,
  CreditCardIcon,
  FileTextIcon,
  HeartIcon,
  HelpCircleIcon,
  LogOutIcon,
  MapPinIcon,
  PlusIcon,
  StarIcon,
  UserIcon,
  MenuIcon,
  XIcon
} from "lucide-react";
import React, { useState } from "react";
import { Avatar, AvatarFallback } from "../../components/ui/avatar/Avatar";
import { Badge } from "../../components/ui/badge";
import { Button } from "../../components/ui/button";
import { Separator } from "../../components/ui/separator";
import { HeaderByAnima } from "../ElectronicsStore/sections/HeaderByAnima/HeaderByAnima";
import { CtaFooterByAnima } from "../ElectronicsStore/sections/CtaFooterByAnima/CtaFooterByAnima";
import { Link, useNavigate } from "react-router-dom";

// Sidebar menu items
interface AccountMenuItem {
  icon: React.ReactElement;
  label: string;
  href: string;
  active?: boolean;
  badge?: string;
}

const accountMenuItems: AccountMenuItem[] = [
  {
    icon: <UserIcon size={16} />,
    label: "Orders",
    href: "/account",
    active: false,
  },
  { 
    icon: <HeartIcon size={16} />, 
    label: "Wishlist", 
    href: "/wishlist", 
    active: false,
  },
  { 
    icon: <CreditCardIcon size={16} />, 
    label: "Payment methods", 
    href: "/payment-methods",
    active: true
  },
  { 
    icon: <CreditCardIcon size={16} />, 
    label: "My EMI", 
    href: "/my-emi",
    active: false
  },
  { 
    icon: <StarIcon size={16} />, 
    label: "My reviews", 
    href: "/my-reviews",
    active: false
  },
];

const manageAccountItems = [
  { icon: <UserIcon size={16} />, label: "Personal info", href: "/personal-info", active: false },
  { icon: <MapPinIcon size={16} />, label: "Addresses", href: "/addresses", active: false },
  { icon: <BellIcon size={16} />, label: "Notifications", href: "/notifications", active: false },
];

const customerServiceItems = [
  { icon: <HelpCircleIcon size={16} />, label: "Help center", href: "#" },
  {
    icon: <FileTextIcon size={16} />,
    label: "Terms and conditions",
    href: "#",
  },
];

// Payment methods data
const paymentMethods = [
  {
    id: 1,
    type: "mastercard",
    cardNumber: "**** **** **** 8341",
    expiryDate: "05/24",
    isExpired: true,
    isPrimary: true,
  },
  {
    id: 2,
    type: "visa",
    cardNumber: "**** **** **** 1276",
    expiryDate: "01/27",
    isExpired: false,
    isPrimary: false,
  },
];

// Card logo components to prevent duplicate rendering
const CardLogo = ({ type }: { type: string }) => {
  if (type === 'visa') {
    return (
      <svg xmlns="http://www.w3.org/2000/svg" width="70" height="20" viewBox="0 0 70 32" fill="none">
        <path d="M26.513 21.5823H20.9834L24.2603 7.1377H29.7899L26.513 21.5823Z" fill="#00579F"/>
        <path d="M47.8039 7.3677C46.7679 6.9777 45.0159 6.5477 42.8899 6.5477C37.4999 6.5477 33.7839 9.2977 33.7639 13.1477C33.7239 16.0177 36.3839 17.6277 38.3659 18.6277C40.3879 19.6477 41.0099 20.3077 41.0099 21.1977C40.9899 22.5777 39.2579 23.2177 37.6459 23.2177C35.4199 23.2177 34.2239 22.9077 32.4129 22.1577L31.6969 21.8577L30.9299 26.4577C32.1659 26.9877 34.5139 27.4577 36.9799 27.4777C42.7299 27.4777 46.3859 24.7677 46.4259 20.6377C46.4459 18.3177 45.0159 16.5277 42.0139 15.0477C40.1829 14.0877 39.0179 13.4277 39.0179 12.4877C39.0379 11.6377 40.0079 10.7677 42.0939 10.7677C43.7869 10.7277 45.0559 11.1177 46.0719 11.5077L46.5719 11.7177L47.3079 7.4277L47.8039 7.3677Z" fill="#00579F"/>
        <path d="M55.2598 17.3177C55.7598 16.1577 57.6098 11.4477 57.6098 11.4477C57.5898 11.4877 58.0898 10.1277 58.3898 9.2777L58.8098 11.2577C58.8098 11.2577 59.9258 16.3477 60.1658 17.3177C59.4458 17.3177 56.2798 17.3177 55.2598 17.3177ZM63.0158 7.1377H59.0298C57.7738 7.1377 56.8338 7.5077 56.2798 8.8477L48.1299 27.1377H53.9798C53.9798 27.1377 54.9798 24.5277 55.1998 23.9277C55.7798 23.9277 61.3358 23.9277 62.0758 23.9277C62.2358 24.6677 62.7558 27.1377 62.7558 27.1377H67.9858L63.0158 7.1377Z" fill="#00579F"/>
        <path d="M18.8499 7.1377L13.4199 21.3577L12.8999 18.8577C11.9999 15.9677 9.07993 12.8577 5.87993 11.1577L10.8799 27.1177H16.7699L24.9199 7.1377H18.8499Z" fill="#00579F"/>
        <path d="M8.62987 7.1377H0.129866L0.00986633 7.5477C6.95987 9.3377 11.6799 13.7777 13.6399 18.8577L11.6999 8.8677C11.3399 7.5277 10.0899 7.1577 8.62987 7.1377Z" fill="#FAA61A"/>
      </svg>
    );
  } else {
    return (
      <svg xmlns="http://www.w3.org/2000/svg" width="48" height="20" viewBox="0 0 48 32" fill="none">
        <circle cx="16" cy="16" r="10" fill="#EB001B"/>
        <circle cx="32" cy="16" r="10" fill="#F79E1B"/>
        <path fill-rule="evenodd" clip-rule="evenodd" d="M24 23.1C26.7 21.1 28.5 17.8 28.5 14C28.5 10.2 26.7 6.9 24 4.9C21.3 6.9 19.5 10.2 19.5 14C19.5 17.8 21.3 21.1 24 23.1Z" fill="#FF5F00"/>
      </svg>
    );
  }
};

export const PaymentMethods = (): JSX.Element => {
  const [primaryMethodId, setPrimaryMethodId] = useState<number>(
    paymentMethods.find(method => method.isPrimary)?.id || 1
  );
  const navigate = useNavigate();
  const [mobileMenuOpen, setMobileMenuOpen] = useState<boolean>(false);

  const setPrimaryMethod = (id: number) => {
    setPrimaryMethodId(id);
  };

  const toggleMobileMenu = () => {
    setMobileMenuOpen(!mobileMenuOpen);
  };

  return (
    <div className="flex flex-col w-full bg-white min-h-screen">
      <HeaderByAnima showHeroSection={false} />
      
      {/* Main Content */}
      <main className="container mx-auto flex flex-col lg:flex-row gap-6 lg:gap-12 px-4 py-8 md:py-16">
        {/* Mobile User Profile with Hamburger */}
        <div className="flex items-center justify-between lg:hidden w-full mb-4">
          <div className="flex items-center gap-4">
            <Avatar className="w-12 h-12 bg-blue-100 rounded-3xl">
              <AvatarFallback className="text-blue-500 font-semibold">
                S
              </AvatarFallback>
            </Avatar>
            <div className="flex flex-col gap-1">
              <h6 className="font-semibold text-gray-900">
                Susan Gardner
              </h6>
              <div className="flex items-center gap-2">
                <img
                  className="w-3.5 h-3.5"
                  alt="Bonus icon"
                  src="/group.png"
                />
                <span className="text-sm text-gray-800">
                  100 bonuses available
                </span>
              </div>
            </div>
          </div>
          <Button 
            variant="ghost" 
            size="icon"
            className="h-10 w-10 rounded-full hover:bg-gray-100"
            onClick={toggleMobileMenu}
          >
            <MenuIcon className="h-6 w-6" />
          </Button>
        </div>

        {/* Mobile Menu Overlay */}
        {mobileMenuOpen && (
          <div className="fixed inset-0 z-40 lg:hidden" onClick={toggleMobileMenu}>
            <div className="absolute inset-0 bg-black/40"></div>
            <div 
              className="absolute right-0 top-0 h-full w-4/5 max-w-sm bg-white shadow-xl p-6 overflow-y-auto"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="flex justify-end mb-6">
                <Button 
                  variant="ghost" 
                  size="icon"
                  className="h-8 w-8"
                  onClick={toggleMobileMenu}
                >
                  <XIcon className="h-5 w-5" />
                </Button>
              </div>
              
              {/* Mobile Nav Items */}
              <div className="space-y-6">
                {/* User Profile (Mobile) */}
                <div className="flex items-center gap-4 mb-4">
                  <Avatar className="w-12 h-12 bg-blue-100 rounded-3xl">
                    <AvatarFallback className="text-blue-500 font-semibold">
                      S
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex flex-col gap-1">
                    <h6 className="font-semibold text-gray-900">
                      Susan Gardner
                    </h6>
                    <div className="flex items-center gap-2">
                      <img
                        className="w-3.5 h-3.5"
                        alt="Bonus icon"
                        src="/group.png"
                      />
                      <span className="text-sm text-gray-800">
                        100 bonuses available
                      </span>
                    </div>
                  </div>
                </div>
                
                <Separator />
                
                {/* Account Navigation (Mobile) */}
                <div>
                  <h6 className="font-semibold text-gray-900 mb-2">Account</h6>
                  <nav className="flex flex-col gap-1">
                    {accountMenuItems.map((item, index) => (
                      <Button
                        key={index}
                        variant={item.active ? "secondary" : "ghost"}
                        className={`justify-start gap-2 px-3 py-2.5 h-auto rounded-lg transition-colors ${
                          item.active 
                            ? "bg-gray-100" 
                            : "hover:bg-gray-50"
                        }`}
                        asChild
                        onClick={toggleMobileMenu}
                      >
                        <Link to={item.href}>
                          {React.cloneElement(item.icon, { className: "text-gray-700" })}
                          <span
                            className={`flex-1 text-left text-sm ${item.active ? "text-gray-900" : "text-gray-700"}`}
                          >
                            {item.label}
                          </span>
                          {item.badge && (
                            <Badge className="bg-primarymain text-white-100 rounded-full px-2 py-0.5 text-xs">
                              {item.badge}
                            </Badge>
                          )}
                        </Link>
                      </Button>
                    ))}
                  </nav>
                </div>
                
                {/* Manage Account Section (Mobile) */}
                <div>
                  <h6 className="font-semibold text-gray-900 mb-2">
                    Manage account
                  </h6>
                  <div className="flex flex-col gap-1">
                    {manageAccountItems.map((item, index) => (
                      <Button
                        key={index}
                        variant={item.active ? "secondary" : "ghost"}
                        className={`justify-start gap-2 px-3 py-2.5 h-auto rounded-lg transition-colors ${
                          item.active 
                            ? "bg-gray-100" 
                            : "hover:bg-gray-50"
                        }`}
                        asChild
                        onClick={toggleMobileMenu}
                      >
                        <Link to={item.href}>
                          {React.cloneElement(item.icon, {
                            className: "text-gray-700",
                          })}
                          <span className={`flex-1 text-left text-sm ${item.active ? "text-gray-900" : "text-gray-700"}`}>
                            {item.label}
                          </span>
                        </Link>
                      </Button>
                    ))}
                  </div>
                </div>
                
                {/* Customer Service Section (Mobile) */}
                <div>
                  <h6 className="font-semibold text-gray-900 mb-2">
                    Customer service
                  </h6>
                  <div className="flex flex-col gap-1">
                    {customerServiceItems.map((item, index) => (
                      <Button
                        key={index}
                        variant="ghost"
                        className="justify-start gap-2 px-3 py-2.5 h-auto rounded-lg hover:bg-gray-50 transition-colors"
                        asChild
                        onClick={toggleMobileMenu}
                      >
                        <Link to={item.href}>
                          {React.cloneElement(item.icon, {
                            className: "text-gray-700",
                          })}
                          <span className="flex-1 text-left text-sm text-gray-700">
                            {item.label}
                          </span>
                        </Link>
                      </Button>
                    ))}
                  </div>
                </div>
                
                {/* Log Out Button (Mobile) */}
                <Button
                  variant="ghost"
                  className="justify-start gap-2 px-3 py-2.5 h-auto rounded-lg w-full hover:bg-gray-50 transition-colors"
                  asChild
                  onClick={toggleMobileMenu}
                >
                  <Link to="/">
                    <LogOutIcon size={16} className="text-gray-700" />
                    <span className="flex-1 text-left text-sm text-gray-700">
                      Log out
                    </span>
                  </Link>
                </Button>
              </div>
            </div>
          </div>
        )}

        {/* Sidebar - Hide on mobile */}
        <aside className="hidden lg:flex lg:w-[282px] flex-col gap-6">
          {/* User Profile */}
          <div className="flex items-center gap-4">
            <Avatar className="w-12 h-12 bg-blue-100 rounded-3xl">
              <AvatarFallback className="text-blue-500 font-semibold">
                S
              </AvatarFallback>
            </Avatar>
            <div className="flex flex-col gap-1 flex-1">
              <h6 className="font-semibold text-gray-900">
                Susan Gardner
              </h6>
              <div className="flex items-center gap-2">
                <img
                  className="w-3.5 h-3.5"
                  alt="Bonus icon"
                  src="/group.png"
                />
                <span className="text-sm text-gray-800">
                  <span className="text-[#4e5562]">
                    100 bonuses
                  </span>
                  <span className="font-semibold">&nbsp;</span>
                  <span>available</span>
                </span>
              </div>
            </div>
          </div>

          {/* Account Navigation */}
          <nav className="flex flex-col gap-0.5">
            {accountMenuItems.map((item, index) => (
              <Button
                key={index}
                variant={item.active ? "secondary" : "ghost"}
                className={`justify-start gap-2 px-3 py-2.5 h-auto rounded-lg ${item.active ? "bg-gray-100" : ""}`}
                asChild
              >
                <Link to={item.href}>
                  {React.cloneElement(item.icon, { className: "text-gray-700" })}
                  <span
                    className={`flex-1 text-left text-sm ${item.active ? "text-gray-900" : "text-gray-700"}`}
                  >
                    {item.label}
                  </span>
                  {item.badge && (
                    <Badge className="bg-primarymain text-white-100 rounded-full px-2 py-0.5 text-xs">
                      {item.badge}
                    </Badge>
                  )}
                </Link>
              </Button>
            ))}
          </nav>

          {/* Manage Account Section */}
          <div className="flex flex-col gap-2">
            <h6 className="px-4 font-semibold text-gray-900">
              Manage account
            </h6>
            <div className="flex flex-col gap-0.5">
              {manageAccountItems.map((item, index) => (
                <Button
                  key={index}
                  variant={item.active ? "secondary" : "ghost"}
                  className={`justify-start gap-2 px-3 py-2.5 h-auto rounded-lg ${item.active ? "bg-gray-100" : ""}`}
                  asChild
                >
                  <Link to={item.href}>
                    {React.cloneElement(item.icon, {
                      className: "text-gray-700",
                    })}
                    <span className={`flex-1 text-left text-sm ${item.active ? "text-gray-900" : "text-gray-700"}`}>
                      {item.label}
                    </span>
                  </Link>
                </Button>
              ))}
            </div>
          </div>

          {/* Customer Service Section */}
          <div className="flex flex-col gap-2">
            <h6 className="px-4 font-semibold text-gray-900">
              Customer service
            </h6>
            <div className="flex flex-col gap-0.5">
              {customerServiceItems.map((item, index) => (
                <Button
                  key={index}
                  variant="ghost"
                  className="justify-start gap-2 px-3 py-2.5 h-auto rounded-lg"
                  asChild
                >
                  <Link to={item.href}>
                    {React.cloneElement(item.icon, {
                      className: "text-gray-700",
                    })}
                    <span className="flex-1 text-left text-sm text-gray-700">
                      {item.label}
                    </span>
                  </Link>
                </Button>
              ))}
            </div>
          </div>

          {/* Log Out Button */}
          <Button
            variant="ghost"
            className="justify-start gap-2 px-3 py-2.5 h-auto rounded-lg"
            onClick={() => navigate('/')}
          >
            <LogOutIcon size={16} className="text-gray-700" />
            <span className="flex-1 text-left text-sm text-gray-700">
              Log out
            </span>
          </Button>
        </aside>

        {/* Main Content Area */}
        <div className="flex-1 max-w-[966px] flex flex-col">
          {/* Header */}
          <h2 className="text-3xl font-bold text-gray-900 mb-8">Payment methods</h2>

          {/* Payment Methods Grid */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Payment Method Cards */}
            {paymentMethods.map((method) => (
              <div 
                key={method.id} 
                className="border border-gray-200 rounded-lg p-5 bg-white"
              >
                <div className="flex justify-between items-center mb-6">
                  {/* Card Logo - Using inline SVG component instead of loading image */}
                  <div className="h-5">
                    <CardLogo type={method.type} />
                  </div>
                  
                  {/* Primary Badge */}
                  {method.id === primaryMethodId ? (
                    <span className="text-xs text-white bg-blue-600 px-2 py-0.5 rounded-md">
                      Primary
                    </span>
                  ) : (
                    <Button 
                      variant="ghost" 
                      onClick={() => setPrimaryMethod(method.id)}
                      className="text-xs text-blue-600 hover:bg-blue-50 px-2 py-0.5 h-auto rounded-md"
                    >
                      Set as primary
                    </Button>
                  )}
                </div>

                {/* Card Number */}
                <div className="text-gray-900 font-medium mb-1">
                  {method.cardNumber}
                </div>

                {/* Expiry Date */}
                <div className={`text-sm mb-5 ${method.isExpired ? 'text-red-500' : 'text-gray-500'}`}>
                  {method.isExpired ? 'Expired ' : 'Expiration '}{method.expiryDate}
                </div>

                {/* Actions */}
                <div className="flex gap-2">
                  <Button 
                    variant="outline" 
                    className="text-gray-500 text-sm px-3 py-1 h-8 rounded-md border-gray-200 hover:bg-gray-50"
                  >
                    Edit
                  </Button>
                  <Button 
                    variant="outline" 
                    className="text-gray-500 text-sm px-3 py-1 h-8 rounded-md border-gray-200 hover:bg-gray-50"
                  >
                    Remove
                  </Button>
                </div>
              </div>
            ))}

            {/* Add New Payment Method Card */}
            <div className="border border-gray-200 border-dashed rounded-lg p-5 flex flex-col items-center justify-center text-center h-[180px] cursor-pointer hover:bg-gray-50 transition-colors">
              <div className="w-8 h-8 bg-gray-50 rounded-full flex items-center justify-center mb-2">
                <PlusIcon size={16} className="text-gray-500" />
              </div>
              <span className="text-gray-900 font-medium">Add payment method</span>
            </div>
          </div>
        </div>
      </main>
      
      <CtaFooterByAnima />
    </div>
  );
}; 