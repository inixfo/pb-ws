import {
  BellIcon,
  ChevronRightIcon,
  CreditCardIcon,
  FileTextIcon,
  HeartIcon,
  HelpCircleIcon,
  LogOutIcon,
  MapPinIcon,
  MoreVerticalIcon,
  ShoppingCartIcon,
  StarIcon,
  TrashIcon,
  UserIcon,
} from "lucide-react";
import React, { useState } from "react";
import { Avatar, AvatarFallback } from "../../components/ui/avatar/Avatar";
import { Badge } from "../../components/ui/badge";
import { Button } from "../../components/ui/button";
import { Checkbox } from "../../components/ui/Checkbox";
import { Separator } from "../../components/ui/separator";
import { HeaderByAnima } from "../ElectronicsStore/sections/HeaderByAnima/HeaderByAnima";
import { CtaFooterByAnima } from "../ElectronicsStore/sections/CtaFooterByAnima/CtaFooterByAnima";
import { Select } from "../../components/ui/Select";
import { Link, useNavigate } from "react-router-dom";

// Sidebar menu items
const accountMenuItems = [
  {
    icon: <UserIcon size={16} />,
    label: "Orders",
    href: "/account",
    active: false,
  },
  { 
    icon: <HeartIcon size={16} />, 
    label: "Wishlist", 
    href: "/wishlist", 
    active: true,
    badge: "8",
  },
  { 
    icon: <CreditCardIcon size={16} />, 
    label: "Payment methods", 
    href: "/payment-methods", 
    active: false 
  },
  { 
    icon: <CreditCardIcon size={16} />, 
    label: "My EMI", 
    href: "/my-emi",
    active: false
  },
  { 
    icon: <StarIcon size={16} />, 
    label: "My reviews", 
    href: "/my-reviews", 
    active: false 
  },
];

const manageAccountItems = [
  { icon: <UserIcon size={16} />, label: "Personal info", href: "/personal-info", active: false },
  { icon: <MapPinIcon size={16} />, label: "Addresses", href: "/addresses", active: false },
  { icon: <BellIcon size={16} />, label: "Notifications", href: "/notifications", active: false },
];

const customerServiceItems = [
  { icon: <HelpCircleIcon size={16} />, label: "Help center", href: "#" },
  {
    icon: <FileTextIcon size={16} />,
    label: "Terms and conditions",
    href: "#",
  },
];

// Wishlist products data
const wishlistProducts = [
  {
    id: 1,
    name: "VRB01 Virtual Reality Glasses",
    price: "$340.99",
    originalPrice: "$430.00",
    discountPercent: "21",
    image: "/image-1.png",
    rating: 4.5,
    ratingCount: "123",
    selected: true,
  },
  {
    id: 2,
    name: "Apple iPhone 14 128GB White",
    price: "$899.00",
    image: "/image-2.png",
    rating: 4,
    ratingCount: "142",
    selected: true,
  },
  {
    id: 3,
    name: "Smart Watch Series 7, White",
    price: "$429.00",
    image: "/image-3.png",
    rating: 5,
    ratingCount: "54",
    selected: false,
  },
];

// Filter options
const sortOptions = [
  { value: "date-added", label: "By date added" },
  { value: "price-low", label: "Price: Low to High" },
  { value: "price-high", label: "Price: High to Low" },
  { value: "name-asc", label: "Name: A to Z" },
  { value: "name-desc", label: "Name: Z to A" },
];

export const Wishlist = (): JSX.Element => {
  const [selectedProducts, setSelectedProducts] = useState<number[]>(
    wishlistProducts.filter(p => p.selected).map(p => p.id)
  );
  const [allSelected, setAllSelected] = useState(false);
  const navigate = useNavigate();

  const toggleSelectAll = () => {
    if (allSelected) {
      setSelectedProducts([]);
    } else {
      setSelectedProducts(wishlistProducts.map(p => p.id));
    }
    setAllSelected(!allSelected);
  };

  const toggleProductSelection = (id: number) => {
    if (selectedProducts.includes(id)) {
      setSelectedProducts(selectedProducts.filter(productId => productId !== id));
      setAllSelected(false);
    } else {
      setSelectedProducts([...selectedProducts, id]);
      if (selectedProducts.length + 1 === wishlistProducts.length) {
        setAllSelected(true);
      }
    }
  };

  return (
    <div className="flex flex-col w-full bg-white min-h-screen">
      <HeaderByAnima showHeroSection={false} />
      
      {/* Main Content */}
      <main className="container mx-auto flex flex-col lg:flex-row gap-6 lg:gap-12 px-4 py-8 md:py-16">
        {/* Sidebar */}
        <aside className="w-full lg:w-[282px] flex flex-col gap-6">
          {/* User Profile */}
          <div className="flex items-center gap-4">
            <Avatar className="w-12 h-12 bg-blue-100 rounded-3xl">
              <AvatarFallback className="text-blue-500 font-semibold">
                S
              </AvatarFallback>
            </Avatar>
            <div className="flex flex-col gap-1 flex-1">
              <h6 className="font-semibold text-gray-900">
                Susan Gardner
              </h6>
              <div className="flex items-center gap-2">
                <img
                  className="w-3.5 h-3.5"
                  alt="Bonus icon"
                  src="/group.png"
                />
                <span className="text-sm text-gray-800">
                  <span className="text-[#4e5562]">
                    100 bonuses
                  </span>
                  <span className="font-semibold">&nbsp;</span>
                  <span>available</span>
                </span>
              </div>
            </div>
          </div>

          {/* Account Navigation */}
          <nav className="flex flex-col gap-0.5">
            {accountMenuItems.map((item, index) => (
              <Button
                key={index}
                variant={item.active ? "secondary" : "ghost"}
                className={`justify-start gap-2 px-3 py-2.5 h-auto rounded-lg ${item.active ? "bg-gray-100" : ""}`}
                asChild
              >
                <Link to={item.href}>
                  {React.cloneElement(item.icon, { className: "text-gray-700" })}
                  <span
                    className={`flex-1 text-left text-sm ${item.active ? "text-gray-900" : "text-gray-700"}`}
                  >
                    {item.label}
                  </span>
                  {item.badge && (
                    <Badge className="bg-primarymain text-white-100 rounded-full px-2 py-0.5 text-xs">
                      {item.badge}
                    </Badge>
                  )}
                </Link>
              </Button>
            ))}
          </nav>

          {/* Manage Account Section */}
          <div className="flex flex-col gap-2">
            <h6 className="px-4 font-semibold text-gray-900">
              Manage account
            </h6>
            <div className="flex flex-col gap-0.5">
              {manageAccountItems.map((item, index) => (
                <Button
                  key={index}
                  variant={item.active ? "secondary" : "ghost"}
                  className={`justify-start gap-2 px-3 py-2.5 h-auto rounded-lg ${item.active ? "bg-gray-100" : ""}`}
                  asChild
                >
                  <Link to={item.href}>
                    {React.cloneElement(item.icon, {
                      className: "text-gray-700",
                    })}
                    <span className={`flex-1 text-left text-sm ${item.active ? "text-gray-900" : "text-gray-700"}`}>
                      {item.label}
                    </span>
                  </Link>
                </Button>
              ))}
            </div>
          </div>

          {/* Customer Service Section */}
          <div className="flex flex-col gap-2">
            <h6 className="px-4 font-semibold text-gray-900">
              Customer service
            </h6>
            <div className="flex flex-col gap-0.5">
              {customerServiceItems.map((item, index) => (
                <Button
                  key={index}
                  variant="ghost"
                  className="justify-start gap-2 px-3 py-2.5 h-auto rounded-lg"
                  asChild
                >
                  <Link to={item.href}>
                    {React.cloneElement(item.icon, {
                      className: "text-gray-700",
                    })}
                    <span className="flex-1 text-left text-sm text-gray-700">
                      {item.label}
                    </span>
                  </Link>
                </Button>
              ))}
            </div>
          </div>

          {/* Log Out Button */}
          <Button
            variant="ghost"
            className="justify-start gap-2 px-3 py-2.5 h-auto rounded-lg"
            onClick={() => navigate('/')}
          >
            <LogOutIcon size={16} className="text-gray-700" />
            <span className="flex-1 text-left text-sm text-gray-700">
              Log out
            </span>
          </Button>
        </aside>

        {/* Main Content Area */}
        <div className="flex-1 max-w-[966px] flex flex-col gap-6">
          {/* Header with Add Wishlist Button */}
          <div className="flex justify-between items-center">
            <h2 className="text-3xl font-bold text-gray-900">Wishlist</h2>
            <Button variant="outline" className="gap-2 border-gray-200 text-gray-800 hover:bg-gray-50">
              <PlusIcon size={16} />
              Add wishlist
            </Button>
          </div>

          {/* Interesting Offers Section */}
          <div className="flex justify-between items-center">
            <div className="flex items-center gap-2">
              <h3 className="text-lg font-semibold text-gray-900">Interesting offers</h3>
              <Button variant="ghost" size="icon" className="p-1">
                <MoreVerticalIcon size={16} className="text-gray-500" />
              </Button>
            </div>
            <Select 
              options={sortOptions}
              value="date-added"
              className="w-[180px]"
            />
          </div>

          {/* Action Buttons */}
          <div className="flex flex-wrap gap-3">
            <Button 
              variant="outline" 
              className="gap-2 border-gray-200 text-gray-800 h-10 px-4 hover:bg-gray-50"
              onClick={toggleSelectAll}
            >
              <Checkbox 
                checked={allSelected}
                className="data-[state=checked]:bg-blue-500 data-[state=checked]:border-blue-500"
              />
              Unselect all
            </Button>

            <Button 
              variant="outline" 
              className="gap-2 border-gray-200 text-gray-800 h-10 px-4 hover:bg-gray-50"
              disabled={selectedProducts.length === 0}
            >
              <ShoppingCartIcon size={16} />
              Add to cart
            </Button>

            <Button 
              variant="outline" 
              className="gap-2 border-gray-200 text-gray-800 h-10 px-4 hover:bg-gray-50"
              disabled={selectedProducts.length === 0}
            >
              <MoveIcon size={16} />
              Relocate
            </Button>

            <Button 
              variant="outline" 
              className="gap-2 border-gray-200 text-gray-800 h-10 px-4 hover:bg-gray-50"
              disabled={selectedProducts.length === 0}
            >
              <TrashIcon size={16} />
              Remove selected
            </Button>
          </div>

          <Separator className="bg-gray-200" />

          {/* Products List */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-x-5 gap-y-6">
            {wishlistProducts.map((product) => {
              const isSelected = selectedProducts.includes(product.id);
              
              return (
                <div key={product.id} className="relative border border-gray-200 rounded-lg bg-white p-4 pb-12">
                  {/* Discount Badge */}
                  {product.discountPercent && (
                    <div className="absolute top-4 left-4 bg-red-500 text-white px-2 py-0.5 text-xs font-medium rounded z-10">
                      -{product.discountPercent}%
                    </div>
                  )}
                  
                  {/* Checkbox */}
                  <div className={`absolute ${product.discountPercent ? 'top-12' : 'top-4'} left-4 z-10`}>
                    <Checkbox 
                      checked={isSelected}
                      onChange={() => toggleProductSelection(product.id)}
                      className="bg-white border-gray-300 data-[state=checked]:bg-blue-500 data-[state=checked]:border-blue-500"
                    />
                  </div>
                  
                  {/* Product Image */}
                  <div className="flex justify-center items-center h-40 mt-8 mb-2">
                    <img 
                      src={product.image}
                      alt={product.name}
                      className="max-h-full max-w-full object-contain"
                    />
                  </div>
                  
                  {/* Rating */}
                  <div className="flex items-center gap-0.5 mb-1">
                    {Array(5).fill(0).map((_, i) => (
                      <StarIcon 
                        key={i} 
                        size={14} 
                        className={`${
                          i < Math.floor(product.rating) 
                            ? "text-yellow-400 fill-yellow-400" 
                            : i < product.rating 
                              ? "text-yellow-400 fill-yellow-400" 
                              : "text-gray-300"
                        }`} 
                      />
                    ))}
                    <span className="text-gray-400 text-xs ml-1">({product.ratingCount})</span>
                  </div>
                  
                  {/* Product Name */}
                  <h3 className="font-medium text-sm text-gray-900 mb-1">{product.name}</h3>
                  
                  {/* Price */}
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-gray-900">{product.price}</span>
                    {product.originalPrice && (
                      <span className="text-sm text-gray-400 line-through">{product.originalPrice}</span>
                    )}
                  </div>

                  {/* Cart Button */}
                  <div className="absolute bottom-4 right-4">
                    <Button 
                      variant="outline" 
                      className="w-8 h-8 p-0 border-gray-200 rounded flex items-center justify-center"
                    >
                      <ShoppingCartIcon size={16} className="text-gray-700" />
                    </Button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </main>
      
      <CtaFooterByAnima />
    </div>
  );
};

// Simple Plus Icon component
const PlusIcon = ({ size = 24, className = "" }) => (
  <svg 
    xmlns="http://www.w3.org/2000/svg" 
    width={size} 
    height={size} 
    viewBox="0 0 24 24" 
    fill="none" 
    stroke="currentColor" 
    strokeWidth="2" 
    strokeLinecap="round" 
    strokeLinejoin="round" 
    className={className}
  >
    <line x1="12" y1="5" x2="12" y2="19"></line>
    <line x1="5" y1="12" x2="19" y2="12"></line>
  </svg>
);

// Move Icon component
const MoveIcon = ({ size = 24, className = "" }) => (
  <svg 
    xmlns="http://www.w3.org/2000/svg" 
    width={size} 
    height={size} 
    viewBox="0 0 24 24" 
    fill="none" 
    stroke="currentColor" 
    strokeWidth="2" 
    strokeLinecap="round" 
    strokeLinejoin="round" 
    className={className}
  >
    <path d="M5 9l-3 3 3 3"></path>
    <path d="M9 5l3-3 3 3"></path>
    <path d="M15 19l3 3 3-3"></path>
    <path d="M19 9l3 3-3 3"></path>
    <path d="M2 12h20"></path>
    <path d="M12 2v20"></path>
  </svg>
); 