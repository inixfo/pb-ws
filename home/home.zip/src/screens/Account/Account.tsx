import {
  BellIcon,
  ChevronRightIcon,
  CreditCardIcon,
  FileTextIcon,
  HeartIcon,
  HelpCircleIcon,
  LogOutIcon,
  MapPinIcon,
  StarIcon,
  UserIcon,
  XIcon,
  MapPinIcon as LocationIcon,
  TruckIcon,
  MenuIcon
} from "lucide-react";
import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Avatar, AvatarFallback } from "../../components/ui/avatar/Avatar";
import { Badge } from "../../components/ui/badge";
import { Button } from "../../components/ui/button";
import { Card, CardContent } from "../../components/ui/card";
import PaginationComponent, {
  PaginationItem,
  PaginationLink,
} from "../../components/ui/pagination";
import { Select } from "../../components/ui/Select";
import { Separator } from "../../components/ui/separator";
import { HeaderByAnima } from "../ElectronicsStore/sections/HeaderByAnima/HeaderByAnima";
import { CtaFooterByAnima } from "../ElectronicsStore/sections/CtaFooterByAnima/CtaFooterByAnima";

// Rename the imported component to maintain compatibility with existing code
const Pagination = PaginationComponent;

// Sidebar menu items
const accountMenuItems = [
  {
    icon: <UserIcon size={16} />,
    label: "Orders",
    href: "/account",
    active: true,
    badge: "1",
  },
  { 
    icon: <HeartIcon size={16} />, 
    label: "Wishlist", 
    href: "/wishlist",
    active: false
  },
  { 
    icon: <CreditCardIcon size={16} />, 
    label: "Payment methods", 
    href: "/payment-methods",
    active: false
  },
  { 
    icon: <CreditCardIcon size={16} />, 
    label: "My EMI", 
    href: "/my-emi",
    active: false
  },
  { 
    icon: <StarIcon size={16} />, 
    label: "My reviews", 
    href: "/my-reviews",
    active: false
  },
];

const manageAccountItems = [
  { icon: <UserIcon size={16} />, label: "Personal info", href: "/personal-info", active: false },
  { icon: <MapPinIcon size={16} />, label: "Addresses", href: "/addresses", active: false },
  { icon: <BellIcon size={16} />, label: "Notifications", href: "/notifications", active: false },
];

const customerServiceItems = [
  { icon: <HelpCircleIcon size={16} />, label: "Help center", href: "/help-center" },
  {
    icon: <FileTextIcon size={16} />,
    label: "Terms and conditions",
    href: "/terms",
  },
];

// Order product type
interface OrderProduct {
  name: string;
  price: string;
  image: string;
  quantity: number;
}

// Orders data
interface Order {
  id: string;
  date: string;
  status: string;
  statusColor: string;
  total: string;
  images: string[];
  extraImages?: number;
  products?: OrderProduct[];
  shippingMethod?: string;
  shippingAddress?: string;
  city?: string;
  estimatedDelivery?: string;
  paymentMethod?: string;
  tax?: string;
  shipping?: string;
}

const orders: Order[] = [
  {
    id: "78A6431D409",
    date: "Feb 6, 2025",
    status: "In progress",
    statusColor: "infomain",
    total: "$2,105.90",
    images: ["/image.png", "/image-1.png", "/image-2.png"],
    products: [
      {
        name: "Smart Watch Series 7, White",
        price: "$429.00",
        image: "/image.png",
        quantity: 1
      },
      {
        name: "Apple iPhone 14 128GB White",
        price: "$899.00",
        image: "/image-1.png",
        quantity: 1
      },
      {
        name: "Tablet Apple iPad Pro M2",
        price: "$989.00",
        image: "/image-2.png",
        quantity: 1
      }
    ],
    shippingMethod: "Courier delivery",
    shippingAddress: "567 Cherry Lane Apt B12",
    city: "Harrisburg",
    estimatedDelivery: "Feb 8, 2025 / 10:00 - 12:00",
    paymentMethod: "Cash on delivery",
    tax: "$12.40",
    shipping: "$26.50"
  },
  {
    id: "47H76G09F33",
    date: "Dec 12, 2024",
    status: "Delivered",
    statusColor: "successmain",
    total: "$360.75",
    images: ["/image-3.png"],
  },
  {
    id: "502TR872W2",
    date: "Nov 7, 2024",
    status: "Delivered",
    statusColor: "successmain",
    total: "$4,268.00",
    images: ["/image-4.png", "/image-5.png", "/image-6.png"],
    extraImages: 3,
  },
  {
    id: "34VB5540K83",
    date: "Sep 15, 2024",
    status: "Canceled",
    statusColor: "dangermain",
    total: "$987.50",
    images: ["/image-7.png", "/image-8.png"],
  },
  {
    id: "112P45A90V2",
    date: "May 12, 2024",
    status: "Delivered",
    statusColor: "successmain",
    total: "$53.00",
    images: ["/image-9.png"],
  },
  {
    id: "28BA67U0981",
    date: "Apr 20, 2024",
    status: "Canceled",
    statusColor: "dangermain",
    total: "$1,029.50",
    images: ["/image-10.png", "/image-11.png"],
  },
];

export const Account = (): JSX.Element => {
  const navigate = useNavigate();
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const [drawerOpen, setDrawerOpen] = useState<boolean>(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState<boolean>(false);

  const openDrawer = (order: Order) => {
    setSelectedOrder(order);
    setDrawerOpen(true);
  };

  const closeDrawer = () => {
    setDrawerOpen(false);
  };

  const toggleMobileMenu = () => {
    setMobileMenuOpen(!mobileMenuOpen);
  };

  return (
    <div className="flex flex-col w-full bg-white-100 min-h-screen">
      <HeaderByAnima showHeroSection={false} />
      
      {/* Main Content */}
      <main className="container mx-auto flex flex-col lg:flex-row gap-6 lg:gap-12 px-4 py-8 md:py-16">
        {/* Mobile User Profile with Hamburger */}
        <div className="flex items-center justify-between lg:hidden w-full mb-4">
          <div className="flex items-center gap-4">
            <Avatar className="w-12 h-12 bg-blue-100 rounded-3xl">
              <AvatarFallback className="text-blue-500 font-semibold">
                S
              </AvatarFallback>
            </Avatar>
            <div className="flex flex-col gap-1">
              <h6 className="font-semibold text-gray-900">
                Susan Gardner
              </h6>
              <div className="flex items-center gap-2">
                <img
                  className="w-3.5 h-3.5"
                  alt="Bonus icon"
                  src="/group.png"
                />
                <span className="text-sm text-gray-800">
                  100 bonuses available
                </span>
              </div>
            </div>
          </div>
          <Button 
            variant="ghost" 
            size="icon"
            className="h-10 w-10 rounded-full hover:bg-gray-100"
            onClick={toggleMobileMenu}
          >
            <MenuIcon className="h-6 w-6" />
          </Button>
        </div>

        {/* Mobile Menu Overlay */}
        {mobileMenuOpen && (
          <div className="fixed inset-0 z-40 lg:hidden" onClick={toggleMobileMenu}>
            <div className="absolute inset-0 bg-black/40"></div>
            <div 
              className="absolute right-0 top-0 h-full w-4/5 max-w-sm bg-white shadow-xl p-6 overflow-y-auto"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="flex justify-end mb-6">
                <Button 
                  variant="ghost" 
                  size="icon"
                  className="h-8 w-8"
                  onClick={toggleMobileMenu}
                >
                  <XIcon className="h-5 w-5" />
                </Button>
              </div>
              
              {/* Mobile Nav Items */}
              <div className="space-y-6">
                {/* User Profile (Mobile) */}
                <div className="flex items-center gap-4 mb-4">
                  <Avatar className="w-12 h-12 bg-blue-100 rounded-3xl">
                    <AvatarFallback className="text-blue-500 font-semibold">
                      S
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex flex-col gap-1">
                    <h6 className="font-semibold text-gray-900">
                      Susan Gardner
                    </h6>
                    <div className="flex items-center gap-2">
                      <img
                        className="w-3.5 h-3.5"
                        alt="Bonus icon"
                        src="/group.png"
                      />
                      <span className="text-sm text-gray-800">
                        100 bonuses available
                      </span>
                    </div>
                  </div>
                </div>
                
                <Separator />
                
                {/* Account Navigation (Mobile) */}
                <div>
                  <h6 className="font-semibold text-gray-900 mb-2">Account</h6>
                  <nav className="flex flex-col gap-1">
                    {accountMenuItems.map((item, index) => (
                      <Button
                        key={index}
                        variant={item.active ? "secondary" : "ghost"}
                        className={`justify-start gap-2 px-3 py-2.5 h-auto rounded-lg transition-colors ${
                          item.active 
                            ? "bg-gray-100" 
                            : "hover:bg-gray-50"
                        }`}
                        asChild
                        onClick={toggleMobileMenu}
                      >
                        <Link to={item.href}>
                          {React.cloneElement(item.icon, { className: "text-gray-700" })}
                          <span
                            className={`flex-1 text-left text-sm ${item.active ? "text-gray-900" : "text-gray-700"}`}
                          >
                            {item.label}
                          </span>
                          {item.badge && (
                            <Badge className="bg-primarymain text-white-100 rounded-full px-2 py-0.5 text-xs">
                              {item.badge}
                            </Badge>
                          )}
                        </Link>
                      </Button>
                    ))}
                  </nav>
                </div>
                
                {/* Manage Account Section (Mobile) */}
                <div>
                  <h6 className="font-semibold text-gray-900 mb-2">
                    Manage account
                  </h6>
                  <div className="flex flex-col gap-1">
                    {manageAccountItems.map((item, index) => (
                      <Button
                        key={index}
                        variant={item.active ? "secondary" : "ghost"}
                        className={`justify-start gap-2 px-3 py-2.5 h-auto rounded-lg transition-colors ${
                          item.active 
                            ? "bg-gray-100" 
                            : "hover:bg-gray-50"
                        }`}
                        asChild
                        onClick={toggleMobileMenu}
                      >
                        <Link to={item.href}>
                          {React.cloneElement(item.icon, {
                            className: "text-gray-700",
                          })}
                          <span className={`flex-1 text-left text-sm ${item.active ? "text-gray-900" : "text-gray-700"}`}>
                            {item.label}
                          </span>
                        </Link>
                      </Button>
                    ))}
                  </div>
                </div>
                
                {/* Customer Service Section (Mobile) */}
                <div>
                  <h6 className="font-semibold text-gray-900 mb-2">
                    Customer service
                  </h6>
                  <div className="flex flex-col gap-1">
                    {customerServiceItems.map((item, index) => (
                      <Button
                        key={index}
                        variant="ghost"
                        className="justify-start gap-2 px-3 py-2.5 h-auto rounded-lg hover:bg-gray-50 transition-colors"
                        asChild
                        onClick={toggleMobileMenu}
                      >
                        <Link to={item.href}>
                          {React.cloneElement(item.icon, {
                            className: "text-gray-700",
                          })}
                          <span className="flex-1 text-left text-sm text-gray-700">
                            {item.label}
                          </span>
                        </Link>
                      </Button>
                    ))}
                  </div>
                </div>
                
                {/* Log Out Button (Mobile) */}
                <Button
                  variant="ghost"
                  className="justify-start gap-2 px-3 py-2.5 h-auto rounded-lg w-full hover:bg-gray-50 transition-colors"
                  asChild
                  onClick={toggleMobileMenu}
                >
                  <Link to="/">
                    <LogOutIcon size={16} className="text-gray-700" />
                    <span className="flex-1 text-left text-sm text-gray-700">
                      Log out
                    </span>
                  </Link>
                </Button>
              </div>
            </div>
          </div>
        )}

        {/* Desktop Sidebar */}
        <aside className="hidden lg:flex lg:w-[282px] flex-col gap-6">
          {/* User Profile */}
          <div className="flex items-center gap-4">
            <Avatar className="w-12 h-12 bg-blue-100 rounded-3xl">
              <AvatarFallback className="text-blue-500 font-semibold">
                S
              </AvatarFallback>
            </Avatar>
            <div className="flex flex-col gap-1 flex-1">
              <h6 className="font-semibold text-gray-900">
                Susan Gardner
              </h6>
              <div className="flex items-center gap-2">
                <img
                  className="w-3.5 h-3.5"
                  alt="Bonus icon"
                  src="/group.png"
                />
                <span className="text-sm text-gray-800">
                  <span className="text-[#4e5562]">
                    100 bonuses
                  </span>
                  <span className="font-semibold">&nbsp;</span>
                  <span>available</span>
                </span>
              </div>
            </div>
          </div>

          {/* Account Navigation */}
          <nav className="flex flex-col gap-0.5">
            {accountMenuItems.map((item, index) => (
              <Button
                key={index}
                variant={item.active ? "secondary" : "ghost"}
                className={`justify-start gap-2 px-3 py-2.5 h-auto rounded-lg transition-colors ${
                  item.active 
                    ? "bg-gray-100" 
                    : "hover:bg-gray-50"
                }`}
                asChild
              >
                <Link to={item.href}>
                  {React.cloneElement(item.icon, { className: "text-gray-700" })}
                  <span
                    className={`flex-1 text-left text-sm ${item.active ? "text-gray-900" : "text-gray-700"}`}
                  >
                    {item.label}
                  </span>
                  {item.badge && (
                    <Badge className="bg-primarymain text-white-100 rounded-full px-2 py-0.5 text-xs">
                      {item.badge}
                    </Badge>
                  )}
                </Link>
              </Button>
            ))}
          </nav>

          {/* Manage Account Section */}
          <div className="flex flex-col gap-2">
            <h6 className="px-4 font-semibold text-gray-900">
              Manage account
            </h6>
            <div className="flex flex-col gap-0.5">
              {manageAccountItems.map((item, index) => (
                <Button
                  key={index}
                  variant={item.active ? "secondary" : "ghost"}
                  className={`justify-start gap-2 px-3 py-2.5 h-auto rounded-lg transition-colors ${
                    item.active 
                      ? "bg-gray-100" 
                      : "hover:bg-gray-50"
                  }`}
                  asChild
                >
                  <Link to={item.href}>
                    {React.cloneElement(item.icon, {
                      className: "text-gray-700",
                    })}
                    <span className={`flex-1 text-left text-sm ${item.active ? "text-gray-900" : "text-gray-700"}`}>
                      {item.label}
                    </span>
                  </Link>
                </Button>
              ))}
            </div>
          </div>

          {/* Customer Service Section */}
          <div className="flex flex-col gap-2">
            <h6 className="px-4 font-semibold text-gray-900">
              Customer service
            </h6>
            <div className="flex flex-col gap-0.5">
              {customerServiceItems.map((item, index) => (
                <Button
                  key={index}
                  variant="ghost"
                  className="justify-start gap-2 px-3 py-2.5 h-auto rounded-lg hover:bg-gray-50 transition-colors"
                  asChild
                >
                  <Link to={item.href}>
                    {React.cloneElement(item.icon, {
                      className: "text-gray-700",
                    })}
                    <span className="flex-1 text-left text-sm text-gray-700">
                      {item.label}
                    </span>
                  </Link>
                </Button>
              ))}
            </div>
          </div>

          {/* Log Out Button */}
          <Button
            variant="ghost"
            className="justify-start gap-2 px-3 py-2.5 h-auto rounded-lg hover:bg-gray-50 transition-colors"
            asChild
          >
            <Link to="/">
              <LogOutIcon size={16} className="text-gray-700" />
              <span className="flex-1 text-left text-sm text-gray-700">
                Log out
              </span>
            </Link>
          </Button>
        </aside>

        {/* Main Content Area */}
        <div className="flex-1 max-w-[966px] flex flex-col gap-10">
          {/* Header with Filters */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 sm:gap-0">
            <h2 className="text-2xl md:text-3xl font-bold text-gray-900">Orders</h2>
            <div className="flex flex-col sm:flex-row gap-3 sm:gap-6">
              <Select
                options={[
                  { value: "all", label: "Select status" },
                  { value: "in-progress", label: "In progress" },
                  { value: "delivered", label: "Delivered" },
                  { value: "canceled", label: "Canceled" }
                ]}
                value="all"
                className="w-full sm:w-[196px]"
              />

              <Select
                options={[
                  { value: "all-time", label: "For all time" },
                  { value: "this-month", label: "This month" },
                  { value: "last-month", label: "Last month" }
                ]}
                value="all-time"
                className="w-full sm:w-[196px]"
              />
            </div>
          </div>

          {/* Orders Table */}
          <Card className="border-0 shadow-none">
            <CardContent className="p-0 space-y-8">
              {/* Table Header - Hidden on Mobile */}
              <div className="hidden md:block space-y-5">
                <div className="flex gap-4">
                  <div className="w-[147px] text-sm text-gray-600">Order #</div>
                  <div className="w-[147px] text-sm text-gray-600">
                    Order date
                  </div>
                  <div className="w-[147px] text-sm text-gray-600">Status</div>
                  <div className="w-[147px] text-sm text-gray-600">Total</div>
                </div>
                <Separator />
              </div>

              {/* Order Rows */}
              <div className="space-y-5">
                {orders.map((order, index) => (
                  <div key={index} className="space-y-5">
                    <div 
                      className="flex flex-col md:flex-row md:items-center justify-between gap-4 md:gap-0 md:h-16 cursor-pointer rounded-lg hover:bg-gray-50 transition-colors p-2" 
                      onClick={() => openDrawer(order)}
                    >
                      <div className="flex flex-col md:flex-row gap-2 md:gap-4">
                        <div className="w-full md:w-[147px] text-sm md:text-base font-medium text-gray-900">
                          <span className="md:hidden font-normal text-gray-600 mr-2">Order #:</span>
                          {order.id}
                        </div>
                        <div className="w-full md:w-[147px] text-sm md:text-base font-medium text-gray-900">
                          <span className="md:hidden font-normal text-gray-600 mr-2">Date:</span>
                          {order.date}
                        </div>
                        <div className="w-full md:w-[147px] flex items-center gap-1">
                          <div className="p-1">
                            <div
                              className={`w-2 h-2 rounded ${
                                order.statusColor === "infomain" 
                                  ? "bg-blue-500" 
                                  : order.statusColor === "successmain" 
                                  ? "bg-green-500" 
                                  : order.statusColor === "dangermain"
                                  ? "bg-red-500"
                                  : ""
                              }`}
                            />
                          </div>
                          <div className="text-sm md:text-base font-medium text-gray-900">
                            <span className="md:hidden font-normal text-gray-600 mr-2">Status:</span>
                            {order.status}
                          </div>
                        </div>
                        <div className="w-full md:w-[147px] text-sm md:text-base font-medium text-gray-900">
                          <span className="md:hidden font-normal text-gray-600 mr-2">Total:</span>
                          {order.total}
                        </div>
                      </div>

                      <div className="flex items-center gap-3 mt-2 md:mt-0">
                        <div className="flex items-center gap-2 justify-end overflow-x-auto">
                          {order.images.map((img, imgIndex) => (
                            <img
                              key={imgIndex}
                              className="w-16 h-16 object-cover rounded-md"
                              alt="Product"
                              src={img}
                            />
                          ))}
                          {order.extraImages && (
                            <div className="p-2.5">
                              <div className="w-7 text-center text-sm font-medium text-gray-900">
                                +{order.extraImages}
                              </div>
                            </div>
                          )}
                        </div>
                        <ChevronRightIcon className="w-4 h-4 text-gray-600 flex-shrink-0" />
                      </div>
                    </div>
                    <Separator />
                  </div>
                ))}
              </div>

              {/* Pagination */}
              <Pagination className="flex items-start gap-1">
                <PaginationItem>
                  <PaginationLink
                    className="p-1.5 bg-gray-100 rounded-md"
                    isActive
                  >
                    1
                  </PaginationLink>
                </PaginationItem>
                <PaginationItem>
                  <PaginationLink className="p-1.5 bg-gray-50 rounded-md hover:bg-gray-100 transition-colors">
                    2
                  </PaginationLink>
                </PaginationItem>
                <PaginationItem>
                  <PaginationLink className="p-1.5 text-gray-600 rounded-md hover:bg-gray-100 transition-colors">
                    3
                  </PaginationLink>
                </PaginationItem>
                <PaginationItem>
                  <PaginationLink className="p-1.5 text-gray-600 rounded-md hover:bg-gray-100 transition-colors">
                    4
                  </PaginationLink>
                </PaginationItem>
              </Pagination>
            </CardContent>
          </Card>
        </div>
      </main>
      
      {/* Order Details Drawer */}
      {drawerOpen && selectedOrder && (
        <div className="fixed inset-0 z-50 flex">
          {/* Backdrop */}
          <div 
            className="fixed inset-0 bg-black/40" 
            onClick={closeDrawer}
          />
          
          {/* Drawer */}
          <div className="fixed top-0 right-0 h-full w-full md:w-[450px] bg-white shadow-xl transition-transform overflow-auto">
            <div className="flex flex-col h-full">
              {/* Header */}
              <div className="flex items-center justify-between p-6 border-b">
                <h2 className="text-xl font-semibold">
                  Order # {selectedOrder.id}
                </h2>
                <Button
                  variant="ghost"
                  size="sm"
                  className="p-1 h-8 w-8"
                  onClick={closeDrawer}
                >
                  <XIcon className="w-5 h-5" />
                </Button>
              </div>
              
              {/* Content */}
              <div className="flex-1 overflow-y-auto">
                {/* Status */}
                <div className="p-6 border-b">
                  <div className="flex items-center gap-2">
                    <div
                      className={`w-2 h-2 rounded ${
                        selectedOrder.statusColor === "infomain" 
                          ? "bg-blue-500" 
                          : selectedOrder.statusColor === "successmain" 
                          ? "bg-green-500" 
                          : selectedOrder.statusColor === "dangermain"
                          ? "bg-red-500"
                          : ""
                      }`}
                    />
                    <span className="text-sm font-medium text-gray-900">{selectedOrder.status}</span>
                  </div>
                </div>

                {/* Products */}
                <div className="p-6 border-b">
                  {selectedOrder.products?.map((product, index) => (
                    <div key={index} className="flex gap-4 mb-6 last:mb-0">
                      <img 
                        src={product.image} 
                        alt={product.name} 
                        className="w-24 h-24 object-cover rounded-md"
                      />
                      <div className="flex flex-col flex-1">
                        <h3 className="text-base font-medium text-gray-900">{product.name}</h3>
                        <div className="flex justify-between items-center mt-2">
                          <span className="text-gray-900 font-semibold">{product.price}</span>
                          <span className="text-sm text-gray-500">Qty: {product.quantity}</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Delivery */}
                <div className="p-6 border-b">
                  <h3 className="text-base font-semibold mb-4">Delivery</h3>
                  
                  <div className="space-y-4">
                    <div className="flex">
                      <div className="w-32 text-sm text-gray-500">Estimated delivery date:</div>
                      <div className="text-sm font-medium flex-1">{selectedOrder.estimatedDelivery}</div>
                    </div>
                    
                    <div className="flex">
                      <div className="w-32 text-sm text-gray-500">Shipping method:</div>
                      <div className="text-sm font-medium flex-1">{selectedOrder.shippingMethod}</div>
                    </div>
                    
                    <div className="flex">
                      <div className="w-32 text-sm text-gray-500">Shipping address:</div>
                      <div className="text-sm font-medium flex-1">
                        {selectedOrder.shippingAddress}, {selectedOrder.city}
                      </div>
                    </div>
                  </div>
                </div>
                
                {/* Payment */}
                <div className="p-6">
                  <h3 className="text-base font-semibold mb-4">Payment</h3>
                  
                  <div className="space-y-4 mb-6">
                    <div className="flex">
                      <div className="w-32 text-sm text-gray-500">Payment method:</div>
                      <div className="text-sm font-medium flex-1">{selectedOrder.paymentMethod}</div>
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-sm text-gray-500">Tax collected:</span>
                      <span className="text-sm font-medium">{selectedOrder.tax}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm text-gray-500">Shipping:</span>
                      <span className="text-sm font-medium">{selectedOrder.shipping}</span>
                    </div>
                    <Separator className="my-2" />
                    <div className="flex justify-between">
                      <span className="text-sm font-medium">Total:</span>
                      <span className="text-sm font-semibold">{selectedOrder.total}</span>
                    </div>
                  </div>
                </div>
              </div>
              
              {/* Actions */}
              <div className="p-6 border-t">
                <Button className="w-full hover:bg-blue-600 transition-colors" variant="default">
                  <TruckIcon className="w-4 h-4 mr-2" />
                  Track Order
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}
      
      <CtaFooterByAnima />
    </div>
  );
}; 