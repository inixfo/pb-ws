import React, { useState } from "react";
import { Button } from "../../../../components/ui/button";
import { Card, CardContent, CardHeader, CardFooter } from "../../../../components/ui/card";
import { Input } from "../../../../components/ui/input";
import { Separator } from "../../../../components/ui/separator";
import { ChevronRightIcon, ArrowRightIcon, CheckIcon, TruckIcon, PackageIcon, PlusIcon, InfoIcon, CreditCardIcon, DollarSignIcon, BanknoteIcon, UploadIcon } from "lucide-react";
import { Select } from "../../../../components/ui/Select";

export const DeliveryInfoContent = (): JSX.Element => {
  const [city, setCity] = useState("");
  const [showShippingMethods, setShowShippingMethods] = useState(false);
  const [selectedShippingMethod, setSelectedShippingMethod] = useState("standard");
  const [currentStep, setCurrentStep] = useState(1);
  const [deliveryInfoCompleted, setDeliveryInfoCompleted] = useState(false);
  const [sameAsBilling, setSameAsBilling] = useState(true);
  const [shippingAddressCompleted, setShippingAddressCompleted] = useState(false);
  
  // Payment form state
  const [selectedPaymentMethod, setSelectedPaymentMethod] = useState("creditCard");
  const [cardNumber, setCardNumber] = useState("");
  const [expiryDate, setExpiryDate] = useState("");
  const [cvv, setCvv] = useState("");
  const [nameOnCard, setNameOnCard] = useState("");

  // EMI and Cardless EMI data
  const [salary, setSalary] = useState("");
  const [jobTitle, setJobTitle] = useState("");
  const [nidFrontPhoto, setNidFrontPhoto] = useState<File | null>(null);
  const [nidBackPhoto, setNidBackPhoto] = useState<File | null>(null);

  // Form fields for shipping address
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [postcode, setPostcode] = useState("");
  const [address, setAddress] = useState("");
  const [selectedCity, setSelectedCity] = useState("");
  const [country, setCountry] = useState("");

  // Form fields for billing address (only used if different from shipping)
  const [billingFirstName, setBillingFirstName] = useState("");
  const [billingLastName, setBillingLastName] = useState("");
  const [billingEmail, setBillingEmail] = useState("");
  const [billingPhone, setBillingPhone] = useState("");
  const [billingPostcode, setBillingPostcode] = useState("");
  const [billingAddress, setBillingAddress] = useState("");
  const [billingSelectedCity, setBillingSelectedCity] = useState("");
  const [billingCountry, setBillingCountry] = useState("");

  // Payment method options data
  const paymentMethods = [
    { id: "creditCard", name: "Credit Card", icon: <CreditCardIcon className="h-5 w-5" /> },
    { id: "cashOnDelivery", name: "Cash on Delivery", icon: <BanknoteIcon className="h-5 w-5" /> },
    { id: "emi", name: "EMI", icon: <DollarSignIcon className="h-5 w-5" /> },
    { id: "cardlessEmi", name: "Cardless EMI", icon: <CreditCardIcon className="h-5 w-5" /> },
  ];

  // Cities options for select
  const cityOptions = [
    { value: "new-york", label: "New York" },
    { value: "los-angeles", label: "Los Angeles" },
    { value: "chicago", label: "Chicago" },
    { value: "houston", label: "Houston" },
    { value: "phoenix", label: "Phoenix" }
  ];

  // Country options for select
  const countryOptions = [
    { value: "us", label: "United States" },
    { value: "ca", label: "Canada" },
    { value: "uk", label: "United Kingdom" },
    { value: "au", label: "Australia" },
    { value: "de", label: "Germany" }
  ];

  // Shipping methods data
  const shippingMethods = [
    {
      id: "standard",
      name: "Standard shipping",
      description: "Delivery in 3-5 business days",
      price: "Free",
      icon: <TruckIcon className="h-5 w-5" />
    },
    {
      id: "express",
      name: "Express shipping",
      description: "Delivery in 1-2 business days",
      price: "$10.00",
      icon: <PackageIcon className="h-5 w-5" />
    }
  ];

  // Data for order summary
  const orderSummaryItems = [
    { label: "Subtotal (3 items):", value: "$2,427.00", color: "text-gray-900" },
    { label: "Saving:", value: "-$110.00", color: "text-dangermain" },
    { label: "Tax collected:", value: "$73.40", color: "text-gray-900" },
    {
      label: "Shipping:",
      value: "Calculated at checkout",
      color: "text-gray-900",
    },
  ];

  // Data for checkout steps
  const checkoutSteps = [
    { number: 1, title: "Delivery Information", active: true },
    { number: 2, title: "Shipping Address", active: false },
    { number: 3, title: "Payment", active: false },
  ];

  const handleCalculateCost = () => {
    if (city) {
      setShowShippingMethods(true);
    }
  };

  const handleSelectShippingMethod = (methodId: string) => {
    setSelectedShippingMethod(methodId);
  };

  const handleContinueToShippingAddress = () => {
    setDeliveryInfoCompleted(true);
    setCurrentStep(2);
  };

  const handleContinueToPayment = () => {
    setShippingAddressCompleted(true);
    setCurrentStep(3);
  };

  const handleEditDeliveryInfo = () => {
    setCurrentStep(1);
    setDeliveryInfoCompleted(false);
  };

  const handleEditShippingAddress = () => {
    setCurrentStep(2);
    setShippingAddressCompleted(false);
  };

  const handleCityChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    setSelectedCity(e.target.value);
  };

  const handleCountryChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    setCountry(e.target.value);
  };

  const handleBillingCityChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    setBillingSelectedCity(e.target.value);
  };

  const handleBillingCountryChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    setBillingCountry(e.target.value);
  };

  const handleSameAsBillingChange = () => {
    setSameAsBilling(!sameAsBilling);
    if (!sameAsBilling) {
      // If switching to same address, copy all shipping fields to billing
      setBillingFirstName(firstName);
      setBillingLastName(lastName);
      setBillingEmail(email);
      setBillingPhone(phone);
      setBillingPostcode(postcode);
      setBillingAddress(address);
      setBillingSelectedCity(selectedCity);
      setBillingCountry(country);
    }
  };

  const handleSelectPaymentMethod = (methodId: string) => {
    setSelectedPaymentMethod(methodId);
  };

  const handleNidFrontUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setNidFrontPhoto(e.target.files[0]);
    }
  };

  const handleNidBackUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setNidBackPhoto(e.target.files[0]);
    }
  };

  const handleCompletePayment = () => {
    // Here you would handle the payment submission
    // After successful payment, redirect to the thank you page
    window.location.href = '/thank-you';
  };

  return (
    <div className="w-full">
      {/* Breadcrumb */}
      <div className="mb-6">
        <div className="flex items-center gap-2">
          <Button
            variant="link"
            className="p-0 h-auto font-navigation-nav-link-small text-gray-700"
            onClick={() => window.location.href = '/'}
          >
            Home
          </Button>
          <ChevronRightIcon className="w-3.5 h-3.5 text-gray-400" />
          <Button
            variant="link"
            className="p-0 h-auto font-navigation-nav-link-small text-gray-700"
            onClick={() => window.location.href = '/cart'}
          >
            Cart
          </Button>
          <ChevronRightIcon className="w-3.5 h-3.5 text-gray-400" />
          <span className="font-navigation-nav-link-small text-gray-400">
            Checkout
          </span>
        </div>
      </div>

      {/* Main Content and Order Summary */}
      <div className="flex flex-col md:flex-row gap-8">
        {/* Main Content */}
        <div className="flex-1">
          {/* Delivery Information */}
          <div className="mb-8">
            <div className="flex items-center gap-2 mb-4">
              {deliveryInfoCompleted ? (
                <div className="flex items-center justify-center w-8 h-8 bg-gray-100 rounded-full">
                  <CheckIcon className="h-4 w-4 text-gray-700" />
                </div>
              ) : (
                <div className="flex items-center justify-center w-8 h-8 bg-primarymain text-white rounded-full">
                  <span className="text-xs font-semibold">1</span>
                </div>
              )}
              <h2 className="text-lg font-semibold text-gray-900 flex-1">Delivery Information</h2>
              {deliveryInfoCompleted && (
                <Button
                  variant="link"
                  className="text-gray-700 text-sm underline p-0 h-auto"
                  onClick={handleEditDeliveryInfo}
                >
                  Edit
                </Button>
              )}
            </div>

            {currentStep === 1 ? (
              <div className="mb-4">
                <p className="text-gray-600 text-sm mb-4">
                  Enter your City to see the delivery and collection options available in your area.
                </p>
                
                <div className="mb-2">
                  <div className="text-sm font-medium text-gray-700 mb-1">City</div>
                  <div className="flex gap-2">
                    <Input
                      value={city}
                      onChange={(e) => setCity(e.target.value)}
                      placeholder="e.g. New York"
                      className="max-w-[240px]"
                    />
                    <Button 
                      className="bg-primarymain hover:bg-primarymain/90 text-white-100 px-4 rounded-lg flex items-center gap-1"
                      onClick={handleCalculateCost}
                    >
                      Calculate cost and availability
                      <ChevronRightIcon className="w-4 h-4" />
                    </Button>
                  </div>
                </div>

                {/* Shipping Methods */}
                {showShippingMethods && (
                  <div className="pl-10 mt-8">
                    <h3 className="text-sm font-medium text-gray-900 mb-4">Shipping Method</h3>
                    <div className="flex flex-col space-y-4">
                      {shippingMethods.map((method) => (
                        <div 
                          key={method.id}
                          className={`relative flex items-start p-4 rounded-lg border-2 cursor-pointer ${
                            selectedShippingMethod === method.id
                              ? "border-primarymain bg-blue-50"
                              : "border-gray-200"
                          }`}
                          onClick={() => handleSelectShippingMethod(method.id)}
                        >
                          <div className="flex items-center h-5">
                            <div className={`w-5 h-5 rounded-full border flex items-center justify-center ${
                              selectedShippingMethod === method.id
                                ? "border-primarymain bg-primarymain"
                                : "border-gray-300"
                            }`}>
                              {selectedShippingMethod === method.id && (
                                <CheckIcon className="h-3 w-3 text-white" />
                              )}
                            </div>
                          </div>
                          <div className="ml-3 flex-1">
                            <div className="text-base font-medium text-gray-900">
                              {method.name}
                            </div>
                            <p className="text-sm text-gray-500">{method.description}</p>
                          </div>
                          <div className="flex items-center gap-3">
                            <div className="rounded-full bg-gray-100 p-2">
                              {method.icon}
                            </div>
                            <span className="text-base font-semibold">{method.price}</span>
                          </div>
                        </div>
                      ))}
                    </div>

                    {/* Continue Button */}
                    <div className="mt-8">
                      <Button 
                        className="bg-primarymain hover:bg-primarymain/90 text-white-100 px-6 py-3 rounded-lg flex items-center gap-2 w-full"
                        onClick={handleContinueToShippingAddress}
                      >
                        Continue
                        <ChevronRightIcon className="w-[18px] h-[18px]" />
                      </Button>
                    </div>
                  </div>
                )}
              </div>
            ) : (
              <div className="flex flex-col gap-4 pl-14">
                <div className="flex flex-col gap-2">
                  <div className="font-medium text-gray-900 text-sm">
                    City
                  </div>
                  <div className="text-gray-600 text-sm">
                    {city}
                  </div>
                </div>

                <div className="flex flex-col gap-2">
                  <div className="font-medium text-gray-900 text-sm">
                    Shipping Method
                  </div>
                  <div className="text-gray-600 text-sm">
                    {selectedShippingMethod === "standard" ? "Standard shipping (Free)" : "Express shipping ($10.00)"}
                  </div>
                </div>

                <div className="flex flex-col gap-2">
                  <div className="font-medium text-gray-900 text-sm">
                    Estimated delivery date
                  </div>
                  <div className="text-gray-600 text-sm">
                    <span>Monday, 13 </span>
                    <span className="text-gray-300">|</span>
                    <span> 12:00 - 16:00 </span>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Shipping Address */}
          <div className="mb-8">
            <div className="flex items-center gap-2 mb-4">
              {shippingAddressCompleted ? (
                <div className="flex items-center justify-center w-8 h-8 bg-gray-100 rounded-full">
                  <CheckIcon className="h-4 w-4 text-gray-700" />
                </div>
              ) : (
                <div className={`flex items-center justify-center w-8 h-8 ${currentStep >= 2 ? "bg-primarymain text-white" : "bg-gray-200 text-gray-700"} rounded-full`}>
                  <span className="text-xs font-semibold">2</span>
                </div>
              )}
              <h2 className={`text-lg font-semibold ${currentStep >= 2 ? "text-gray-900" : "text-gray-500"}`}>Shipping Address</h2>
              {shippingAddressCompleted && (
                <Button
                  variant="link"
                  className="text-gray-700 text-sm underline p-0 h-auto ml-auto"
                  onClick={handleEditShippingAddress}
                >
                  Edit
                </Button>
              )}
            </div>

            {currentStep === 2 ? (
              <div className="flex flex-col gap-6 pl-14">
                <div className="flex flex-col gap-4 w-full">
                  <div className="flex flex-col gap-6 w-full">
                    {/* Name Fields */}
                    <div className="flex gap-6 w-full">
                      <div className="flex flex-col gap-2 flex-1">
                        <label className="text-sm font-medium text-gray-900">
                          First name <span className="text-red-500">*</span>
                        </label>
                        <Input 
                          className="px-4 py-[9px] bg-white rounded-lg border border-solid border-gray-300" 
                          value={firstName}
                          onChange={(e) => setFirstName(e.target.value)}
                        />
                      </div>
                      <div className="flex flex-col gap-2 flex-1">
                        <label className="text-sm font-medium text-gray-900">
                          Last name <span className="text-red-500">*</span>
                        </label>
                        <Input 
                          className="px-4 py-[9px] bg-white rounded-lg border border-solid border-gray-300" 
                          value={lastName}
                          onChange={(e) => setLastName(e.target.value)}
                        />
                      </div>
                    </div>

                    {/* Contact Fields */}
                    <div className="flex gap-6 w-full">
                      <div className="flex flex-col gap-2 flex-1">
                        <label className="text-sm font-medium text-gray-900">
                          Email address <span className="text-red-500">*</span>
                        </label>
                        <Input 
                          className="px-4 py-[9px] bg-white rounded-lg border border-solid border-gray-300" 
                          value={email}
                          onChange={(e) => setEmail(e.target.value)}
                        />
                      </div>
                      <div className="flex flex-col gap-2 flex-1">
                        <label className="text-sm font-medium text-gray-900">
                          Mobile number
                        </label>
                        <Input 
                          className="px-4 py-[9px] bg-white rounded-lg border border-solid border-gray-300" 
                          value={phone}
                          onChange={(e) => setPhone(e.target.value)}
                        />
                      </div>
                    </div>

                    {/* Country Field */}
                    <div className="flex flex-col gap-2 w-full">
                      <label className="text-sm font-medium text-gray-900">
                        Country <span className="text-red-500">*</span>
                      </label>
                      <div className="w-full">
                        <Select
                          options={countryOptions}
                          value={country}
                          onChange={handleCountryChange}
                          className="w-full"
                        />
                      </div>
                    </div>

                    {/* Location Fields */}
                    <div className="flex gap-6 w-full">
                      <div className="flex flex-col gap-2 flex-1">
                        <label className="text-sm font-medium text-gray-900">
                          City <span className="text-red-500">*</span>
                        </label>
                        <div className="w-full">
                          <Select
                            options={cityOptions}
                            value={selectedCity}
                            onChange={handleCityChange}
                            className="w-full"
                          />
                        </div>
                      </div>
                      <div className="flex flex-col gap-2 flex-1">
                        <label className="text-sm font-medium text-gray-900">
                          Postcode <span className="text-red-500">*</span>
                        </label>
                        <Input
                          className="px-4 py-3 bg-white rounded-lg border border-solid border-gray-300"
                          value={postcode}
                          onChange={(e) => setPostcode(e.target.value)}
                        />
                      </div>
                    </div>

                    {/* Address Field */}
                    <div className="flex flex-col gap-2 w-full">
                      <label className="text-sm font-medium text-gray-900">
                        House / apartment number and street address{" "}
                        <span className="text-red-500">*</span>
                      </label>
                      <Input 
                        className="px-4 py-[9px] bg-white rounded-lg border border-solid border-gray-300" 
                        value={address}
                        onChange={(e) => setAddress(e.target.value)}
                      />
                    </div>
                  </div>

                  {/* Add Address Lines Button */}
                  <Button
                    variant="ghost"
                    className="flex items-center gap-1.5 px-0 py-2.5 text-gray-700 text-sm"
                  >
                    Add address lines
                    <PlusIcon className="w-4 h-4" />
                  </Button>
                </div>

                {/* Billing Address Section */}
                <div className="flex flex-col gap-4 w-full">
                  <div className="flex items-center gap-2 w-full">
                    <h3 className="font-semibold text-gray-900">
                      Billing address
                    </h3>
                    <InfoIcon className="w-4 h-4 text-gray-500" />
                  </div>
                  <div className="flex items-center gap-2 w-full">
                    <div 
                      className="w-5 h-5 relative flex items-center justify-center cursor-pointer"
                      onClick={handleSameAsBillingChange}
                    >
                      <div className={`w-4 h-4 border ${sameAsBilling ? 'bg-primarymain border-primarymain' : 'bg-white border-gray-300'} rounded-sm`}></div>
                      {sameAsBilling && <CheckIcon className="w-3 h-3 text-white absolute" />}
                    </div>
                    <div className="flex-1 text-gray-600 text-sm">
                      Same as delivery address
                    </div>
                  </div>
                </div>

                {/* Billing Address Form (Only shown if not same as delivery) */}
                {!sameAsBilling && (
                  <div className="flex flex-col gap-4 w-full mt-4">
                    <h3 className="font-semibold text-gray-900">
                      Billing Address Details
                    </h3>
                    
                    <div className="flex flex-col gap-6 w-full">
                      {/* Name Fields */}
                      <div className="flex gap-6 w-full">
                        <div className="flex flex-col gap-2 flex-1">
                          <label className="text-sm font-medium text-gray-900">
                            First name <span className="text-red-500">*</span>
                          </label>
                          <Input 
                            className="px-4 py-[9px] bg-white rounded-lg border border-solid border-gray-300" 
                            value={billingFirstName}
                            onChange={(e) => setBillingFirstName(e.target.value)}
                          />
                        </div>
                        <div className="flex flex-col gap-2 flex-1">
                          <label className="text-sm font-medium text-gray-900">
                            Last name <span className="text-red-500">*</span>
                          </label>
                          <Input 
                            className="px-4 py-[9px] bg-white rounded-lg border border-solid border-gray-300" 
                            value={billingLastName}
                            onChange={(e) => setBillingLastName(e.target.value)}
                          />
                        </div>
                      </div>

                      {/* Contact Fields */}
                      <div className="flex gap-6 w-full">
                        <div className="flex flex-col gap-2 flex-1">
                          <label className="text-sm font-medium text-gray-900">
                            Email address <span className="text-red-500">*</span>
                          </label>
                          <Input 
                            className="px-4 py-[9px] bg-white rounded-lg border border-solid border-gray-300" 
                            value={billingEmail}
                            onChange={(e) => setBillingEmail(e.target.value)}
                          />
                        </div>
                        <div className="flex flex-col gap-2 flex-1">
                          <label className="text-sm font-medium text-gray-900">
                            Mobile number
                          </label>
                          <Input 
                            className="px-4 py-[9px] bg-white rounded-lg border border-solid border-gray-300" 
                            value={billingPhone}
                            onChange={(e) => setBillingPhone(e.target.value)}
                          />
                        </div>
                      </div>

                      {/* Country Field */}
                      <div className="flex flex-col gap-2 w-full">
                        <label className="text-sm font-medium text-gray-900">
                          Country <span className="text-red-500">*</span>
                        </label>
                        <div className="w-full">
                          <Select
                            options={countryOptions}
                            value={billingCountry}
                            onChange={handleBillingCountryChange}
                            className="w-full"
                          />
                        </div>
                      </div>

                      {/* Location Fields */}
                      <div className="flex gap-6 w-full">
                        <div className="flex flex-col gap-2 flex-1">
                          <label className="text-sm font-medium text-gray-900">
                            City <span className="text-red-500">*</span>
                          </label>
                          <div className="w-full">
                            <Select
                              options={cityOptions}
                              value={billingSelectedCity}
                              onChange={handleBillingCityChange}
                              className="w-full"
                            />
                          </div>
                        </div>
                        <div className="flex flex-col gap-2 flex-1">
                          <label className="text-sm font-medium text-gray-900">
                            Postcode <span className="text-red-500">*</span>
                          </label>
                          <Input
                            className="px-4 py-3 bg-white rounded-lg border border-solid border-gray-300"
                            value={billingPostcode}
                            onChange={(e) => setBillingPostcode(e.target.value)}
                          />
                        </div>
                      </div>

                      {/* Address Field */}
                      <div className="flex flex-col gap-2 w-full">
                        <label className="text-sm font-medium text-gray-900">
                          House / apartment number and street address{" "}
                          <span className="text-red-500">*</span>
                        </label>
                        <Input 
                          className="px-4 py-[9px] bg-white rounded-lg border border-solid border-gray-300" 
                          value={billingAddress}
                          onChange={(e) => setBillingAddress(e.target.value)}
                        />
                      </div>
                    </div>
                  </div>
                )}

                {/* Continue Button */}
                <Button 
                  className="flex items-center justify-center gap-2 px-6 py-3 w-full bg-primarymain text-white-100 rounded-lg"
                  onClick={handleContinueToPayment}
                >
                  Continue
                  <ChevronRightIcon className="w-[18px] h-[18px]" />
                </Button>
              </div>
            ) : (
              shippingAddressCompleted && (
                <div className="flex flex-col gap-4 pl-14">
                  <div className="flex flex-col gap-2">
                    <div className="font-medium text-gray-900 text-sm">
                      Name
                    </div>
                    <div className="text-gray-600 text-sm">
                      {firstName} {lastName}
                    </div>
                  </div>

                  <div className="flex flex-col gap-2">
                    <div className="font-medium text-gray-900 text-sm">
                      Email
                    </div>
                    <div className="text-gray-600 text-sm">
                      {email}
                    </div>
                  </div>

                  <div className="flex flex-col gap-2">
                    <div className="font-medium text-gray-900 text-sm">
                      Phone
                    </div>
                    <div className="text-gray-600 text-sm">
                      {phone || "Not provided"}
                    </div>
                  </div>

                  <div className="flex flex-col gap-2">
                    <div className="font-medium text-gray-900 text-sm">
                      Address
                    </div>
                    <div className="text-gray-600 text-sm">
                      {address}
                    </div>
                  </div>

                  <div className="flex flex-col gap-2">
                    <div className="font-medium text-gray-900 text-sm">
                      City
                    </div>
                    <div className="text-gray-600 text-sm">
                      {cityOptions.find(c => c.value === selectedCity)?.label || selectedCity}
                    </div>
                  </div>

                  <div className="flex flex-col gap-2">
                    <div className="font-medium text-gray-900 text-sm">
                      Billing Address
                    </div>
                    <div className="text-gray-600 text-sm">
                      {sameAsBilling 
                        ? "Same as shipping address" 
                        : billingFirstName + " " + billingLastName + ", " + billingAddress + ", " + (cityOptions.find(c => c.value === billingSelectedCity)?.label || billingSelectedCity)}
                    </div>
                  </div>
                </div>
              )
            )}
          </div>

          {/* Payment */}
          <div>
            <div className="flex items-center gap-2 mb-4">
              <div className={`flex items-center justify-center w-8 h-8 ${currentStep === 3 ? "bg-primarymain text-white" : "bg-gray-200 text-gray-700"} rounded-full`}>
                <span className="text-xs font-semibold">3</span>
              </div>
              <h2 className={`text-lg font-semibold ${currentStep === 3 ? "text-gray-900" : "text-gray-500"}`}>Payment</h2>
              {shippingAddressCompleted && currentStep !== 3 && (
                <Button
                  variant="link"
                  className="text-gray-700 text-sm underline p-0 h-auto ml-auto"
                  onClick={handleEditShippingAddress}
                >
                  Edit
                </Button>
              )}
            </div>
            
            {currentStep === 3 && (
              <div className="pl-14">
                <div className="space-y-6">
                  {/* Payment Method */}
                  <div>
                    <h3 className="text-base font-semibold mb-4">Payment Method</h3>
                    <div className="flex flex-col space-y-3">
                      {paymentMethods.map((method) => (
                        <div
                          key={method.id}
                          className={`flex items-center p-4 border rounded-lg cursor-pointer ${
                            selectedPaymentMethod === method.id
                              ? "border-primarymain bg-blue-50"
                              : "border-gray-200"
                          }`}
                          onClick={() => handleSelectPaymentMethod(method.id)}
                        >
                          <div className={`w-5 h-5 rounded-full border flex items-center justify-center ${
                            selectedPaymentMethod === method.id
                              ? "border-primarymain bg-primarymain"
                              : "border-gray-300"
                          }`}>
                            {selectedPaymentMethod === method.id && (
                              <CheckIcon className="h-3 w-3 text-white" />
                            )}
                          </div>
                          <div className="ml-3 flex items-center gap-2">
                            <div className="rounded-full bg-gray-100 p-2">
                              {method.icon}
                            </div>
                            <span className="text-base font-medium text-gray-900">{method.name}</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  <Separator className="my-6" />

                  {/* Credit Card Information */}
                  {selectedPaymentMethod === "creditCard" && (
                    <div className="space-y-4">
                      <h3 className="text-base font-semibold">Card Information</h3>

                      <div className="space-y-4">
                        <div className="flex flex-col gap-2">
                          <label className="text-sm font-medium text-gray-900">
                            Card Number <span className="text-red-500">*</span>
                          </label>
                          <Input
                            value={cardNumber}
                            onChange={(e) => setCardNumber(e.target.value)}
                            placeholder="1234 5678 9012 3456"
                            className="px-4 py-[9px] bg-white rounded-lg border border-solid border-gray-300"
                          />
                        </div>

                        <div className="grid grid-cols-2 gap-4">
                          <div className="flex flex-col gap-2">
                            <label className="text-sm font-medium text-gray-900">
                              Expiry Date <span className="text-red-500">*</span>
                            </label>
                            <Input
                              value={expiryDate}
                              onChange={(e) => setExpiryDate(e.target.value)}
                              placeholder="MM/YY"
                              className="px-4 py-[9px] bg-white rounded-lg border border-solid border-gray-300"
                            />
                          </div>
                          <div className="flex flex-col gap-2">
                            <label className="text-sm font-medium text-gray-900">
                              CVV <span className="text-red-500">*</span>
                            </label>
                            <Input
                              value={cvv}
                              onChange={(e) => setCvv(e.target.value)}
                              placeholder="123"
                              className="px-4 py-[9px] bg-white rounded-lg border border-solid border-gray-300"
                            />
                          </div>
                        </div>

                        <div className="flex flex-col gap-2">
                          <label className="text-sm font-medium text-gray-900">
                            Name on Card <span className="text-red-500">*</span>
                          </label>
                          <Input
                            value={nameOnCard}
                            onChange={(e) => setNameOnCard(e.target.value)}
                            placeholder="John Doe"
                            className="px-4 py-[9px] bg-white rounded-lg border border-solid border-gray-300"
                          />
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Cash on Delivery Instructions */}
                  {selectedPaymentMethod === "cashOnDelivery" && (
                    <div className="p-4 bg-gray-50 rounded-lg">
                      <p className="text-gray-600 text-sm">
                        You will pay for your order when it is delivered to your shipping address. Please ensure someone is available to receive the delivery and make the payment.
                      </p>
                    </div>
                  )}

                  {/* EMI Information */}
                  {selectedPaymentMethod === "emi" && (
                    <div className="space-y-4">
                      <h3 className="text-base font-semibold">EMI Information</h3>
                      <p className="text-gray-600 text-sm mb-4">
                        Please provide your credit card details for EMI payment option.
                      </p>

                      <div className="space-y-4">
                        <div className="flex flex-col gap-2">
                          <label className="text-sm font-medium text-gray-900">
                            Card Number <span className="text-red-500">*</span>
                          </label>
                          <Input
                            value={cardNumber}
                            onChange={(e) => setCardNumber(e.target.value)}
                            placeholder="1234 5678 9012 3456"
                            className="px-4 py-[9px] bg-white rounded-lg border border-solid border-gray-300"
                          />
                        </div>

                        <div className="grid grid-cols-2 gap-4">
                          <div className="flex flex-col gap-2">
                            <label className="text-sm font-medium text-gray-900">
                              Expiry Date <span className="text-red-500">*</span>
                            </label>
                            <Input
                              value={expiryDate}
                              onChange={(e) => setExpiryDate(e.target.value)}
                              placeholder="MM/YY"
                              className="px-4 py-[9px] bg-white rounded-lg border border-solid border-gray-300"
                            />
                          </div>
                          <div className="flex flex-col gap-2">
                            <label className="text-sm font-medium text-gray-900">
                              CVV <span className="text-red-500">*</span>
                            </label>
                            <Input
                              value={cvv}
                              onChange={(e) => setCvv(e.target.value)}
                              placeholder="123"
                              className="px-4 py-[9px] bg-white rounded-lg border border-solid border-gray-300"
                            />
                          </div>
                        </div>

                        <div className="flex flex-col gap-2">
                          <label className="text-sm font-medium text-gray-900">
                            Name on Card <span className="text-red-500">*</span>
                          </label>
                          <Input
                            value={nameOnCard}
                            onChange={(e) => setNameOnCard(e.target.value)}
                            placeholder="John Doe"
                            className="px-4 py-[9px] bg-white rounded-lg border border-solid border-gray-300"
                          />
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Cardless EMI */}
                  {selectedPaymentMethod === "cardlessEmi" && (
                    <div className="space-y-4">
                      <h3 className="text-base font-semibold">Cardless EMI Information</h3>
                      <p className="text-gray-600 text-sm mb-4">
                        Please provide your employment details and NID for verification.
                      </p>

                      <div className="space-y-4">
                        <div className="flex flex-col gap-2">
                          <label className="text-sm font-medium text-gray-900">
                            Job Title <span className="text-red-500">*</span>
                          </label>
                          <Input
                            value={jobTitle}
                            onChange={(e) => setJobTitle(e.target.value)}
                            placeholder="Software Engineer"
                            className="px-4 py-[9px] bg-white rounded-lg border border-solid border-gray-300"
                          />
                        </div>

                        <div className="flex flex-col gap-2">
                          <label className="text-sm font-medium text-gray-900">
                            Monthly Salary <span className="text-red-500">*</span>
                          </label>
                          <Input
                            value={salary}
                            onChange={(e) => setSalary(e.target.value)}
                            placeholder="5000"
                            className="px-4 py-[9px] bg-white rounded-lg border border-solid border-gray-300"
                          />
                        </div>

                        <div className="flex flex-col gap-2">
                          <label className="text-sm font-medium text-gray-900">
                            NID Front Photo <span className="text-red-500">*</span>
                          </label>
                          <div className="flex items-center gap-2">
                            <Input
                              type="file"
                              onChange={handleNidFrontUpload}
                              className="hidden"
                              id="nid-front"
                            />
                            <label 
                              htmlFor="nid-front"
                              className="px-4 py-2 bg-gray-100 rounded-lg border border-gray-300 flex items-center gap-2 cursor-pointer hover:bg-gray-200 text-sm"
                            >
                              <UploadIcon className="h-4 w-4" />
                              {nidFrontPhoto ? nidFrontPhoto.name : "Upload NID Front"}
                            </label>
                          </div>
                        </div>

                        <div className="flex flex-col gap-2">
                          <label className="text-sm font-medium text-gray-900">
                            NID Back Photo <span className="text-red-500">*</span>
                          </label>
                          <div className="flex items-center gap-2">
                            <Input
                              type="file"
                              onChange={handleNidBackUpload}
                              className="hidden"
                              id="nid-back"
                            />
                            <label 
                              htmlFor="nid-back"
                              className="px-4 py-2 bg-gray-100 rounded-lg border border-gray-300 flex items-center gap-2 cursor-pointer hover:bg-gray-200 text-sm"
                            >
                              <UploadIcon className="h-4 w-4" />
                              {nidBackPhoto ? nidBackPhoto.name : "Upload NID Back"}
                            </label>
                          </div>
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Complete Payment Button */}
                  <Button 
                    className="flex items-center justify-center gap-2 px-6 py-3 w-full bg-primarymain text-white-100 rounded-lg mt-6"
                    onClick={handleCompletePayment}
                  >
                    Complete Payment
                  </Button>
                  
                  <p className="text-center text-gray-500 text-sm">
                    Your payment information is secure and encrypted
                  </p>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Order Summary */}
        <div className="flex flex-col w-full md:w-[416px] gap-4">
          <Card className="bg-gray-50 rounded-2xl">
            <CardHeader className="flex flex-row items-center justify-between p-8 pb-6">
              <h3 className="font-heading-desktop-h5 text-gray-900">
                Order summary
              </h3>
              <Button
                variant="link"
                className="text-gray-700 text-sm underline p-0 h-auto"
                onClick={() => window.location.href = '/cart'}
              >
                Edit
              </Button>
            </CardHeader>
            <CardContent className="p-0 px-8">
              <div className="flex items-center gap-3 mb-6">
                <div className="w-16 h-16 relative">
                  <img
                    className="absolute w-14 h-14 top-1 left-1"
                    alt="Product image"
                    src="/image.png"
                  />
                </div>
                <div className="w-16 h-16 relative">
                  <img
                    className="absolute w-14 h-14 top-1 left-1"
                    alt="Product image"
                    src="/image-1.png"
                  />
                </div>
                <div className="w-16 h-16 relative">
                  <img
                    className="absolute w-14 h-14 top-1 left-1"
                    alt="Product image"
                    src="/image-2.png"
                  />
                </div>
                <ChevronRightIcon className="w-4 h-4 ml-auto" />
              </div>

              <Separator className="mb-4" />

              <div className="flex flex-col gap-4 mb-4">
                {orderSummaryItems.map((item, index) => (
                  <div key={index} className="flex gap-4 items-center w-full">
                    <div className="flex-1 text-gray-600 text-sm leading-[22px]">
                      {item.label}
                    </div>
                    <div
                      className={`flex-1 font-navigation-nav-link-small text-right ${item.color}`}
                    >
                      {item.value}
                    </div>
                  </div>
                ))}
              </div>

              <Separator className="mb-4" />
            </CardContent>
            <CardFooter className="flex items-center p-8 pt-0">
              <div className="flex items-center gap-4 w-full">
                <div className="flex-1 text-gray-600 text-sm leading-[22px]">
                  Estimated total:
                </div>
                <div className="w-[156px] font-heading-desktop-h5 text-gray-900 text-right">
                  $2,390.40
                </div>
              </div>
            </CardFooter>
          </Card>

          {/* Bonus Points Card */}
          <Card className="bg-gray-50 rounded-2xl p-6">
            <CardContent className="p-0">
              <div className="flex justify-center gap-3 items-center w-full">
                <div className="text-amber-500 text-xl">🎁</div>
                <div className="flex-1 text-gray-900 text-sm leading-[14px]">
                  <span className="text-[#181d25]">
                    Congratulations! You have earned{" "}
                  </span>
                  <span className="font-semibold text-[#181d25]">
                    256 bonuses
                  </span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}; 