import {
  MessageSquareIcon,
  StarIcon,
  ThumbsDownIcon,
  ThumbsUpIcon,
  ChevronDownIcon,
  ShoppingCartIcon,
  HeartIcon,
  RefreshCwIcon,
} from "lucide-react";
import React, { useState } from "react";
import { Badge } from "../../../../components/ui/badge";
import { Button } from "../../../../components/ui/button";
import { Separator } from "../../../../components/ui/separator";
import { Card, CardContent } from "../../../../components/ui/card";

export const ProductReviewsSection = (): JSX.Element => {
  const [currentPage, setCurrentPage] = useState(1);
  const totalPages = 16;

  // Review data for mapping
  const ratingDistribution = [
    { stars: 5, count: 37, width: "337px" },
    { stars: 4, count: 16, width: "100px" },
    { stars: 3, count: 9, width: "51px" },
    { stars: 2, count: 4, width: "25px" },
    { stars: 1, count: 2, width: "13px" },
  ];

  const reviews = [
    {
      id: 1,
      author: "Rafael Marquez",
      verified: true,
      date: "June 28, 2023",
      rating: 4,
      color: "Blue",
      model: "128GB",
      content:
        "The phone has a new A15 Bionic chip, which makes it lightning-fast and responsive. The camera system has also been upgraded, and it now includes a 12-megapixel ultra-wide lens and a 12-megapixel wide lens.",
      likes: 0,
      dislikes: 0,
      hasReply: false,
    },
    {
      id: 2,
      author: "Ronald Richards",
      verified: true,
      date: "June 8, 2023",
      rating: 4,
      color: "Black",
      model: "256GB",
      content:
        "The phone also has 5G connectivity, which makes it future-proof. Overall, the iPhone 14 is an excellent phone for anyone looking for a premium device with great features.",
      pros: "12-megapixel ultra-wide lens and a 12-megapixel wide lens",
      cons: "Does not have a headphone jack",
      likes: 0,
      dislikes: 0,
      hasReply: true,
      reply: {
        author: "Cartzilla Company",
        date: "June 12, 2023",
        content:
          "Thank you for your feedback! We are glad that you were satisfied with your purchase :)",
      },
    },
    {
      id: 3,
      author: "Kristin Watson",
      verified: true,
      date: "May 17, 2023",
      rating: 4,
      color: "Blue",
      model: "128GB",
      content:
        "The phone has a new A15 Bionic chip, which makes it lightning-fast and responsive. The camera system has also been upgraded, and it now includes a 12-megapixel ultra-wide lens and a 12-megapixel wide lens. The battery life is excellent, and it can easily last a whole day of heavy use.",
      likes: 0,
      dislikes: 0,
      hasImages: true,
      images: ["/image.png", "/image-1.png", "/image-2.png"],
    },
    {
      id: 4,
      author: "Jenny Wilson",
      verified: true,
      date: "May 28, 2023",
      rating: 4,
      color: "Red",
      model: "64GB",
      content:
        "The phone also has 5G connectivity, which makes it future-proof. Overall, the iPhone 13 is an excellent phone for anyone looking for a premium device with great features.",
      pros: "12-megapixel ultra-wide lens and a 12-megapixel wide lens",
      cons: "Does not have a headphone jack",
      likes: 0,
      dislikes: 0,
    },
  ];

  return (
    <div className="flex w-full max-w-[1296px] gap-6 lg:gap-8">
      <div className="flex flex-col w-full lg:w-[746px] gap-6">
        <div className="flex flex-col gap-4 w-full">
          <div className="flex justify-between items-center w-full">
            <h2 className="font-heading-desktop-h3 text-gray-900 text-xl sm:text-2xl">Reviews</h2>
            <Button
              variant="secondary"
              className="flex gap-1.5 px-3 py-2 sm:px-4 sm:py-2.5 bg-gray-100 rounded-lg"
            >
              <img className="w-4 h-4" alt="Icon" src="/icon-25.svg" />
              <span className="font-navigation-nav-link-small text-gray-700 text-sm">
                Leave a review
              </span>
            </Button>
          </div>

          <div className="flex flex-col sm:flex-row gap-4 sm:gap-6 w-full">
            <div className="flex flex-col items-center justify-center w-full sm:w-[196px] h-[150px] sm:h-[170px] bg-gray-50 rounded-lg">
              <span className="font-heading-desktop-h1 text-gray-900 text-center text-3xl sm:text-4xl">
                4.1
              </span>
              <div className="flex flex-col items-center gap-2 mt-4">
                <div className="flex gap-1">
                  {[1, 2, 3, 4].map((i) => (
                    <StarIcon
                      key={i}
                      className="w-3.5 h-3.5 fill-current text-yellow-500"
                    />
                  ))}
                  <StarIcon className="w-3.5 h-3.5 text-gray-300" />
                </div>
                <span className="font-normal text-gray-600 text-sm text-center">
                  68 reviews
                </span>
              </div>
            </div>

            <div className="flex flex-col w-full sm:w-[526px] gap-3 justify-center">
              {ratingDistribution.map((rating) => (
                <div
                  key={rating.stars}
                  className="flex items-center gap-4 w-full"
                >
                  <div className="flex items-center gap-1">
                    <span className="font-normal text-gray-600 text-sm">
                      {rating.stars}
                    </span>
                    <StarIcon className="w-3.5 h-3.5 text-gray-600" />
                  </div>
                  <div className="relative flex-1 h-1 bg-gray-100 rounded-[100px]">
                    <div
                      className="h-1 bg-yellow-500 rounded-[100px]"
                      style={{ width: rating.width }}
                    />
                  </div>
                  <span className="font-normal text-gray-500 text-sm text-right w-[17px]">
                    {rating.count}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="flex flex-col gap-6 w-full">
          <div className="flex flex-col gap-4 w-full">
            <div className="flex justify-between items-center w-full">
              <div className="flex items-center gap-2">
                <div className="relative w-5 h-5">
                  <img
                    className="absolute w-[15px] h-[15px] top-0.5 left-0.5"
                    alt="Union"
                    src="/union-1.svg"
                  />
                </div>
                <span className="font-normal text-gray-700 text-sm">
                  Only verified
                </span>
              </div>

              <div className="flex items-center gap-2.5 px-4 py-[9px] bg-white-100 rounded-lg border border-gray-200">
                <img className="w-4 h-4" alt="Icon" src="/icon-27.svg" />
                <span className="flex-1 font-normal text-gray-600 text-sm">
                  Most popular
                </span>
                <ChevronDownIcon className="w-3.5 h-3.5 text-gray-600" />
              </div>
            </div>
            <Separator className="w-full" />
          </div>

          {reviews.map((review) => (
            <div key={review.id} className="flex flex-col gap-4 w-full">
              <div className="flex flex-col gap-4 w-full">
                <div className="flex items-center gap-4 w-full">
                  <div className="flex items-center gap-2 flex-1">
                    <h3 className="font-heading-desktop-h6 text-gray-900">
                      {review.author}
                    </h3>
                    {review.verified && (
                      <img
                        className="w-4 h-4"
                        alt="Verified"
                        src="/icon-left-2.svg"
                      />
                    )}
                  </div>
                  <span className="flex-1 font-normal text-gray-500 text-sm text-right">
                    {review.date}
                  </span>
                </div>

                <div className="flex flex-col gap-3 w-full">
                  <div className="flex gap-1 w-full">
                    {Array(review.rating)
                      .fill(0)
                      .map((_, i) => (
                        <StarIcon
                          key={i}
                          className="w-3.5 h-3.5 fill-current text-yellow-500"
                        />
                      ))}
                    {Array(5 - review.rating)
                      .fill(0)
                      .map((_, i) => (
                        <StarIcon
                          key={i}
                          className="w-3.5 h-3.5 text-gray-300"
                        />
                      ))}
                  </div>

                  <div className="flex gap-8 w-full">
                    <div className="flex items-center gap-2">
                      <span className="font-navigation-nav-link-small text-gray-900">
                        Color:
                      </span>
                      <span className="font-normal text-gray-600 text-sm">
                        {review.color}
                      </span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="font-navigation-nav-link-small text-gray-900">
                        Model:
                      </span>
                      <span className="font-normal text-gray-600 text-sm">
                        {review.model}
                      </span>
                    </div>
                  </div>

                  <p className="font-normal text-gray-600 text-sm">
                    {review.content}
                  </p>

                  {(review.pros || review.cons) && (
                    <div className="flex flex-col gap-2 w-full">
                      {review.pros && (
                        <div className="flex items-center gap-2 w-full">
                          <span className="font-navigation-nav-link-small text-gray-900">
                            Pros:
                          </span>
                          <span className="font-normal text-gray-600 text-sm">
                            {review.pros}
                          </span>
                        </div>
                      )}
                      {review.cons && (
                        <div className="flex items-center gap-2 w-full">
                          <span className="font-navigation-nav-link-small text-gray-900">
                            Cons:
                          </span>
                          <span className="font-normal text-gray-600 text-sm">
                            {review.cons}
                          </span>
                        </div>
                      )}
                    </div>
                  )}

                  {review.hasImages && (
                    <div className="flex gap-3 py-2 w-full">
                      {review.images?.map((image, i) => (
                        <div
                          key={i}
                          className="w-[86px] h-[106px] rounded-md bg-cover bg-center"
                          style={{ backgroundImage: `url(${image})` }}
                        />
                      ))}
                    </div>
                  )}

                  <div className="flex justify-between items-center w-full">
                    <Button
                      variant="ghost"
                      className="flex items-center gap-1.5 px-0 py-2 text-gray-800"
                    >
                      <MessageSquareIcon className="w-4 h-4" />
                      <span className="font-navigation-nav-link-small">
                        Reply
                      </span>
                    </Button>

                    <div className="flex items-center gap-3">
                      <Button
                        variant="ghost"
                        className="flex items-center gap-1.5 px-0 py-2 text-gray-500"
                      >
                        <ThumbsUpIcon className="w-4 h-4" />
                        <span className="font-navigation-nav-link-small">
                          {review.likes}
                        </span>
                      </Button>
                      <Separator orientation="vertical" className="h-4" />
                      <Button
                        variant="ghost"
                        className="flex items-center gap-1.5 px-0 py-2 text-gray-500"
                      >
                        <ThumbsDownIcon className="w-4 h-4" />
                        <span className="font-navigation-nav-link-small">
                          {review.dislikes}
                        </span>
                      </Button>
                    </div>
                  </div>
                </div>
              </div>

              {review.hasReply && review.reply && (
                <div className="flex flex-col gap-6 w-full">
                  <div className="flex gap-4 pl-4 w-full">
                    <div className="flex flex-col gap-3 flex-1">
                      <div className="flex items-center gap-6 w-full">
                        <div className="flex items-center gap-2">
                          <Badge className="px-2 py-0.5 bg-blue-600 text-white-100 font-navigation-nav-link-extra-small">
                            Reply
                          </Badge>
                          <h4 className="font-heading-desktop-h6 text-gray-900">
                            {review.reply.author}
                          </h4>
                        </div>
                        <span className="flex-1 font-body-small text-gray-500">
                          {review.reply.date}
                        </span>
                      </div>
                      <p className="font-normal text-gray-600 text-sm">
                        {review.reply.content}
                      </p>
                    </div>
                  </div>
                  <Separator className="w-full" />
                </div>
              )}

              <Separator className="w-full" />
            </div>
          ))}

          <nav className="flex items-center gap-1 justify-center mt-2">
            {[1, 2, 3, 4, "...", 16].map((page, index) => (
              <button
                key={index}
                className={`h-8 w-8 flex items-center justify-center rounded-md text-sm font-medium transition-colors ${
                  page === 1
                    ? "bg-gray-100 text-gray-900"
                    : page === 2
                    ? "bg-gray-50 text-gray-900"
                    : "text-gray-600 hover:bg-gray-50"
                }`}
                onClick={() => typeof page === 'number' && setCurrentPage(page)}
              >
                {page}
              </button>
            ))}
          </nav>
        </div>
      </div>

      <div className="hidden lg:block md:self-start sticky top-4">
        <Card className="w-full md:w-[280px] lg:w-[320px] border border-[#e0e5eb] rounded-lg">
          <div className="p-3 flex flex-col gap-2">
            <div className="flex items-center gap-2 w-full">
              <div className="w-[70px] h-[70px] rounded bg-gray-100 flex-shrink-0"></div>
              <div className="flex flex-col gap-1 flex-1 min-w-0">
                <div className="flex items-center gap-2 w-full">
                  <div className="flex items-start gap-1">
                    <img className="w-3 h-3" alt="Star fill" src="/star-fill.svg" />
                    <img className="w-3 h-3" alt="Star fill" src="/star-fill.svg" />
                    <img className="w-3 h-3" alt="Star fill" src="/star-fill.svg" />
                    <img className="w-3 h-3" alt="Star fill" src="/star-fill.svg" />
                    <img className="w-3 h-3" alt="Star" src="/star.svg" />
                  </div>
                  <span className="flex-1 text-gray-400 text-xs">68</span>
                </div>
                <h4 className="text-gray-900 font-navigation-nav-link-small text-sm truncate">
                  Apple iPhone 14 Plus 128GB Blue
                </h4>
                <div className="flex items-center h-6 w-full">
                  <span className="text-gray-900 font-heading-desktop-h5 text-lg font-semibold">$940.00</span>
                </div>
              </div>
            </div>
            <div className="flex items-start gap-2 w-full">
              <Button className="flex-1 bg-primarymain hover:bg-primarymain/90 text-white-100 gap-1 rounded-lg text-xs h-8 px-2">
                <ShoppingCartIcon className="w-3 h-3" />
                <span className="hidden sm:inline">Add to cart</span>
                <span className="sm:hidden">Add</span>
              </Button>
              <Button
                variant="outline"
                size="icon"
                className="p-1.5 bg-gray-100 border-0 h-8 w-8"
              >
                <HeartIcon className="w-3 h-3" />
              </Button>
              <Button
                variant="outline"
                size="icon"
                className="p-1.5 bg-gray-100 border-0 h-8 w-8"
              >
                <RefreshCwIcon className="w-3 h-3" />
              </Button>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}; 