import {
  ChevronRightIcon,
  HeartIcon,
  InfoIcon,
  RefreshCwIcon,
  ShoppingCartIcon,
} from "lucide-react";
import React from "react";
import { Alert, AlertDescription } from "../../../../components/ui/alert";
import { Button } from "../../../../components/ui/button";
import { Card, CardContent } from "../../../../components/ui/card";

export const ProductDetailsSection = (): JSX.Element => {
  // Product specifications data
  const specCategories = [
    {
      title: "General specs",
      specs: [
    { label: "Model:", value: "iPhone 14 Plus" },
    { label: "Gender:", value: "Unisex" },
        { label: "Screen type:", value: "Super Retina XDR", hasInfo: true },
    { label: "Screen refresh rate:", value: "120 Hz" },
      ],
    },
    {
      title: "Display",
      specs: [
    { label: "Screen diagonal:", value: '6.1"' },
    { label: "Display resolution:", value: "2532x1170" },
        {
          label: "Matrix type:",
          value: "OLED (Super Retina XDR)",
          hasInfo: true,
        },
    { label: "Number of touch points:", value: "10" },
        { label: "Screen material:", value: "Screen material", hasInfo: true },
      ],
    },
    {
      title: "Memory functions",
      specs: [
        { label: "Memory functions:", value: "128 Gb" },
        { label: "Maximum size of a supported memory card:", value: "None" },
      ],
    },
    {
      title: "Battery",
      specs: [
        { label: "Fast charging:", value: "Yes" },
        { label: "Wireless charging:", value: "Yes", hasInfo: true },
        { label: "Charging power:", value: "15 W" },
      ],
    },
    {
      title: "Housing",
      specs: [
        {
          label: "Housing protection:",
          value: "Protection against dust and moisture",
          hasInfo: true,
    },
        { label: "Protection class:", value: "IP68", hasInfo: true },
        {
          label: "Biometric protection:",
          value: "Face recognition",
          hasInfo: true,
        },
        { label: "Body material:", value: "Metal, Glass" },
        { label: "Warranty period:", value: "2 years", hasInfo: true },
        { label: "Country of origin:", value: "China" },
      ],
    },
  ];

  return (
    <div className="flex flex-col w-full max-w-[1296px] gap-4 mx-auto pt-2 px-0">
      <div className="flex w-full flex-col md:flex-row gap-6 md:gap-6 lg:gap-8">
        {/* Left column - specifications */}
        <div className="flex-1 flex flex-col gap-4">
          <h2 className="text-gray-900 text-xl sm:text-2xl font-heading-desktop-h3 font-semibold leading-7">
            Product details
          </h2>

          {/* Specifications sections */}
          <div className="flex flex-col gap-4 w-full">
            {specCategories.map((category, index) => (
              <div key={index} className="flex flex-col gap-2 w-full">
                <h3 className="text-gray-900 font-heading-desktop-h6 text-base font-semibold">
                  {category.title}
          </h3>

                {category.specs.map((spec, specIndex) => (
                  <div key={specIndex} className="relative w-full min-h-[21px]">
                    {spec.hasInfo && (
                      <InfoIcon className="absolute right-0 w-4 h-4 top-[3px] text-gray-400" />
                    )}
                    <div className="w-full max-w-[722px] min-h-[21px]">
                      <div className="flex w-full min-h-[21px] items-center gap-2 flex-wrap sm:flex-nowrap">
                        <span className="text-gray-600 text-sm font-normal">
                          {spec.label}
                        </span>
                        <div className="hidden sm:block flex-1 h-[21px] border-b border-dotted border-gray-300" />
                        <span className="text-gray-900 text-left sm:text-right font-navigation-nav-link-small">
                          {spec.value}
                        </span>
                      </div>
                    </div>
                  </div>
                ))}
                      </div>
                    ))}
                  </div>

          {/* InfoIcon alert */}
          <Alert className="bg-blue-50 border border-blue-200 rounded-lg p-3">
            <div className="flex items-start gap-2">
              <InfoIcon className="w-[18px] h-[18px] mt-0.5 text-blue-500 flex-shrink-0" />
              <AlertDescription className="text-blue-700 text-sm">
                Product specifications and equipment are subject to change
                without notice.
              </AlertDescription>
            </div>
          </Alert>

          {/* Contact section */}
          <div className="flex flex-col gap-2">
            <h3 className="text-gray-900 font-heading-desktop-h6 text-base font-semibold">
              Do you have any questions?
            </h3>
            <Button className="bg-primarymain hover:bg-primarymain/90 text-white-100 rounded-md px-4 py-2 w-fit">
              Contact us
            </Button>
          </div>
        </div>

        {/* Right column - product card */}
        <div className="md:self-start sticky top-4">
          <Card className="w-full md:w-[280px] lg:w-[320px] border border-[#e0e5eb] rounded-lg">
            <CardContent className="p-3 flex flex-col gap-2">
              {/* Product summary */}
              <div className="flex items-center gap-2 w-full">
                <div className="w-[70px] h-[70px] rounded bg-gray-100 flex-shrink-0" />
                <div className="flex flex-col gap-1 flex-1 min-w-0">
                  {/* Rating */}
                <div className="flex items-center gap-2 w-full">
                    <div className="flex items-start gap-1">
                    {[1, 2, 3, 4].map((star) => (
                      <img
                        key={star}
                        className="w-3 h-3"
                        alt="Star fill"
                        src="/star-fill.svg"
                      />
                    ))}
                      <img className="w-3 h-3" alt="Star" src="/star.svg" />
                    </div>
                    <span className="flex-1 text-gray-400 text-xs">68</span>
                  </div>

                  {/* Product name */}
                  <h4 className="text-gray-900 font-navigation-nav-link-small text-sm truncate">
                  Apple iPhone 14 Plus 128GB Blue
                  </h4>

                  {/* Price */}
                  <div className="flex items-center h-6 w-full">
                    <span className="text-gray-900 font-heading-desktop-h5 text-lg font-semibold">
                    $940.00
                  </span>
                </div>
              </div>
            </div>

              {/* Action buttons */}
              <div className="flex items-start gap-2 w-full">
                <Button className="flex-1 bg-primarymain hover:bg-primarymain/90 text-white-100 gap-1 rounded-lg text-xs h-8 px-2">
                  <ShoppingCartIcon className="w-3 h-3" />
                  <span className="hidden sm:inline">Add to cart</span>
                  <span className="sm:hidden">Add</span>
              </Button>
              <Button
                variant="outline"
                size="icon"
                  className="p-1.5 bg-gray-100 border-0 h-8 w-8"
              >
                  <HeartIcon className="w-3 h-3" />
              </Button>
              <Button
                variant="outline"
                size="icon"
                  className="p-1.5 bg-gray-100 border-0 h-8 w-8"
              >
                  <RefreshCwIcon className="w-3 h-3" />
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
      </div>
    </div>
  );
}; 