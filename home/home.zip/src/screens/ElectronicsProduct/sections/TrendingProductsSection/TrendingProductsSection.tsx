import {
  ChevronLeftIcon,
  ChevronRightIcon,
  ShoppingCartIcon,
  StarIcon,
} from "lucide-react";
import React from "react";
import { Badge } from "../../../../components/ui/badge";
import { Button } from "../../../../components/ui/button";
import { Card, CardContent } from "../../../../components/ui/card";
import { Separator } from "../../../../components/ui/separator";

const products = [
  {
    id: 1,
    name: "VRB01 Virtual Reality Glasses",
    price: "$340.99",
    originalPrice: "$430.00",
    image: "/image-10.png",
    rating: 5,
    reviews: 14,
    badge: { text: "-21%", type: "danger" },
  },
  {
    id: 2,
    name: "Apple iPhone 14 128GB White",
    price: "$899.00",
    image: "/image-11.png",
    rating: 4,
    reviews: 142,
  },
  {
    id: 3,
    name: "Smart Watch Series 7, White",
    price: "$429.00",
    image: "/image-12.png",
    rating: 5,
    reviews: 64,
  },
  {
    id: 4,
    name: "Laptop Apple MacBook Pro 13 M2",
    price: "$1,200.00",
    image: "/image-13.png",
    rating: 3,
    reviews: 51,
    badge: { text: "New", type: "info" },
  },
];

export const TrendingProductsSection = (): JSX.Element => {
  return (
    <section className="flex flex-col w-full items-start gap-6">
      <div className="flex flex-col items-start gap-6 w-full">
        <h2 className="font-heading-desktop-h3 font-[number:var(--heading-desktop-h3-font-weight)] text-gray-900 text-[length:var(--heading-desktop-h3-font-size)] tracking-[var(--heading-desktop-h3-letter-spacing)] leading-[var(--heading-desktop-h3-line-height)] [font-style:var(--heading-desktop-h3-font-style)]">
          Trending products
        </h2>
        <Separator className="w-full" />
      </div>
      <div className="relative flex w-full">
        <Button
          variant="outline"
          size="icon"
          className="absolute -left-5 top-[181px] z-10 rounded-full bg-white-100 border-[#e0e5eb]"
        >
          <ChevronLeftIcon className="h-4 w-4" />
        </Button>
        <div className="flex gap-6 w-full">
          {products.map((product) => (
            <Card
              key={product.id}
              className="flex-1 rounded-lg overflow-hidden bg-white-100"
            >
              <div className="flex flex-col items-center justify-center p-6 relative">
                {product.badge && (
                  <Badge
                    className={`absolute top-4 left-4 ${
                      product.badge.type === "danger"
                        ? "bg-dangermain"
                        : "bg-infomain"
                    }`}
                  >
                    <span className="font-navigation-nav-link-extra-small font-[number:var(--navigation-nav-link-extra-small-font-weight)] text-white-100 text-[length:var(--navigation-nav-link-extra-small-font-size)] tracking-[var(--navigation-nav-link-extra-small-letter-spacing)] leading-[var(--navigation-nav-link-extra-small-line-height)] [font-style:var(--navigation-nav-link-extra-small-font-style)]">
                      {product.badge.text}
                    </span>
                  </Badge>
                )}
                <img
                  className="w-[258px] h-60"
                  alt={product.name}
                  src={product.image}
                />
              </div>
              <CardContent className="flex flex-col items-start gap-3 pt-0 pb-4 px-4 bg-white-100">
                <div className="flex flex-col items-start gap-2 w-full">
                  <div className="flex items-center gap-2 w-full">
                    <div className="flex gap-1">
                      {[...Array(5)].map((_, i) => (
                        <StarIcon
                          key={i}
                          className={`w-3 h-3 ${
                            i < product.rating
                              ? "fill-current text-yellow-500"
                              : "text-gray-200"
                          }`}
                        />
                      ))}
                    </div>
                    <span className="flex-1 font-body-extra-small font-[number:var(--body-extra-small-font-weight)] text-gray-400 text-[length:var(--body-extra-small-font-size)] tracking-[var(--body-extra-small-letter-spacing)] leading-[var(--body-extra-small-line-height)] [font-style:var(--body-extra-small-font-style)]">
                      ({product.reviews})
                    </span>
                  </div>
                  <h3 className="font-navigation-nav-link-small font-[number:var(--navigation-nav-link-small-font-weight)] text-gray-900 text-[length:var(--navigation-nav-link-small-font-size)] leading-[var(--navigation-nav-link-small-line-height)] tracking-[var(--navigation-nav-link-small-letter-spacing)] [font-style:var(--navigation-nav-link-small-font-style)]">
                    {product.name}
                  </h3>
                </div>
                <div className="flex items-center justify-between w-full">
                  <div className="flex items-center gap-2">
                    <span className="font-heading-desktop-h5 font-[number:var(--heading-desktop-h5-font-weight)] text-gray-900 text-[length:var(--heading-desktop-h5-font-size)] tracking-[var(--heading-desktop-h5-letter-spacing)] leading-[var(--heading-desktop-h5-line-height)] [font-style:var(--heading-desktop-h5-font-style)]">
                      {product.price}
                    </span>
                    {product.originalPrice && (
                      <span className="font-normal text-gray-400 text-sm leading-[21px] line-through">
                        {product.originalPrice}
                      </span>
                    )}
                  </div>
                  <Button
                    variant="secondary"
                    size="icon"
                    className="w-10 h-10 bg-gray-100 rounded-lg"
                  >
                    <ShoppingCartIcon className="w-4 h-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
        <Button
          variant="outline"
          size="icon"
          className="absolute right-0 top-[181px] z-10 rounded-full bg-white-100 border-[#e0e5eb]"
        >
          <ChevronRightIcon className="h-4 w-4" />
        </Button>
      </div>
    </section>
  );
}; 