import {
  ChevronDownIcon,
  ChevronLeftIcon,
  ChevronRightIcon,
  HeartIcon,
  MapPinIcon,
  MinusIcon,
  PlusIcon,
  SearchIcon,
  Share2Icon,
  ShoppingCartIcon,
} from "lucide-react";
import React from "react";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "../../../../components/ui/accordion";
import { Badge } from "../../../../components/ui/badge";
import {
  Breadcrumb,
  BreadcrumbList,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbSeparator,
} from "../../../../components/ui/breadcrumb";
import { Button } from "../../../../components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "../../../../components/ui/dropdown-menu";
import { Input } from "../../../../components/ui/input";
import {
  NavigationMenu,
  NavigationMenuItem,
  NavigationMenuLink,
  NavigationMenuList,
} from "../../../../components/ui/navigation-menu";
import { Separator } from "../../../../components/ui/separator";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "../../../../components/ui/tabs";
import { ProductDetailsSection } from "../ProductDetailsSection/ProductDetailsSection";
import { ProductReviewsSection } from "../ProductReviewsSection";

export const ProductNavbarSection = (): JSX.Element => {
  // Navigation links data
  const navLinks = [
    { text: "Best Sellers", href: "#" },
    { text: "Today's Deals", href: "#" },
    { text: "New Arrivals", href: "#" },
    { text: "Gift Cards", href: "#" },
    { text: "Help Center", href: "#" },
  ];

  // Storage options data
  const storageOptions = [
    { value: "64GB", selected: false },
    { value: "128GB", selected: true },
    { value: "256GB", selected: false },
    { value: "512GB", selected: false },
  ];

  // Color options data
  const colorOptions = [
    { color: "#5a7aa1", name: "Blue", selected: true },
    { color: "#ee7976", name: "Pink", selected: false },
    { color: "#9acbf1", name: "Light Blue", selected: false },
    { color: "#1f2631", name: "Black", selected: false },
  ];

  // Shipping options data
  const shippingOptions = [
    { method: "Pickup from the store", time: "Today", price: "Free" },
    { method: "Pickup from postal offices", time: "Tomorrow", price: "$25.00" },
    { method: "Delivery by courier", time: "2-3 days", price: "$35.00" },
  ];

  // Product images data
  const productImages = [
    { src: "/image.png", selected: true },
    { src: "/image-1.png", selected: false },
    { src: "/image-2.png", selected: false },
    { src: "/image-3.png", selected: false },
    { src: "/image-4.png", selected: false },
    { src: "/image-5.png", selected: false, more: 3 },
  ];

  return (
    <div className="container max-w-[1296px] px-4 sm:px-6 lg:px-8 flex flex-col items-start gap-2 sm:gap-3">
      {/* Breadcrumb Navigation */}
      <div className="flex items-center gap-2 text-xs text-gray-500 pt-1 pb-0 overflow-x-auto w-full">
        <span className="text-gray-700 whitespace-nowrap">Home</span>
        <ChevronRightIcon className="w-3.5 h-3.5 text-gray-400 flex-shrink-0" />
        <span className="text-gray-700 whitespace-nowrap">Shop</span>
        <ChevronRightIcon className="w-3.5 h-3.5 text-gray-400 flex-shrink-0" />
        <span className="text-gray-400 whitespace-nowrap">Product page</span>
      </div>

      {/* Product Title and Tabs */}
      <div className="flex flex-col w-full items-start gap-3 sm:gap-4">
        <h1 className="font-heading-desktop-h3 text-gray-900 text-[var(--heading-desktop-h3-font-size)] text-2xl sm:text-3xl md:text-4xl">
          Apple iPhone 14 PlusIcon 128GB Blue
        </h1>

        <div className="w-full relative">
          <Separator className="absolute bottom-0 w-full" />

          <Tabs defaultValue="general" className="w-full">
            <TabsList className="bg-transparent p-0 h-10 gap-2 sm:gap-4 md:gap-8 overflow-x-auto w-full">
              <TabsTrigger
                value="general"
                className="px-0 py-2.5 h-full data-[state=active]:border-b-2 data-[state=active]:border-[#181d25] data-[state=active]:text-gray-900 data-[state=inactive]:text-gray-700 rounded-none bg-transparent font-navigation-nav-link-small whitespace-nowrap"
              >
                General info
              </TabsTrigger>
              <TabsTrigger
                value="details"
                className="px-0 py-2.5 h-full data-[state=active]:border-b-2 data-[state=active]:border-[#181d25] data-[state=active]:text-gray-900 data-[state=inactive]:text-gray-700 rounded-none bg-transparent font-navigation-nav-link-small whitespace-nowrap"
              >
                Product details
              </TabsTrigger>
              <TabsTrigger
                value="reviews"
                className="px-0 py-2.5 h-full data-[state=active]:border-b-2 data-[state=active]:border-[#181d25] data-[state=active]:text-gray-900 data-[state=inactive]:text-gray-700 rounded-none bg-transparent font-navigation-nav-link-small whitespace-nowrap"
              >
                Reviews (68)
              </TabsTrigger>
            </TabsList>

            {/* Rating */}
            <div className="flex items-center gap-2 absolute top-[11px] right-0">
              <div className="flex items-start gap-1">
                {[1, 2, 3, 4].map((star) => (
                  <img
                    key={star}
                    className="w-3.5 h-3.5"
                    alt="Star fill"
                    src="/star-fill.svg"
                  />
                ))}
                <img className="w-3.5 h-3.5" alt="Star" src="/star-1.svg" />
              </div>
              <span className="font-body-extra-small text-gray-400 text-[var(--body-extra-small-font-size)] hidden sm:inline">
                68 reviews
              </span>
            </div>

            <TabsContent value="general" className="mt-4 w-full mb-0 min-h-0">
              {/* Product Content */}
              <div className="w-full flex flex-col lg:flex-row gap-4 lg:gap-6">
                {/* Product Images */}
                <div className="w-full lg:w-1/2 xl:w-[636px]">
                  {/* Main Product Image */}
                  <div className="w-full aspect-square lg:h-[500px] xl:h-[600px] rounded-lg bg-[url(/image-6.png)] bg-cover relative mb-2">
                    <Button
                      variant="outline"
                      size="icon"
                      className="absolute top-1/2 -translate-y-1/2 right-4 p-3 rounded-full"
                    >
                      <ChevronRightIcon className="w-4 h-4" />
                    </Button>
                    <Button
                      variant="outline"
                      size="icon"
                      className="absolute top-1/2 -translate-y-1/2 left-4 p-3 rounded-full"
                    >
                      <ChevronLeftIcon className="w-4 h-4" />
                    </Button>
                  </div>

                  {/* Thumbnail Images */}
                  <div className="flex items-start gap-2 mt-2 flex-wrap justify-center sm:justify-start">
                    {productImages.map((image, index) => (
                      <div
                        key={index}
                        className={`w-[60px] h-[60px] sm:w-[75px] sm:h-[75px] rounded-lg border ${image.selected ? "border-[#181d25]" : "border-[#e0e5eb]"} bg-[url(${image.src})] bg-cover relative`}
                      >
                        {image.more && (
                          <Badge className="absolute bottom-3 left-1/2 transform -translate-x-1/2 bg-gray-100 text-gray-700 font-medium px-2 py-px rounded">
                            +{image.more}
                          </Badge>
                        )}
                      </div>
                    ))}
                  </div>
                </div>

                {/* Product Details */}
                <div className="flex flex-col w-full lg:w-1/2 xl:w-[526px] gap-4 lg:gap-6 mt-4 lg:mt-0">
                  {/* Product Options */}
                  <div className="flex flex-col gap-3">
                    <div className="flex flex-col gap-4 sm:gap-5">
                      {/* Storage Options */}
                      <div className="flex flex-col gap-2">
                        <div className="font-body-small-semi-bold text-gray-900 text-[var(--body-small-semi-bold-font-size)]">
                          Model
                        </div>
                        <div className="flex gap-2 relative flex-wrap">
                          {storageOptions.map((option, index) => (
                            <Button
                              key={index}
                              variant="outline"
                              className={`px-3 py-1.5 rounded-md ${option.selected ? "border-[#181d25] text-gray-900" : "border-[#e0e5eb] text-gray-700"} font-navigation-nav-link-extra-small text-xs`}
                            >
                              {option.value}
                            </Button>
                          ))}
                          <span className="absolute top-px right-0 font-body-extra-small text-gray-500 text-[var(--body-extra-small-font-size)] hidden sm:block">
                            V00273124
                          </span>
                        </div>
                      </div>

                      {/* Color Options */}
                      <div className="flex flex-col gap-2">
                        <div className="flex items-center gap-1 w-full">
                          <span className="font-body-small-semi-bold text-gray-900 text-[var(--body-small-semi-bold-font-size)]">
                            Color:
                          </span>
                          <span className="flex-1 font-normal text-gray-600 text-sm leading-[22px]">
                            Blue
                          </span>
                        </div>
                        <div className="flex gap-3">
                          {colorOptions.map((option, index) => (
                            <div
                              key={index}
                              className={`w-5 h-5 rounded-full ${option.selected ? "border border-solid border-[#9ca3af]" : ""} flex items-center justify-center`}
                            >
                              <div
                                className="w-3.5 h-3.5 rounded-[6.88px]"
                                style={{ backgroundColor: option.color }}
                              />
                            </div>
                          ))}
                        </div>
                      </div>

                      {/* Price and Availability */}
                      <div className="flex items-center gap-3 sm:gap-4 w-full flex-wrap sm:flex-nowrap">
                        <div className="font-heading-desktop-h4 text-gray-900 text-[var(--heading-desktop-h4-font-size)]">
                          $940.00
                        </div>
                        <div className="flex items-center justify-end gap-2 flex-1">
                          <img
                            className="w-4 h-4"
                            alt="Icon left"
                            src="/icon-left-1.svg"
                          />
                          <span className="font-normal text-successmain text-sm leading-6 whitespace-nowrap">
                            Available to order
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* Add to Cart Section */}
                    <div className="flex flex-col gap-4">
                      <div className="flex items-start gap-2 sm:gap-3 w-full flex-wrap sm:flex-nowrap">
                        {/* Quantity Selector */}
                        <div className="flex items-center border border-solid border-[#cad0d9] rounded-lg h-9">
                          <Button
                            variant="ghost"
                            size="icon"
                            className="p-2.5 rounded-none"
                          >
                            <MinusIcon className="w-4 h-4" />
                          </Button>
                          <div className="flex w-10 items-center justify-center">
                            <span className="font-navigation-nav-link-regular text-gray-700 text-[var(--navigation-nav-link-regular-font-size)]">
                              1
                            </span>
                          </div>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="p-2.5 rounded-none"
                          >
                            <PlusIcon className="w-4 h-4" />
                          </Button>
                        </div>

                        {/* Add to Cart Button */}
                        <Button className="flex-1 sm:w-auto sm:flex-none sm:w-[200px] bg-primarymain hover:bg-primarymain/90 gap-2 h-9 px-3">
                          <ShoppingCartIcon className="w-4 h-4" />
                          <span className="font-navigation-nav-link-regular text-white-100 text-[var(--navigation-nav-link-regular-font-size)]">
                            Add to cart
                          </span>
                        </Button>

                        {/* Wishlist Button */}
                        <Button
                          variant="secondary"
                          size="icon"
                          className="p-2.5 bg-gray-100 h-9 w-9"
                        >
                          <HeartIcon className="w-4 h-4" />
                        </Button>

                        {/* Share Button */}
                        <Button
                          variant="secondary"
                          size="icon"
                          className="p-2.5 bg-gray-100 h-9 w-9"
                        >
                          <Share2Icon className="w-4 h-4" />
                        </Button>
                      </div>

                      {/* Additional Info */}
                      <div className="flex items-center gap-2 sm:gap-4 w-full flex-wrap">
                        {/* Bonuses */}
                        <div className="flex items-center gap-1.5">
                          <div className="relative w-4 h-4">
                            <img
                              className="absolute w-1.5 h-1.5 top-2.5 left-px"
                              alt="Group"
                              src="/group.png"
                            />
                            <img
                              className="absolute w-1.5 h-1.5 top-2.5 left-2"
                              alt="Group"
                              src="/group-1.png"
                            />
                            <div className="absolute w-4 h-[9px] top-0 left-0">
                              <img
                                className="absolute w-2 h-1 top-[5px] left-0"
                                alt="Group"
                                src="/group-2.png"
                              />
                              <img
                                className="absolute w-2 h-1 top-[5px] left-2"
                                alt="Group"
                                src="/group-3.png"
                              />
                              <img
                                className="absolute w-[7px] h-[5px] top-0 left-2"
                                alt="Group"
                                src="/group-4.png"
                              />
                              <img
                                className="absolute w-[7px] h-[5px] top-0 left-px"
                                alt="Group"
                                src="/group-5.png"
                              />
                            </div>
                          </div>
                          <span className="font-normal text-gray-900 text-xs">
                            <span className="font-body-small-semi-bold text-[#181d25] text-[var(--body-small-semi-bold-font-size)]">
                              +32
                            </span>{" "}
                            bonuses
                          </span>
                        </div>

                        {/* Interest-free loan */}
                        <div className="flex items-center gap-1.5">
                          <div className="relative w-4 h-4 bg-[url(/vector.svg)] bg-cover">
                            <img
                              className="absolute w-1.5 h-2 top-1 left-[5px]"
                              alt="Group"
                              src="/group-6.png"
                            />
                          </div>
                          <span className="font-normal text-gray-900 text-xs leading-[22px] whitespace-nowrap">
                            Interest-free loan
                          </span>
                        </div>

                        {/* Pay by installments */}
                        <div className="flex items-center gap-1.5">
                          <div className="relative w-4 h-4 bg-[url(/group-7.png)] bg-cover" />
                          <span className="font-normal text-gray-900 text-xs leading-[22px] whitespace-nowrap">
                            Pay by installments
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Shipping Options */}
                  <div className="flex flex-col gap-3">
                    <div className="w-full h-7 relative">
                      <h2 className="font-heading-desktop-h6 text-gray-900 text-[var(--heading-desktop-h6-font-size)]">
                        Shipping options
                      </h2>
                      <Button
                        variant="secondary"
                        size="sm"
                        className="absolute top-0 right-0 gap-1.5 px-3 py-1.5 bg-gray-100 hidden sm:flex text-xs"
                      >
                        <MapPinIcon className="w-3 h-3" />
                        <span className="font-navigation-nav-link-extra-small text-gray-700 text-[var(--navigation-nav-link-extra-small-font-size)]">
                          Find local store
                        </span>
                      </Button>
                    </div>

                    {/* Shipping Options List */}
                    {shippingOptions.map((option, index) => (
                      <div key={index} className="flex items-start gap-2 sm:gap-4 w-full flex-wrap sm:flex-nowrap">
                        <div className="w-full sm:w-[200px] font-normal text-gray-600 text-xs leading-[22px]">
                          {option.method}
                        </div>
                        <div className="flex-1 font-normal text-gray-600 text-xs leading-[22px]">
                          {option.time}
                        </div>
                        <div className="flex-1 font-body-small-semi-bold text-gray-900 text-[var(--body-small-semi-bold-font-size)] text-right text-xs">
                          {option.price}
                        </div>
                      </div>
                    ))}

                    <Separator className="my-1" />

                    {/* Accordion Sections */}
                    <Accordion type="single" collapsible className="w-full">
                      <AccordionItem
                        value="warranty"
                        className="border-b border-[#e0e5eb] py-0"
                      >
                        <AccordionTrigger className="py-3 hover:no-underline">
                          <h3 className="font-heading-desktop-h6 text-gray-900 text-[var(--heading-desktop-h6-font-size)] text-sm">
                            Warranty information
                          </h3>
                        </AccordionTrigger>
                        <AccordionContent>
                          {/* Warranty content would go here */}
                        </AccordionContent>
                      </AccordionItem>

                      <AccordionItem
                        value="payment"
                        className="border-b border-[#e0e5eb] py-0"
                      >
                        <AccordionTrigger className="py-3 hover:no-underline">
                          <h3 className="font-heading-desktop-h6 text-gray-900 text-[var(--heading-desktop-h6-font-size)] text-sm">
                            Payment and credit
                          </h3>
                        </AccordionTrigger>
                        <AccordionContent>
                          {/* Payment content would go here */}
                        </AccordionContent>
                      </AccordionItem>
                    </Accordion>
                  </div>
                </div>
              </div>
            </TabsContent>
            
            <TabsContent value="details" className="mt-4 w-full mb-0 pt-0 pb-0 min-h-0">
              <ProductDetailsSection />
            </TabsContent>
            
            <TabsContent value="reviews" className="mt-4 w-full mb-0 min-h-0">
              <ProductReviewsSection />
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
}; 