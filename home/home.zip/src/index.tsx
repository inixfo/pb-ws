import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { ElectronicsStore } from "./screens/ElectronicsStore/ElectronicsStore";
import { ShopCategories } from "./screens/ShopCategories/ShopCategories";
import { ShopCatalog } from "./screens/ShopCatalog/ShopCatalog";
import { ElectronicsProduct } from "./screens/ElectronicsProduct/ElectronicsProduct";
import { ShoppingCart } from "./screens/ShoppingCart/ShoppingCart";
import { DeliveryInfo } from "./screens/DeliveryInfo/DeliveryInfo";
import { ThankYou } from "./screens/ThankYou";
import { Account, Wishlist, PaymentMethods, Addresses, Notifications, MyEMI } from "./screens/Account";
import { MyReviews } from "./screens/Account/MyReviews";
import { PersonalInfo } from "./screens/Account/PersonalInfo";

createRoot(document.getElementById("app") as HTMLElement).render(
  <StrictMode>
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<ElectronicsStore />} />
        <Route path="/categories" element={<ShopCategories />} />
        <Route path="/catalog" element={<ShopCatalog />} />
        <Route path="/product" element={<ElectronicsProduct />} />
        <Route path="/cart" element={<ShoppingCart />} />
        <Route path="/checkout" element={<DeliveryInfo />} />
        <Route path="/thank-you" element={<ThankYou />} />
        <Route path="/account" element={<Account />} />
        <Route path="/wishlist" element={<Wishlist />} />
        <Route path="/payment-methods" element={<PaymentMethods />} />
        <Route path="/my-reviews" element={<MyReviews />} />
        <Route path="/personal-info" element={<PersonalInfo />} />
        <Route path="/addresses" element={<Addresses />} />
        <Route path="/notifications" element={<Notifications />} />
        <Route path="/my-emi" element={<MyEMI />} />
      </Routes>
    </BrowserRouter>
  </StrictMode>
);
