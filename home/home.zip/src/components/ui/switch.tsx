import * as React from "react";
import { cn } from "../../lib/utils";

export interface SwitchProps extends Omit<React.InputHTMLAttributes<HTMLInputElement>, "onChange"> {
  checked?: boolean;
  onCheckedChange?: (checked: boolean) => void;
}

export const Switch = React.forwardRef<HTMLInputElement, SwitchProps>(
  ({ className, checked, onCheckedChange, ...props }, ref) => {
    const handleChange = (event: React.ChangeEvent<HTMLInputElement>) => {
      onCheckedChange?.(event.target.checked);
    };

    return (
      <div className={cn("inline-flex h-[24px] w-[44px] relative", className)}>
        <input
          type="checkbox"
          className="peer sr-only"
          checked={checked}
          onChange={handleChange}
          ref={ref}
          {...props}
        />
        <span className="absolute inset-0 rounded-full bg-gray-300 peer-checked:bg-blue-500 transition-colors" />
        <span className="block h-5 w-5 rounded-full bg-white shadow-lg ring-0 transition-transform absolute top-0.5 left-0.5 peer-checked:translate-x-5" />
      </div>
    );
  }
);

Switch.displayName = "Switch"; 